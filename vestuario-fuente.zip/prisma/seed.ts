import "dotenv/config";
import { PrismaClient } from "@prisma/client";
import { hash } from "bcryptjs";
const db = new PrismaClient();
async function main() {
  const email = process.env.ADMIN_EMAIL || "admin@vestuario.local";
  const password = process.env.ADMIN_PASSWORD;
  if (!password || password.length < 12)
    throw new Error(
      "Define ADMIN_PASSWORD con al menos 12 caracteres en .env.",
    );
  await db.admin.upsert({
    where: { email },
    update: {},
    create: {
      email,
      name: "Administración",
      passwordHash: await hash(password, 12),
    },
  });
  if (process.env.SEED_DEMO !== "true") {
    console.log("Administrador inicializado. No se cargaron datos demo.");
    return;
  }
  const folk = await db.category.upsert({
    where: { slug: "folclor" },
    update: {},
    create: { slug: "folclor", name: "Arte, cultura y folclor" },
  });
  const dance = await db.category.upsert({
    where: { slug: "bailes" },
    update: {},
    create: { slug: "bailes", name: "Bailes tradicionales", parentId: folk.id },
  });
  const kids = await db.category.upsert({
    where: { slug: "infantiles" },
    update: {},
    create: { slug: "infantiles", name: "Disfraces infantiles" },
  });
  const princess = await db.category.upsert({
    where: { slug: "princesas" },
    update: {},
    create: { slug: "princesas", name: "Princesas", parentId: kids.id },
  });
  const jobs = await db.category.upsert({
    where: { slug: "profesiones" },
    update: {},
    create: { slug: "profesiones", name: "Profesiones", parentId: kids.id },
  });
  const accessories = await db.category.upsert({
    where: { slug: "accesorios" },
    update: {},
    create: { slug: "accesorios", name: "Piezas y accesorios" },
  });
  const samples = [
    {
      slug: "mapale",
      name: "Mapalé del Caribe",
      categoryId: dance.id,
      color: "Amarillo",
      price: 55000,
      tags: ["mapalé", "caribe", "danza", "folclor"],
      image: "mapale",
    },
    {
      slug: "cumbia",
      name: "Cumbia tradicional",
      categoryId: dance.id,
      color: "Blanco",
      price: 60000,
      tags: ["cumbia", "danza", "pollera", "caribe"],
      image: "cumbia",
    },
    {
      slug: "bambuco",
      name: "Bambuco de fiesta",
      categoryId: dance.id,
      color: "Rosado",
      price: 65000,
      tags: ["bambuco", "sanjuanero", "danza", "folclor"],
      image: "bambuco",
    },
    {
      slug: "tango",
      name: "Tango de escenario",
      categoryId: dance.id,
      color: "Rojo",
      price: 70000,
      tags: ["tango", "danza", "escenario"],
      image: "tango",
    },
    {
      slug: "cenicienta",
      name: "Cenicienta clásica",
      categoryId: princess.id,
      color: "Azul",
      price: 50000,
      tags: ["cenicienta", "princesa", "cinderella", "infantil"],
      image: "cenicienta",
    },
    {
      slug: "blancanieves",
      name: "Blancanieves del bosque",
      categoryId: princess.id,
      color: "Amarillo",
      price: 50000,
      tags: ["blancanieves", "princesa", "infantil"],
      image: "blancanieves",
    },
    {
      slug: "doctora",
      name: "Pequeña doctora",
      categoryId: jobs.id,
      color: "Blanco",
      price: 35000,
      tags: ["doctora", "doctor", "médica", "profesiones", "infantil"],
      image: "doctora",
    },
    {
      slug: "bombera",
      name: "Bombera al rescate",
      categoryId: jobs.id,
      color: "Rojo",
      price: 40000,
      tags: ["bombera", "bombero", "profesiones", "infantil"],
      image: "bombera",
    },
    {
      slug: "falda-llanera",
      name: "Falda llanera",
      categoryId: accessories.id,
      color: "Rojo",
      price: 30000,
      tags: ["joropo", "llanera", "falda"],
      image: "joropo",
    },
    {
      slug: "blusa-llanera",
      name: "Blusa llanera",
      categoryId: accessories.id,
      color: "Blanco",
      price: 20000,
      tags: ["joropo", "llanera", "blusa"],
      image: "cumbia",
    },
    {
      slug: "tocado",
      name: "Tocado de flores",
      categoryId: accessories.id,
      color: "Rojo",
      price: 10000,
      tags: ["flores", "accesorio", "cumbia"],
      image: "tocado",
    },
  ];
  for (const [index, s] of samples.entries()) {
    if (await db.costume.findUnique({ where: { slug: s.slug } })) continue;
    const model = await db.costume.create({
      data: {
        slug: s.slug,
        name: s.name,
        categoryId: s.categoryId,
        tags: s.tags,
        description:
          "Ejemplo ficticio para explorar Vestuario. La ilustración no representa una prenda real del negocio. Precio, piezas y medidas son datos de demostración.",
        searchTerms: s.tags.join(" "),
        images: [`/demo/${s.image}.svg`],
        demo: true,
        featured: index < 8,
        requiredMetrics: ["chest", "waist"],
      },
    });
    for (const [si, size] of ["6", "8"].entries()) {
      const v = await db.variant.create({
        data: {
          costumeId: model.id,
          size,
          color: s.color,
          price: s.price,
          commercialAgeMin: si ? 7 : 5,
          commercialAgeMax: si ? 9 : 7,
        },
      });
      for (let n = 1; n <= (s.slug === "cumbia" ? 8 : 3); n++) {
        const cleaning = s.slug === "bombera" && si === 0 && n === 3;
        const unit = await db.unit.create({
          data: {
            variantId: v.id,
            code: `DEMO-${s.slug.toUpperCase()}-${size}-${n}`,
            images: [],
            location: `Estante ${index + 1}`,
            state: cleaning ? "CLEANING" : "READY",
            notes: "Unidad ficticia de demostración",
            measurements: {
              create: [
                {
                  metric: "chest",
                  garmentCm: si ? 76 : 68,
                  easeCm: 4,
                  bodyMinCm: si ? 66 : 58,
                },
                {
                  metric: "waist",
                  garmentCm: si ? 68 : 60,
                  easeCm: 3,
                  bodyMinCm: si ? 57 : 49,
                },
              ],
            },
          },
        });
        if (cleaning)
          await db.inventoryBlock.create({
            data: {
              unitId: unit.id,
              kind: "CLEANING",
              startsAt: new Date(),
              reason: "Limpieza de ejemplo",
            },
          });
      }
    }
  }
  if (!(await db.costume.findUnique({ where: { slug: "joropo" } }))) {
    const model = await db.costume.create({
      data: {
        slug: "joropo",
        name: "Joropo · conjunto llanero",
        description:
          "Conjunto flexible de demostración: falda y blusa obligatorias. Ilustración y datos ficticios.",
        categoryId: dance.id,
        tags: ["joropo", "llanero", "llanera", "danza", "conjunto"],
        searchTerms: "ropa para bailar joropo folclor",
        images: ["/demo/joropo.svg"],
        requiredMetrics: [],
        featured: true,
        demo: true,
      },
    });
    for (const size of ["6", "8"]) {
      const v = await db.variant.create({
        data: { costumeId: model.id, size, color: "Rojo", price: 65000 },
      });
      const options = await db.variant.findMany({
        where: {
          size,
          costume: { slug: { in: ["falda-llanera", "blusa-llanera"] } },
        },
        include: { costume: true },
      });
      await db.outfit.create({
        data: {
          variantId: v.id,
          mode: "FLEXIBLE",
          components: {
            create: options.map((o) => ({
              name: o.costume.name,
              variantId: o.id,
              required: true,
            })),
          },
        },
      });
    }
  }
  if (
    !(await db.costume.findUnique({ where: { slug: "cumbia-conjunto-fijo" } }))
  ) {
    const model = await db.costume.create({
      data: {
        slug: "cumbia-conjunto-fijo",
        name: "Cumbia · conjunto de escenario",
        description:
          "Conjunto fijo de demostración con vestido y tocado específicos. Datos ficticios.",
        categoryId: dance.id,
        tags: ["cumbia", "conjunto"],
        searchTerms: "cumbia conjunto fijo",
        images: ["/demo/cumbia.svg"],
        requiredMetrics: [],
        demo: true,
      },
    });
    const v = await db.variant.create({
      data: { costumeId: model.id, size: "6", color: "Blanco", price: 75000 },
    });
    const dress = await db.unit.findFirstOrThrow({
      where: { variant: { size: "6", costume: { slug: "cumbia" } } },
      orderBy: { code: "asc" },
    });
    const flower = await db.unit.findFirstOrThrow({
      where: { variant: { size: "6", costume: { slug: "tocado" } } },
      orderBy: { code: "asc" },
    });
    await db.outfit.create({
      data: {
        variantId: v.id,
        mode: "FIXED",
        components: {
          create: [
            { name: "Vestido", fixedUnitId: dress.id },
            { name: "Tocado", fixedUnitId: flower.id },
          ],
        },
      },
    });
  }
  if (!(await db.rental.findUnique({ where: { reference: "DEMO-PROXIMA" } }))) {
    const unit = await db.unit.findFirstOrThrow({
      where: { variant: { costume: { slug: "mapale" }, size: "6" } },
    });
    const variant = await db.variant.findUniqueOrThrow({
      where: { id: unit.variantId },
    });
    const start = new Date(Date.now() + 3 * 86400000),
      end = new Date(Date.now() + 4 * 86400000);
    const customer = await db.customer.create({
      data: { name: "Cliente de demostración", contact: "Contacto ficticio" },
    });
    const rental = await db.rental.create({
      data: {
        reference: "DEMO-PROXIMA",
        demo: true,
        customerId: customer.id,
        startsAt: start,
        endsAt: end,
        status: "CONFIRMED",
        items: {
          create: {
            variantId: variant.id,
            quantity: 1,
            unitPrice: variant.price,
          },
        },
      },
      include: { items: true },
    });
    const a = await db.allocation.create({
      data: { itemId: rental.items[0].id, unitId: unit.id },
    });
    await db.inventoryBlock.create({
      data: {
        unitId: unit.id,
        rentalId: rental.id,
        allocationId: a.id,
        kind: "RENTAL",
        startsAt: start,
        endsAt: end,
      },
    });
    await db.payment.create({
      data: {
        rentalId: rental.id,
        kind: "RENT",
        amount: 20000,
        method: "Efectivo (demo)",
      },
    });
  }
  for (const sample of [
    {
      reference: "DEMO-ENTREGADA",
      slug: "tango",
      status: "DELIVERED" as const,
      start: -1,
      end: 1,
    },
    {
      reference: "DEMO-VENCIDA",
      slug: "bambuco",
      status: "DELIVERED" as const,
      start: -4,
      end: -1,
    },
    {
      reference: "DEMO-SOLICITUD",
      slug: "cenicienta",
      status: "REQUESTED" as const,
      start: 2,
      end: 3,
    },
    {
      reference: "DEMO-DEVUELTA",
      slug: "doctora",
      status: "RETURNED" as const,
      start: -5,
      end: -3,
    },
  ]) {
    if (await db.rental.findUnique({ where: { reference: sample.reference } }))
      continue;
    await db.$transaction(async (tx) => {
      const unit = await tx.unit.findFirstOrThrow({
        where: { variant: { size: "8", costume: { slug: sample.slug } } },
        include: { variant: true },
        orderBy: { code: "asc" },
      });
      const customer = await tx.customer.create({
        data: {
          name: "Cliente ficticio · " + sample.reference,
          contact: "Datos de demostración",
        },
      });
      const startsAt = new Date(Date.now() + sample.start * 86400000),
        endsAt = new Date(Date.now() + sample.end * 86400000);
      const rental = await tx.rental.create({
        data: {
          reference: sample.reference,
          demo: true,
          customerId: customer.id,
          startsAt,
          endsAt,
          status: sample.status,
          notes: "Ejemplo ficticio para explorar el flujo operativo.",
          items: {
            create: {
              variantId: unit.variantId,
              quantity: 1,
              unitPrice: unit.variant.price,
            },
          },
        },
        include: { items: true },
      });
      if (sample.status !== "REQUESTED") {
        const returned = sample.status === "RETURNED";
        const allocation = await tx.allocation.create({
          data: {
            unitId: unit.id,
            itemId: rental.items[0].id,
            returnedAt: returned ? endsAt : null,
            condition: returned ? "CLEANING" : null,
          },
        });
        await tx.inventoryBlock.create({
          data: {
            unitId: unit.id,
            rentalId: rental.id,
            allocationId: allocation.id,
            kind: "RENTAL",
            startsAt,
            endsAt,
            active: !returned,
          },
        });
        await tx.movement.create({
          data: {
            unitId: unit.id,
            type: returned ? "RETURNED" : "DELIVERED",
            detail: "Movimiento ficticio · " + sample.reference,
          },
        });
        if (returned) {
          await tx.unit.update({
            where: { id: unit.id },
            data: { state: "CLEANING" },
          });
          await tx.inventoryBlock.create({
            data: {
              unitId: unit.id,
              kind: "CLEANING",
              startsAt: endsAt,
              reason: "Revisión ficticia pendiente",
            },
          });
        }
        await tx.payment.create({
          data: {
            rentalId: rental.id,
            kind: "RENT",
            amount: unit.variant.price,
            method: "Efectivo (demo)",
          },
        });
      }
    });
  }
  console.log(
    "Seed terminado: administrador, categorías, ilustraciones demo, variantes, unidades, conjuntos y alquileres de ejemplo.",
  );
}
main()
  .catch((e) => {
    console.error(e);
    process.exitCode = 1;
  })
  .finally(() => db.$disconnect());
