ALTER TABLE "Costume" ADD COLUMN "bundleImage" TEXT;
