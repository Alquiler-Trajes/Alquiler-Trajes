-- CreateSchema
CREATE SCHEMA IF NOT EXISTS "public";

-- CreateEnum
CREATE TYPE "UnitState" AS ENUM ('READY', 'CLEANING', 'REPAIR', 'RETIRED');

-- CreateEnum
CREATE TYPE "RentalStatus" AS ENUM ('REQUESTED', 'CONFIRMED', 'PREPARING', 'DELIVERED', 'RETURNED', 'CLOSED', 'CANCELLED');

-- CreateEnum
CREATE TYPE "BlockKind" AS ENUM ('RENTAL', 'CLEANING', 'REPAIR', 'ADMIN');

-- CreateEnum
CREATE TYPE "PaymentKind" AS ENUM ('RENT', 'DEPOSIT', 'REFUND', 'DEPOSIT_REFUND');

-- CreateEnum
CREATE TYPE "OutfitMode" AS ENUM ('FIXED', 'FLEXIBLE');

-- CreateTable
CREATE TABLE "Admin" (
    "id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "passwordHash" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Admin_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Session" (
    "id" TEXT NOT NULL,
    "tokenHash" TEXT NOT NULL,
    "adminId" TEXT NOT NULL,
    "expiresAt" TIMESTAMPTZ(3) NOT NULL,

    CONSTRAINT "Session_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Category" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "parentId" TEXT,

    CONSTRAINT "Category_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Costume" (
    "id" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "categoryId" TEXT NOT NULL,
    "tags" TEXT[],
    "searchTerms" TEXT NOT NULL DEFAULT '',
    "requiredMetrics" TEXT[],
    "featured" BOOLEAN NOT NULL DEFAULT false,
    "demo" BOOLEAN NOT NULL DEFAULT false,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "images" TEXT[],
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Costume_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Variant" (
    "id" TEXT NOT NULL,
    "costumeId" TEXT NOT NULL,
    "size" TEXT NOT NULL,
    "color" TEXT NOT NULL,
    "price" INTEGER NOT NULL,
    "commercialAgeMin" INTEGER,
    "commercialAgeMax" INTEGER,
    "elastic" BOOLEAN NOT NULL DEFAULT false,
    "active" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "Variant_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Unit" (
    "id" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "variantId" TEXT NOT NULL,
    "state" "UnitState" NOT NULL DEFAULT 'READY',
    "location" TEXT NOT NULL DEFAULT '',
    "notes" TEXT NOT NULL DEFAULT '',
    "acquiredAt" TIMESTAMPTZ(3),
    "acquisitionCost" INTEGER,
    "images" TEXT[],

    CONSTRAINT "Unit_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Measurement" (
    "id" TEXT NOT NULL,
    "unitId" TEXT NOT NULL,
    "metric" TEXT NOT NULL,
    "garmentCm" DOUBLE PRECISION,
    "bodyMinCm" DOUBLE PRECISION,
    "bodyMaxCm" DOUBLE PRECISION,
    "easeCm" DOUBLE PRECISION,

    CONSTRAINT "Measurement_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Outfit" (
    "id" TEXT NOT NULL,
    "variantId" TEXT NOT NULL,
    "mode" "OutfitMode" NOT NULL,

    CONSTRAINT "Outfit_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "OutfitComponent" (
    "id" TEXT NOT NULL,
    "outfitId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "required" BOOLEAN NOT NULL DEFAULT true,
    "quantity" INTEGER NOT NULL DEFAULT 1,
    "variantId" TEXT,
    "fixedUnitId" TEXT,
    "allowSubstitution" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "OutfitComponent_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ComponentOption" (
    "componentId" TEXT NOT NULL,
    "variantId" TEXT NOT NULL,

    CONSTRAINT "ComponentOption_pkey" PRIMARY KEY ("componentId","variantId")
);

-- CreateTable
CREATE TABLE "Customer" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "contact" TEXT NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Customer_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Rental" (
    "id" TEXT NOT NULL,
    "reference" TEXT NOT NULL,
    "customerId" TEXT NOT NULL,
    "status" "RentalStatus" NOT NULL DEFAULT 'REQUESTED',
    "startsAt" TIMESTAMPTZ(3) NOT NULL,
    "endsAt" TIMESTAMPTZ(3) NOT NULL,
    "notes" TEXT NOT NULL DEFAULT '',
    "demo" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(3) NOT NULL,

    CONSTRAINT "Rental_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "RentalItem" (
    "id" TEXT NOT NULL,
    "rentalId" TEXT NOT NULL,
    "variantId" TEXT NOT NULL,
    "quantity" INTEGER NOT NULL,
    "unitPrice" INTEGER NOT NULL,

    CONSTRAINT "RentalItem_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Allocation" (
    "id" TEXT NOT NULL,
    "itemId" TEXT NOT NULL,
    "unitId" TEXT NOT NULL,
    "returnedAt" TIMESTAMPTZ(3),
    "condition" TEXT,

    CONSTRAINT "Allocation_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "InventoryBlock" (
    "id" TEXT NOT NULL,
    "unitId" TEXT NOT NULL,
    "rentalId" TEXT,
    "allocationId" TEXT,
    "kind" "BlockKind" NOT NULL,
    "startsAt" TIMESTAMPTZ(3) NOT NULL,
    "endsAt" TIMESTAMPTZ(3),
    "active" BOOLEAN NOT NULL DEFAULT true,
    "reason" TEXT NOT NULL DEFAULT '',
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "InventoryBlock_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Payment" (
    "id" TEXT NOT NULL,
    "rentalId" TEXT NOT NULL,
    "kind" "PaymentKind" NOT NULL,
    "amount" INTEGER NOT NULL,
    "method" TEXT NOT NULL,
    "note" TEXT NOT NULL DEFAULT '',
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Payment_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Movement" (
    "id" TEXT NOT NULL,
    "unitId" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "detail" TEXT NOT NULL,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Movement_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AuditLog" (
    "id" TEXT NOT NULL,
    "actorId" TEXT,
    "action" TEXT NOT NULL,
    "entityId" TEXT NOT NULL,
    "detail" JSONB,
    "createdAt" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "AuditLog_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "Admin_email_key" ON "Admin"("email");

-- CreateIndex
CREATE UNIQUE INDEX "Session_tokenHash_key" ON "Session"("tokenHash");

-- CreateIndex
CREATE INDEX "Session_expiresAt_idx" ON "Session"("expiresAt");

-- CreateIndex
CREATE UNIQUE INDEX "Category_name_key" ON "Category"("name");

-- CreateIndex
CREATE UNIQUE INDEX "Category_slug_key" ON "Category"("slug");

-- CreateIndex
CREATE UNIQUE INDEX "Costume_slug_key" ON "Costume"("slug");

-- CreateIndex
CREATE INDEX "Costume_categoryId_active_idx" ON "Costume"("categoryId", "active");

-- CreateIndex
CREATE UNIQUE INDEX "Variant_costumeId_size_color_key" ON "Variant"("costumeId", "size", "color");

-- CreateIndex
CREATE UNIQUE INDEX "Unit_code_key" ON "Unit"("code");

-- CreateIndex
CREATE INDEX "Unit_variantId_state_idx" ON "Unit"("variantId", "state");

-- CreateIndex
CREATE UNIQUE INDEX "Measurement_unitId_metric_key" ON "Measurement"("unitId", "metric");

-- CreateIndex
CREATE UNIQUE INDEX "Outfit_variantId_key" ON "Outfit"("variantId");

-- CreateIndex
CREATE INDEX "Customer_contact_idx" ON "Customer"("contact");

-- CreateIndex
CREATE UNIQUE INDEX "Rental_reference_key" ON "Rental"("reference");

-- CreateIndex
CREATE INDEX "Rental_status_startsAt_idx" ON "Rental"("status", "startsAt");

-- CreateIndex
CREATE INDEX "Rental_endsAt_idx" ON "Rental"("endsAt");

-- CreateIndex
CREATE INDEX "Allocation_unitId_returnedAt_idx" ON "Allocation"("unitId", "returnedAt");

-- CreateIndex
CREATE UNIQUE INDEX "Allocation_itemId_unitId_key" ON "Allocation"("itemId", "unitId");

-- CreateIndex
CREATE UNIQUE INDEX "InventoryBlock_allocationId_key" ON "InventoryBlock"("allocationId");

-- CreateIndex
CREATE INDEX "InventoryBlock_unitId_active_startsAt_idx" ON "InventoryBlock"("unitId", "active", "startsAt");

-- CreateIndex
CREATE INDEX "Payment_rentalId_createdAt_idx" ON "Payment"("rentalId", "createdAt");

-- CreateIndex
CREATE INDEX "Movement_unitId_createdAt_idx" ON "Movement"("unitId", "createdAt");

-- CreateIndex
CREATE INDEX "AuditLog_entityId_createdAt_idx" ON "AuditLog"("entityId", "createdAt");

-- AddForeignKey
ALTER TABLE "Session" ADD CONSTRAINT "Session_adminId_fkey" FOREIGN KEY ("adminId") REFERENCES "Admin"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Category" ADD CONSTRAINT "Category_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES "Category"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Costume" ADD CONSTRAINT "Costume_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES "Category"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Variant" ADD CONSTRAINT "Variant_costumeId_fkey" FOREIGN KEY ("costumeId") REFERENCES "Costume"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Unit" ADD CONSTRAINT "Unit_variantId_fkey" FOREIGN KEY ("variantId") REFERENCES "Variant"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Measurement" ADD CONSTRAINT "Measurement_unitId_fkey" FOREIGN KEY ("unitId") REFERENCES "Unit"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Outfit" ADD CONSTRAINT "Outfit_variantId_fkey" FOREIGN KEY ("variantId") REFERENCES "Variant"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "OutfitComponent" ADD CONSTRAINT "OutfitComponent_outfitId_fkey" FOREIGN KEY ("outfitId") REFERENCES "Outfit"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "OutfitComponent" ADD CONSTRAINT "OutfitComponent_variantId_fkey" FOREIGN KEY ("variantId") REFERENCES "Variant"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "OutfitComponent" ADD CONSTRAINT "OutfitComponent_fixedUnitId_fkey" FOREIGN KEY ("fixedUnitId") REFERENCES "Unit"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ComponentOption" ADD CONSTRAINT "ComponentOption_componentId_fkey" FOREIGN KEY ("componentId") REFERENCES "OutfitComponent"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ComponentOption" ADD CONSTRAINT "ComponentOption_variantId_fkey" FOREIGN KEY ("variantId") REFERENCES "Variant"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Rental" ADD CONSTRAINT "Rental_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "Customer"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RentalItem" ADD CONSTRAINT "RentalItem_rentalId_fkey" FOREIGN KEY ("rentalId") REFERENCES "Rental"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RentalItem" ADD CONSTRAINT "RentalItem_variantId_fkey" FOREIGN KEY ("variantId") REFERENCES "Variant"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Allocation" ADD CONSTRAINT "Allocation_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES "RentalItem"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Allocation" ADD CONSTRAINT "Allocation_unitId_fkey" FOREIGN KEY ("unitId") REFERENCES "Unit"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "InventoryBlock" ADD CONSTRAINT "InventoryBlock_unitId_fkey" FOREIGN KEY ("unitId") REFERENCES "Unit"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "InventoryBlock" ADD CONSTRAINT "InventoryBlock_rentalId_fkey" FOREIGN KEY ("rentalId") REFERENCES "Rental"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "InventoryBlock" ADD CONSTRAINT "InventoryBlock_allocationId_fkey" FOREIGN KEY ("allocationId") REFERENCES "Allocation"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Payment" ADD CONSTRAINT "Payment_rentalId_fkey" FOREIGN KEY ("rentalId") REFERENCES "Rental"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Movement" ADD CONSTRAINT "Movement_unitId_fkey" FOREIGN KEY ("unitId") REFERENCES "Unit"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- PostgreSQL is the final authority for physical unit exclusivity.
CREATE EXTENSION IF NOT EXISTS btree_gist;
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS unaccent;
ALTER TABLE "InventoryBlock" ADD CONSTRAINT "valid_block_interval" CHECK ("endsAt" IS NULL OR "endsAt" > "startsAt");
ALTER TABLE "InventoryBlock" ADD CONSTRAINT "no_unit_overlap" EXCLUDE USING gist ("unitId" WITH =, tstzrange("startsAt", "endsAt", '[)') WITH &&) WHERE (active);
ALTER TABLE "Rental" ADD CONSTRAINT "valid_rental_interval" CHECK ("endsAt" > "startsAt");
ALTER TABLE "Variant" ADD CONSTRAINT "nonnegative_price" CHECK (price >= 0);
ALTER TABLE "Payment" ADD CONSTRAINT "positive_payment" CHECK (amount > 0);
ALTER TABLE "RentalItem" ADD CONSTRAINT "positive_quantity" CHECK (quantity > 0 AND "unitPrice" >= 0);
ALTER TABLE "Measurement" ADD CONSTRAINT "valid_measurement" CHECK (("garmentCm" IS NULL OR "garmentCm" > 0) AND ("easeCm" IS NULL OR "easeCm" >= 0) AND ("bodyMinCm" IS NULL OR "bodyMinCm" > 0) AND ("bodyMaxCm" IS NULL OR "bodyMaxCm" > 0) AND ("bodyMinCm" IS NULL OR "bodyMaxCm" IS NULL OR "bodyMinCm" <= "bodyMaxCm"));
ALTER TABLE "OutfitComponent" ADD CONSTRAINT "valid_component" CHECK (quantity > 0 AND ("variantId" IS NOT NULL OR "fixedUnitId" IS NOT NULL));
CREATE INDEX "costume_search_trgm" ON "Costume" USING gin ((lower(name || ' ' || "searchTerms")) gin_trgm_ops);
CREATE INDEX "costume_search_text" ON "Costume" USING gin (to_tsvector('spanish', name || ' ' || description || ' ' || "searchTerms"));
