ALTER TABLE "Costume" ADD COLUMN "danceStyle" TEXT;
ALTER TABLE "Costume" ADD COLUMN "includedAccessories" TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[];
ALTER TABLE "Costume" ADD COLUMN "bundleSize" INTEGER NOT NULL DEFAULT 1;
ALTER TABLE "Costume" ADD CONSTRAINT "Costume_bundleSize_check" CHECK ("bundleSize" IN (1, 6));
