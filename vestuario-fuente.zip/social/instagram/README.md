# Instagram · @alquileresbga

Contenido preparado y publicado el 29 de octubre de 2026 para Alquiler Trajes Bga, con atención en Bucaramanga y su área metropolitana.

El contenido reutiliza únicamente las fotos revisadas de `apps/web/public/data/catalog.json`. La clasificación coincide con la web: Danzas y cultura, Disfraces (princesas, profesiones y personajes), y Accesorios. Los juegos de seis se anuncian para modelos culturales; piloto se presenta como traje completo.

## Generar y revisar

```powershell
pnpm instagram:prepare
pnpm instagram:preview
```

La entrega queda en `outputs/instagram-alquileresbga`. Abre `index.html` o `http://127.0.0.1:8170/`. Este servidor solo escucha en el equipo local.

El panel permite corregir la bio, el nombre propuesto, los títulos de las láminas, sus textos de apoyo, los pies de foto y los textos alternativos. Puede descargar una lámina en PNG o SVG y guardar/cargar las correcciones como JSON. Los cambios del panel no se publican en Instagram. Las imágenes JPG ya exportadas conservan su versión original; para una lámina corregida se usa la descarga del editor. El JSON permite conservar las correcciones al cambiar de equipo o navegador.

## Entrega

- Imagen de perfil y datos listos para copiar.
- Nueve publicaciones publicadas: 17 láminas, con textos y accesibilidad. Las tres colecciones encabezan la cuadrícula.
- Seis portadas de destacadas: Cultura, Disfraces, Accesorios, Cómo alquilar, Tallas y Nuestra zona.
- Seis historias de presentación publicadas; Cultura y Accesorios incluyen stickers de enlace a su colección.
- Seis respuestas para copiar y adaptar, sin envío automático.
- Propuesta inicial de tres semanas conservada como referencia. El usuario aprobó publicar todas las piezas el 29 de octubre; no quedó programación pendiente.
- Referencias de las doce fotografías utilizadas, sus hashes y dimensiones de las 30 imágenes diseñadas.

Las fotografías se insertan completas en las plantillas SVG y se convierten de formato para la exportación. No se generaron nuevos trajes ni se retocaron sus detalles. Las presentaciones editadas con IA se identifican en imágenes y textos. No se anuncian tarifas, garantías, cantidades nuevas, horarios, dirección o condiciones sin confirmar.

## Aplicado a la cuenta

Se guardaron la bio de 114 caracteres y la imagen de perfil. El nombre actual, Alquiler Trajes Bga, se conserva; el panel incluye una alternativa como propuesta. El usuario añadió el enlace del catálogo desde la app móvil, después de que el formulario web indicara esa limitación; se comprobó que apunta a `https://alquiler-trajes.github.io/Alquiler-Trajes/`.

Tras la aprobación del usuario se publicaron y verificaron las nueve publicaciones (17 láminas) y las seis historias en [@alquileresbga](https://www.instagram.com/alquileresbga/). Las publicaciones se cargaron del 09 al 01 para dejar Danzas y cultura, Disfraces y Accesorios en la primera fila. Se conservaron el formato original 4:5, los textos aprobados y los 17 textos alternativos. Se activó la etiqueta de IA en las ocho publicaciones con fotografías editadas. La publicación cruzada en Facebook quedó desactivada.

`publicaciones.json` conserva los enlaces y las verificaciones para evitar duplicar contenido. El kit incluye `PUBLICACIONES-EN-INSTAGRAM.txt` y capturas de la cuenta. Las correcciones del panel local no modifican las publicaciones existentes.

Las destacadas y la fijación de publicaciones no están confirmadas. Meta Business Suite reconoce las seis historias activas, pero el formulario para crear una destacada permanece cargando al guardar. Instagram web muestra vacía la selección para crear destacadas y no ofrece fijar publicaciones en el menú de estas. Las seis portadas siguen disponibles en `03-destacadas` para aplicarlas desde la app móvil. No se enviaron mensajes ni se activaron anuncios.

## Validación

Se comprobaron 30 imágenes, sus dimensiones, nueve textos de publicación, 17 textos alternativos, la longitud de la bio y la procedencia de doce fotos. Revisión visual conjunta de las 30 piezas y de ejemplos a tamaño completo. En el navegador se editó un título y se descargó el PNG de 1080×1350; se restauró el texto original y se comprobó guardar y recuperar el JSON de correcciones. Bio, avatar y enlace se revisaron en la cuenta real.

Los diseños usan 1080×1350 para publicaciones, 1080×1920 para historias/portadas y 1080×1080 para avatar. Son los formatos elegidos para esta entrega, sin afirmar cambios de alcance o resultados de Instagram. La cuenta mostró nueve publicaciones y Meta Business Suite mostró seis historias activas con 23 horas restantes al comprobarlas.
