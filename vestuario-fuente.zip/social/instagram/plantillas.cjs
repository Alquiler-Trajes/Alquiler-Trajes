/* Plantillas originales; las fotografías se insertan sin retocar ni recortar. */
const escapeXML = value => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&apos;"}[c]));
const palette = {culture:{ink:"#244d3a",wash:"#e9eee0",accent:"#a95235"},characters:{ink:"#244d3a",wash:"#e5edde",accent:"#a95235"},accessories:{ink:"#714381",wash:"#eee3f2",accent:"#714381"},guide:{ink:"#244d3a",wash:"#ece8dc",accent:"#a95235"}};
function lines(text, limit) {
  return String(text).split("\n").flatMap(paragraph => {
    const result = []; let line = "";
    for (const word of paragraph.split(/\s+/)) {
      if (line && `${line} ${word}`.length > limit) { result.push(line); line = word; }
      else line = line ? `${line} ${word}` : word;
    }
    result.push(line); return result;
  });
}
function textLines(text, x, y, size, limit, color, serif = false, lineHeight = 1.16) {
  return `<text x="${x}" y="${y}" fill="${color}" font-family="${serif ? "Georgia, serif" : "Arial, sans-serif"}" font-size="${size}">${lines(text,limit).map((line,i)=>`<tspan x="${x}" dy="${i ? size*lineHeight : 0}">${escapeXML(line)}</tspan>`).join("")}</text>`;
}
function svg(width,height,body) { return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}"><rect width="100%" height="100%" fill="#f9f7f2"/>${body}</svg>`; }
function brand(data,x,y,size=34) { return `<g transform="translate(${x} ${y-32})" color="#b95b39">${data.icons.flower}</g><text x="${x+46}" y="${y}" fill="#183e35" font-family="Georgia,serif" font-weight="bold" font-size="${size}">alquileresbga</text>`; }
function photo(data,key,x,y,width,height) { return `<image xlink:href="${data.photos[key].data}" x="${x}" y="${y}" width="${width}" height="${height}" preserveAspectRatio="xMidYMid meet"/>`; }
function poster(slide,data) {
  const p=palette[slide.theme||"guide"], guide=slide.layout==="steps";
  let body=brand(data,76,83)+`<text x="76" y="139" font-size="21" letter-spacing="2" font-family="Arial,sans-serif" fill="${p.ink}">${escapeXML(slide.eyebrow.toUpperCase())}</text>`;
  const titleSize=Math.min(76,Math.floor(190/(lines(slide.title,22).length*1.16)));
  body+=textLines(slide.title,76,232,titleSize,22,p.ink,true);
  body+=`<rect x="76" y="383" width="928" height="717" rx="28" fill="${p.wash}"/>`;
  if(guide) {
    slide.steps.forEach((step,i)=>{
      const y=455+i*190;
      body+=`<circle cx="139" cy="${y+7}" r="31" fill="${p.ink}"/><text x="139" y="${y+18}" text-anchor="middle" font-family="Arial,sans-serif" font-size="30" fill="white">${i+1}</text>`;
      body+=textLines(step.heading,199,y,39,31,p.ink,true)+textLines(step.text,199,y+57,29,39,"#425344",false,1.35);
    });
  } else if(slide.photos.length===1) {
    body+=`<rect x="103" y="406" width="874" height="671" rx="14" fill="#fffdf9"/>`+photo(data,slide.photos[0],112,416,856,651);
  } else {
    const gap=18, width=(874-gap*(slide.photos.length-1))/slide.photos.length;
    slide.photos.forEach((key,i)=>{
      const x=103+i*(width+gap);
      body+=`<rect x="${x}" y="406" width="${width}" height="671" rx="14" fill="#fffdf9"/>`+photo(data,key,x+8,421,width-16,641);
    });
  }
  body+=textLines(slide.subtitle,76,1160,lines(slide.subtitle,48).length>2?23:32,48,p.ink,false,1.3);
  body+=`<line x1="76" y1="1231" x2="1004" y2="1231" stroke="#cdd4c6"/><text x="76" y="1275" font-family="Arial,sans-serif" font-size="23" fill="#284e39">Bucaramanga y área metropolitana</text><text x="76" y="1312" font-family="Arial,sans-serif" font-size="18" fill="#566451">${guide ? "Consulta fecha, talla y condiciones por mensaje directo." : "Presentación con fotografía editada con IA. Confirma detalles y disponibilidad."}</text>`;
  return svg(1080,1350,body);
}
function cover(cover,data) {
  const p=palette[cover.theme||"guide"];
  return svg(1080,1920,`<rect x="0" y="0" width="1080" height="1920" fill="${p.wash}"/><circle cx="540" cy="925" r="330" fill="#f9f7f2" stroke="${p.ink}" stroke-width="3"/><circle cx="540" cy="925" r="289" fill="none" stroke="${p.ink}" stroke-opacity=".2"/><g transform="translate(420 765) scale(7.5)" color="${p.ink}">${data.icons[cover.icon]}</g><text x="540" y="1070" text-anchor="middle" font-family="Georgia,serif" font-size="63" fill="${p.ink}">${escapeXML(cover.label)}</text><text x="540" y="1450" text-anchor="middle" font-family="Arial,sans-serif" font-size="28" letter-spacing="3" fill="${p.ink}">@alquileresbga</text>`);
}
function story(story,data) {
  const p=palette[story.theme||"guide"];
  let body=brand(data,88,235,40)+textLines(story.title,88,400,82,20,p.ink,true);
  if(story.photo) body+=`<rect x="88" y="620" width="904" height="720" rx="30" fill="${p.wash}"/>`+photo(data,story.photo,113,645,854,670);
  else {
    body+=`<rect x="88" y="620" width="904" height="720" rx="30" fill="${p.wash}"/>`;
    story.steps.forEach((step,i)=>{body+=textLines(`${i+1}. ${step}`,140,750+i*180,43,31,p.ink,false,1.32);});
  }
  body+=textLines(story.body,88,1440,40,40,p.ink,false,1.35);
  body+=`<rect x="88" y="1640" width="904" height="85" rx="20" fill="${p.ink}"/><text x="540" y="1695" text-anchor="middle" font-family="Arial,sans-serif" font-size="31" fill="white">${escapeXML(story.cta)}</text><text x="88" y="1780" font-family="Arial,sans-serif" font-size="21" fill="#566451">${story.photo ? "Foto de presentación editada con IA." : "Disponibilidad y condiciones por confirmar."}</text>`;
  return svg(1080,1920,body);
}
function avatar(data) {
  return svg(1080,1080,`<circle cx="540" cy="540" r="491" fill="#e9eee0"/><circle cx="540" cy="540" r="447" fill="#f9f7f2" stroke="#b95b39" stroke-width="3"/><g transform="translate(395 218) scale(9)" color="#b95b39">${data.icons.flower}</g><text x="540" y="635" text-anchor="middle" font-family="Georgia,serif" font-size="113" fill="#183e35">alquileres</text><text x="540" y="758" text-anchor="middle" font-family="Georgia,serif" font-size="109" fill="#183e35">bga</text>`);
}
const api={poster,cover,story,avatar};
if(typeof module!=="undefined") module.exports=api; else window.SocialTemplates=api;
