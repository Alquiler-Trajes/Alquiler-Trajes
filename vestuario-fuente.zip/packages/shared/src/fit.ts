export type Metric = "height" | "chest" | "waist" | "hip" | "length";
export interface RecordedMeasurement {
  metric: string;
  garmentCm?: number | null;
  bodyMinCm?: number | null;
  bodyMaxCm?: number | null;
  easeCm?: number | null;
}
export interface FitResult {
  level: "ORIENTATIVE" | "ESTIMATED" | "VERIFIED";
  compatible: boolean | null;
  reasons: string[];
  missing: string[];
}
export function evaluateFit(
  body: Partial<Record<Metric, number>>,
  records: RecordedMeasurement[],
  required: string[],
  elastic: boolean,
): FitResult {
  const reasons: string[] = [];
  const missing: string[] = [];
  let checked = 0;
  let incompatible = false;
  if (!required.length)
    return {
      level: "ORIENTATIVE",
      compatible: null,
      reasons: [
        "El diseño no tiene criterios de ajuste registrados. Confirma las medidas o realiza una prueba física.",
      ],
      missing: [],
    };
  for (const metric of required) {
    const value = body[metric as Metric];
    const r = records.find((m) => m.metric === metric);
    if (value == null || !r) {
      missing.push(metric);
      continue;
    }
    if (
      (elastic && (r.bodyMinCm == null || r.bodyMaxCm == null)) ||
      (!elastic && (r.garmentCm == null || r.easeCm == null))
    ) {
      missing.push(metric);
      continue;
    }
    checked++;
    const upper = elastic ? r.bodyMaxCm! : r.garmentCm! - r.easeCm!;
    const lower = r.bodyMinCm;
    const fits = value <= upper && (lower == null || value >= lower);
    if (!fits) incompatible = true;
    reasons.push(
      `${metric}: cuerpo ${value} cm; ${elastic ? `rango corporal registrado ${r.bodyMinCm}–${r.bodyMaxCm} cm` : `prenda ${r.garmentCm} cm, holgura mínima registrada ${r.easeCm} cm`}. ${fits ? "Cumple este criterio." : "No cumple este criterio."}`,
    );
  }
  if (!checked)
    reasons.push(
      "La edad y la etiqueta comercial no confirman el ajuste. Registra medidas corporales y criterios reales de la prenda.",
    );
  if (missing.length)
    reasons.push(
      "Faltan medidas o criterios registrados. Se recomienda confirmar mediante medidas o prueba física.",
    );
  return {
    level: !checked ? "ORIENTATIVE" : missing.length ? "ESTIMATED" : "VERIFIED",
    compatible: incompatible ? false : checked && !missing.length ? true : null,
    reasons,
    missing,
  };
}
