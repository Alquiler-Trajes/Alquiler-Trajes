export const normalize = (s: string) =>
  s
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
const vocabulary: Record<string, string[]> = {
  cenicienta: ["cinderella"],
  mapale: ["mapale"],
  joropo: ["llanero", "llanera"],
  cumbia: ["cumbiamba"],
  doctora: ["doctor", "medico", "medica", "medicina"],
  bombera: ["bombero", "bomberas"],
  princesa: ["princesas", "princess"],
  azul: ["azules"],
  rojo: ["rojos", "roja", "rojas"],
  blanco: ["blanca", "blancas", "blancos"],
  amarillo: ["amarilla", "amarillos"],
};
export function distance(a: string, b: string): number {
  const row = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    let prev = row[0];
    row[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const old = row[j];
      row[j] = Math.min(
        row[j] + 1,
        row[j - 1] + 1,
        prev + (a[i - 1] === b[j - 1] ? 0 : 1),
      );
      prev = old;
    }
  }
  return row[b.length];
}
export interface SearchIntent {
  original: string;
  terms: string[];
  age?: number;
  quantity: number;
  color?: string;
  dates: string[];
  explanation: string[];
}
export interface QueryInterpreter {
  interpret(query: string): SearchIntent;
}
export function extractDates(original: string, now = new Date()): string[] {
  const q = normalize(original);
  const found: { position: number; date: string }[] = [];
  const today = new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Bogota",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(now);
  const year = Number(today.slice(0, 4));
  const add = (
    position: number,
    y: number,
    m: number,
    d: number,
    implicitYear = false,
  ) => {
    const date = new Date(Date.UTC(y, m - 1, d));
    if (
      date.getUTCFullYear() !== y ||
      date.getUTCMonth() !== m - 1 ||
      date.getUTCDate() !== d
    )
      return;
    let value = date.toISOString().slice(0, 10);
    if (implicitYear && value < today) value = `${y + 1}${value.slice(4)}`;
    found.push({ position, date: value });
  };
  for (const match of original.matchAll(/\b(\d{4})-(\d{2})-(\d{2})\b/g))
    add(match.index!, +match[1], +match[2], +match[3]);
  for (const match of original.matchAll(/\b(\d{1,2})\/(\d{1,2})\/(\d{4})\b/g))
    add(match.index!, +match[3], +match[2], +match[1]);
  const months = [
    "enero",
    "febrero",
    "marzo",
    "abril",
    "mayo",
    "junio",
    "julio",
    "agosto",
    "septiembre",
    "octubre",
    "noviembre",
    "diciembre",
  ];
  const regex = new RegExp(
    `\\b(\\d{1,2})\\s+(?:al\\s+(\\d{1,2})\\s+)?(?:de\\s+)?(${months.join("|")})(?:\\s+(?:de\\s+)?(\\d{4}))?\\b`,
    "g",
  );
  for (const match of q.matchAll(regex)) {
    const y = match[4] ? +match[4] : year,
      m = months.indexOf(match[3]) + 1;
    add(match.index!, y, m, +match[1], !match[4]);
    if (match[2]) add(match.index! + 0.5, y, m, +match[2], !match[4]);
  }
  return [
    ...new Set(
      found.sort((a, b) => a.position - b.position).map((f) => f.date),
    ),
  ];
}
const stop = new Set(
  "necesito quiero disfraz disfraces traje trajes ropa para de del la el las los una un unos con y en bailar anos nina nino ninas ninos presentacion por favor".split(
    " ",
  ),
);
export class LocalQueryInterpreter implements QueryInterpreter {
  interpret(original: string): SearchIntent {
    const q = normalize(original);
    const age = q.match(/(?:de\s+)?(\d{1,2})\s*anos/);
    const quantity = q.match(
      /(\d{1,2})\s*(?:trajes|disfraces|unidades|vestidos)/,
    );
    const dates = extractDates(original);
    const terms = q
      .replace(/\d{4}-\d{2}-\d{2}/g, "")
      .split(" ")
      .filter((w) => w && !stop.has(w) && !/^\d+$/.test(w))
      .map((w) => {
        for (const [key, aliases] of Object.entries(vocabulary))
          if (
            w === key ||
            aliases.includes(w) ||
            (w.length >= 5 && distance(w, key) === 1)
          )
            return key;
        return w;
      });
    const color = terms.find((t) =>
      [
        "azul",
        "rojo",
        "blanco",
        "amarillo",
        "negro",
        "verde",
        "rosado",
      ].includes(t),
    );
    return {
      original,
      terms: [...new Set(terms)],
      age: age ? Number(age[1]) : undefined,
      quantity: quantity ? Number(quantity[1]) : 1,
      color,
      dates,
      explanation: [
        ...(age
          ? [
              `${age[1]} años: referencia comercial; necesitamos medidas para confirmar la talla.`,
            ]
          : []),
        ...(dates.length === 1
          ? [
              "Identificamos una fecha. Completa entrega y devolución para evaluar disponibilidad.",
            ]
          : []),
      ],
    };
  }
}
export function relevance(intent: SearchIntent, text: string): number {
  const words = normalize(text).split(" ");
  if (!intent.terms.length) return 1;
  return intent.terms.reduce(
    (score, term) =>
      score +
      (words.some(
        (w) =>
          w === term ||
          w.startsWith(term) ||
          (term.startsWith(w) && w.length > 4),
      )
        ? 10
        : words.some((w) => term.length >= 5 && distance(w, term) <= 1)
          ? 5
          : 0),
    0,
  );
}
