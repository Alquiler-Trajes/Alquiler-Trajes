export type CollectionGroup = "celebraciones" | "personajes";
export type CostumeKind = "cultural" | "princess" | "profession" | "costume";
type Category = { id: string; slug?: string; name?: string; parentId?: string | null };
type Model = { category: { id: string; name?: string; slug?: string }; bundleSize?: number };
export const collectionSections: { kind: CostumeKind; title: string }[] = [
  { kind: "cultural", title: "Trajes culturales y de danza" },
  { kind: "princess", title: "Princesas" },
  { kind: "profession", title: "Profesiones" },
  { kind: "costume", title: "Disfraces" },
];
export function costumeKind(item: Model, categories: Category[]): CostumeKind {
  const labels = new Set<string>();
  const visited = new Set<string>();
  let category: Category | undefined = categories.find(c => c.id === item.category.id) || item.category;
  while (category && !visited.has(category.id)) {
    visited.add(category.id);
    labels.add((category.slug || category.name || "").toLowerCase());
    category = categories.find(c => c.id === category?.parentId);
  }
  if (item.bundleSize === 6 || labels.has("bailes") || labels.has("folclor")) return "cultural";
  if (labels.has("princesas")) return "princess";
  if (labels.has("profesiones")) return "profession";
  return "costume";
}
export const costumeOrder = (item: Model, categories: Category[]) => collectionSections.findIndex(s => s.kind === costumeKind(item, categories));
export const inCollection = (item: Model, categories: Category[], group?: string | null) =>
  !group || (group === "celebraciones" ? costumeOrder(item, categories) < 2 : costumeOrder(item, categories) >= 2);
