export type CollectionGroup = "celebraciones" | "personajes" | "accesorios";
export type CostumeKind = "cultural" | "stage" | "princess" | "profession" | "costume" | "accessory";
type Category = { id: string; slug?: string; name?: string; parentId?: string | null };
type Model = { category: { id: string; name?: string; slug?: string }; bundleSize?: number };
export const collectionSections: { kind: CostumeKind; title: string }[] = [
  { kind: "cultural", title: "Trajes culturales y de danza" },
  { kind: "stage", title: "Época y escenario" },
  { kind: "princess", title: "Princesas" },
  { kind: "profession", title: "Profesiones" },
  { kind: "costume", title: "Disfraces" },
  { kind: "accessory", title: "Accesorios para alquilar" },
];
export function costumeKind(item: Model, categories: Category[]): CostumeKind {
  const labels = new Set<string>();
  const visited = new Set<string>();
  let category: Category | undefined = categories.find(c => c.id === item.category.id) || item.category;
  while (category && !visited.has(category.id)) {
    visited.add(category.id);
    labels.add((category.slug || category.name || "").toLowerCase());
    category = categories.find(c => c.id === category?.parentId);
  }
  if (labels.has("accesorios")) return "accessory";
  if (item.bundleSize === 6 || labels.has("bailes") || labels.has("folclor")) return "cultural";
  const leaf = categories.find(c => c.id === item.category.id) || item.category;
  if (["baile", "epocas", "personajes"].includes((leaf.slug || "").toLowerCase())) return "stage";
  if (labels.has("princesas")) return "princess";
  if (labels.has("profesiones")) return "profession";
  return "costume";
}
export const costumeOrder = (item: Model, categories: Category[]) => collectionSections.findIndex(s => s.kind === costumeKind(item, categories));
export const inCollection = (item: Model, categories: Category[], group?: string | null) =>
  !group || (group === "accesorios" ? costumeKind(item, categories) === "accessory" : group === "celebraciones" ? ["cultural", "stage", "princess"].includes(costumeKind(item, categories)) : ["profession", "costume"].includes(costumeKind(item, categories)));
