export * from "./search";
export * from "./fit";
export * from "./catalog";
export const money = (amount: number) =>
  new Intl.NumberFormat("es-CO", {
    style: "currency",
    currency: "COP",
    maximumFractionDigits: 0,
  }).format(amount);
export const statusLabels: Record<string, string> = {
  REQUESTED: "Solicitado",
  CONFIRMED: "Confirmado",
  PREPARING: "En preparación",
  DELIVERED: "Entregado",
  RETURNED: "Devuelto",
  CLOSED: "Cerrado",
  CANCELLED: "Cancelado",
  READY: "Disponible",
  CLEANING: "En limpieza",
  REPAIR: "En reparación",
  RETIRED: "Retirada",
};
