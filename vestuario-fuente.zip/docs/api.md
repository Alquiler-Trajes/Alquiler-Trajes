# API REST

Base: `http://127.0.0.1:4000/api`. Swagger se genera a partir de los controladores en `/api/docs`; la especificación está en `/api/docs-json`. Los cuerpos indicados aquí se validan estrictamente. Las rutas administrativas requieren cookie `vestuario_session` y Origin permitido en mutaciones.

## Público

| Método y ruta                            | Operación                                                                                |
| ---------------------------------------- | ---------------------------------------------------------------------------------------- |
| `GET /health`                            | Comprueba PostgreSQL y servicio.                                                         |
| `GET /config`                            | Zona comercial y enlace WhatsApp si está configurado.                                    |
| `GET /catalog`                           | Catálogo paginado y búsqueda.                                                            |
| `GET /catalog/:slug`                     | Detalle, variantes, medidas públicas y bloqueos sin datos de clientes.                   |
| `GET /catalog/variants/:id/availability` | Cantidad disponible en `startsAt` / `endsAt`.                                            |
| `POST /catalog/variants/:id/fit`         | Medidas corporales opcionales en cm: `height`, `chest`, `waist`, `hip`, `length`.        |
| `POST /requests`                         | Registra solicitud pública y devuelve referencia, cotización, mensaje y enlace WhatsApp. |

`GET /catalog` admite `q`, `category` (id, incluye descendientes), `size`, `color`, `startsAt`, `endsAt`, `onlyAvailable=true`, `sort` (`relevance`, `price-asc`, `price-desc`, `name`) y `page` (desde 1). Devuelve `items`, `total`, `page`, `intent`, `suggestions`, `categories`, `filters` y fechas interpretadas. Páginas de 24 diseños.

Ejemplo de solicitud:

```json
{
  "name": "Cliente ficticio",
  "contact": "contacto-ficticio",
  "startsAt": "2026-11-05T09:00:00-05:00",
  "endsAt": "2026-11-07T18:00:00-05:00",
  "notes": "Presentación de prueba",
  "items": [{ "variantId": "id-real-de-variante", "quantity": 2 }]
}
```

Las fechas son ejemplos; deben elegirse instantes futuros. El precio lo lee el servidor. No se acepta un precio enviado por el visitante.

## Sesiones

| Método y ruta       | Cuerpo / respuesta                                                  |
| ------------------- | ------------------------------------------------------------------- |
| `POST /auth/login`  | `{email,password}`. Emite cookie protegida; devuelve nombre/correo. |
| `GET /auth/me`      | Requiere sesión. Devuelve identidad administrativa.                 |
| `POST /auth/logout` | Elimina sesión y cookie.                                            |

## Inventario administrativo

| Método y ruta                         | Cuerpo / operación                                                                                                                                                                       |
| ------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `GET, POST /admin/categories`         | Lista o crea `{name,parentId?}`.                                                                                                                                                         |
| `PATCH, DELETE /admin/categories/:id` | Edita categoría sin ciclos o elimina una categoría vacía.                                                                                                                                |
| `GET /admin/inventory`                | Diseños con variantes, unidades, medidas, bloqueos e historial.                                                                                                                          |
| `POST /admin/costumes`                | `name, categoryId, size, color, price, quantity`; opcionales `description, images, tags, searchTerms, requiredMetrics, featured, location, commercialAgeMin, commercialAgeMax, elastic`. |
| `PATCH /admin/costumes/:id`           | Edita campos del diseño, fotos, criterios, destacado y `active`.                                                                                                                         |
| `DELETE /admin/costumes/:id`          | Archiva conservando historial.                                                                                                                                                           |
| `POST /admin/costumes/:id/variants`   | `{size,color,price,elastic?,commercialAgeMin?,commercialAgeMax?}`.                                                                                                                       |
| `PATCH /admin/variants/:id`           | Campos comerciales y `active`.                                                                                                                                                           |
| `POST /admin/variants/:id/units`      | `{quantity,location?}`; 1–100 unidades independientes.                                                                                                                                   |
| `PATCH /admin/units/:id`              | `code?,state?,location?,notes?,images?,acquiredAt?,acquisitionCost?,measurements?`.                                                                                                      |
| `POST /admin/units/:id/blocks`        | `{startsAt,endsAt,kind,reason}`; kind `CLEANING`, `REPAIR` o `ADMIN`.                                                                                                                    |
| `DELETE /admin/blocks/:id`            | Libera bloqueo administrativo sin borrarlo.                                                                                                                                              |
| `POST /admin/images`                  | Multipart `file`; JPEG/PNG/WebP hasta 5 MB. Devuelve URL local WebP.                                                                                                                     |
| `POST /admin/outfits`                 | Define conjunto de una variante sin unidades propias.                                                                                                                                    |
| `PATCH /admin/outfits/:id`            | Reemplaza definición sin modificar asignaciones históricas.                                                                                                                              |
| `DELETE /admin/outfits/:id`           | Desarma un conjunto sin historial; si lo tiene debe archivarse.                                                                                                                          |

Medida: `{metric,garmentCm?,bodyMinCm?,bodyMaxCm?,easeCm?}`. Los valores ausentes pueden ser null. Estado físico: `READY`, `CLEANING`, `REPAIR`, `RETIRED`.

Conjunto: `{variantId,mode,components}`. Cada componente contiene `name`, `required`, `quantity`, `fixedUnitId` para fijo o `variantId` para flexible, `allowSubstitution` y `alternativeVariantIds`. Al menos uno obligatorio. Modalidades `FIXED` y `FLEXIBLE`; no anida conjuntos.

## Alquileres y operación

| Método y ruta                      | Operación                                                              |
| ---------------------------------- | ---------------------------------------------------------------------- |
| `GET /admin/dashboard`             | Indicadores y agenda.                                                  |
| `GET /admin/rentals`               | Últimos 500 alquileres con saldos, pagos y asignaciones.               |
| `GET /admin/rentals/:id`           | Detalle completo.                                                      |
| `PATCH /admin/rentals/:id/status`  | `{status}` según transiciones de negocio.                              |
| `PATCH /admin/rentals/:id/dates`   | `{startsAt,endsAt}` revalida solapamientos.                            |
| `POST /admin/rentals/:id/return`   | `{units:[{unitId,condition,note?}]}`; condition `CLEANING` o `REPAIR`. |
| `POST /admin/rentals/:id/payments` | `{kind,amount,method,note?}`.                                          |
| `GET /admin/customers`             | Últimos 500 clientes e historial.                                      |
| `PATCH /admin/customers/:id`       | `{name,contact}`.                                                      |
| `GET /admin/audit`                 | Últimas 100 operaciones.                                               |

## XLSX

| Método y ruta                | Operación                                                                                         |
| ---------------------------- | ------------------------------------------------------------------------------------------------- |
| `GET /admin/import/template` | Descarga plantilla XLSX.                                                                          |
| `POST /admin/import/preview` | Multipart `file`; devuelve filas validadas y errores sin escribir.                                |
| `POST /admin/import/commit`  | `{rows,confirmed:true}` usando filas de la previsualización; revalida todo y guarda atómicamente. |

## Respuestas de error

`{statusCode,message,details?}`. Códigos: 400 datos inválidos, 401 sesión ausente/vencida, 403 origen inválido, 404 registro inexistente, 409 conflicto de disponibilidad/estado/integridad, 413 archivo excesivo, 429 límite de solicitudes y 500 error inesperado sin detalles internos.
