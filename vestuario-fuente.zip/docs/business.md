# Flujos de negocio

## Inventario

Crear un diseño con cantidad N produce una variante y N unidades independientes con identificadores aleatorios únicos. Agregar una talla crea otra variante; **Registrar unidades** incorpora prendas físicas a esa variante. Cantidad 0 permite crear el diseño que representará un conjunto.

Las categorías permiten jerarquía y rechazan ciclos. No se elimina una categoría referenciada. Archivar un diseño lo oculta al público y evita nuevas asignaciones; no altera alquileres confirmados. Retirar o enviar una unidad a limpieza/reparación requiere resolver primero sus reservas activas.

Las indisponibilidades temporales se gestionan desde la unidad y bloquean sus fechas mediante PostgreSQL. El estado físico `CLEANING`, `REPAIR` o `RETIRED` la excluye adicionalmente de cualquier nueva asignación. Marcar `READY` termina los bloqueos administrativos de revisión; no modifica reservas.

## Búsqueda y tallas

La interpretación extrae términos, sinónimos, edad comercial, cantidad, color y fechas explícitas. Admite ISO, `dd/mm/aaaa` y fechas españolas como `del 5 al 7 de noviembre`. Una sola fecha necesita completar el intervalo. Expresiones relativas complejas como «el viernes de la otra semana» se completan con los filtros.

Se busca únicamente en registros existentes. La clasificación combina coincidencias normalizadas, errores de una letra, sinónimos, texto completo y similitud de PostgreSQL. Los filtros por categoría incluyen descendientes. Seleccionar fechas permite mostrar solo variantes con suficientes unidades para la cantidad interpretada.

El asistente compara datos corporales con criterios reales de cada unidad. Sin criterios o medidas devuelve **Orientativa** con compatibilidad desconocida. Con criterios parciales, **Estimada**. Con todos los criterios registrados, **Verificada por criterios**, pudiendo cumplirlos o incumplirlos. Una edad o talla de etiqueta nunca verifica por sí sola.

En prendas rígidas se exige `cuerpo <= prenda - holgura mínima registrada`, además del mínimo corporal si está registrado. En prendas elásticas/ajustables se exige el rango corporal mínimo y máximo medido. La interfaz muestra las razones, los datos faltantes y recomienda prueba física si corresponde.

## Solicitud y reserva

Los modelos culturales configurados con formato de seis admiten una unidad o juego completo. Para niña, el juego agrega tres variantes S y tres M; para niño, seis unidades Niño. Cada línea conserva su tarifa unitaria. El carrito muestra el juego y elimina sus líneas juntas; antes de enviar combina las cantidades de una misma variante. La disponibilidad del juego se consulta en una sola planificación para respetar existencias compartidas entre colores. Los accesorios incluidos son descripciones del traje y no originan asignaciones independientes.

```text
SOLICITADO → CONFIRMADO → EN PREPARACIÓN → ENTREGADO → DEVUELTO → CERRADO
     └──────────┴───────────────→ CANCELADO
```

La solicitud pública guarda los datos mínimos y la cotización real del servidor. No bloquea inventario. Confirmar asigna todas las piezas obligatorias o falla completamente; no deja una reserva incompleta. Cancelar antes de entregar libera bloqueos y conserva asignaciones y pagos históricos.

El negocio puede ajustar fechas; PostgreSQL rechaza superposiciones y revierte todo el cambio. No se cambia el inicio de una prenda entregada. La entrega solo se registra dentro del intervalo vigente y con unidades listas y devueltas por el cliente anterior.

Una devolución parcial registra únicamente las unidades recibidas y mantiene el alquiler entregado mientras haya faltantes. Cuando todas se reciben pasa a devuelto. Cada unidad requiere limpieza o reparación. Las prendas devueltas se liberan de ese alquiler pero no vuelven a estar listas hasta completar la revisión.

## Pagos

`RENT` abona el alquiler; `REFUND` devuelve abonos; `DEPOSIT` recibe una garantía; `DEPOSIT_REFUND` devuelve garantías. Los importes son positivos y se rechazan abonos superiores al saldo o devoluciones superiores a lo recibido. Las garantías no se cuentan como ingresos de alquiler. El panel informa total, abono neto, saldo y garantía pendiente.

Cerrar requiere devolución completa, saldo de alquiler cero y garantía neta cero. Una cancelación no genera un movimiento bancario ni un reembolso automático: el negocio debe registrar la devolución de dinero que corresponda.

## WhatsApp

El enlace incluye identificador de solicitud, nombres de referencia, talla, color, cantidades, fechas y total. El mensaje queda visible y puede copiarse incluso si el negocio no ha configurado su número. Abrir WhatsApp no cambia el estado de la solicitud.

## Importación

Descarga la plantilla, conserva las columnas y elimina la fila ficticia. La previsualización verifica tipos, categorías, cantidades, precios, referencias duplicadas y combinaciones nombre/talla/color ya existentes. No escribe datos.

La confirmación exige `confirmed=true`, revalida todos los datos y ejecuta el archivo completo en una transacción serializable. Si una fila es inválida o aparece un duplicado concurrente, no se incorpora ninguna fila. La referencia importada queda en términos internos del diseño para reconocer reintentos. Cada fila crea su diseño/variante y sus propias unidades; no fusiona variantes con diseños existentes.
