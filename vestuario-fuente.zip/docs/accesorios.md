# Accesorios y base de inventario en Excel

Actualizado el 29/10/2026.

El inicio conserva las dos colecciones de trajes y agrega un acceso sencillo a Accesorios. Se ofrecen Charlestón, caballero años 20, marinero, piloto, hawaiano, Michael Jackson, pirata clásico, pirata corsario y peineta de rosas. La selección admite trajes y kits juntos.

Piloto completo pertenece a Profesiones y enlaza al kit de accesorios; el kit enlaza al traje completo. La existencia de camisa y pantalón fue confirmada por el negocio. Su cantidad, talla y foto siguen pendientes. La ficha explica que la fotografía actual muestra únicamente los accesorios.

`prepare-accessory-rentals.ts` es transaccional e idempotente, crea una copia local previa y auditoría. Conserva 296 unidades listas y 759 archivadas. No crea unidades de accesorios con cantidades supuestas. Las referencias físicas compartidas entre kit y traje evitan reservas simultáneas de una misma pieza cuando se registre su stock. Los precios siguen pendientes y el servidor conserva el bloqueo de solicitudes sin tarifa.

Tres referencias con personas o anuncios se editaron con image_gen. Maestros: `Multimedia_Adjunta/Estudio/Accesorios`. Las fichas señalan que son ediciones con IA. El manifiesto `fotos-accesorios.json` registra las referencias y los prompts.

El Excel privado contiene cuatro tablas filtrables con fotos y encabezados inmovilizados:

- Inventario: 29 modelos, fotos y totales por modelo.
- Tallas: 246 registros, cantidades y estados de prendas, sin duplicar el stock cultural por color.
- Accesorios: 64 tipos de piezas y campos de cantidad, estado y tarifa pendientes de recuento.
- Kits: nueve ofertas y composición. Su capacidad usa las piezas de Accesorios; no son existencias adicionales.

Se comprobó la suma de 296 unidades, la ausencia de cantidades inventadas para piloto, el cálculo de disponibilidad tras modificar cantidades, la capacidad de un kit, la restauración de esos cambios y la ausencia de errores de fórmulas. Se renderizaron y revisaron las cuatro hojas. No se verificó la apertura en Microsoft Excel. La edición del archivo no actualiza la base de datos ni GitHub Pages automáticamente.

Validación de la aplicación: typecheck, compilación estática, 23 pruebas unitarias, 26 de integración y 10 de navegador en escritorio/móvil. Auditoría del inventario: `scripts/audit-accessory-inventory.ts`.
