# Accesorios y base de inventario en Excel

Actualizado el 29/10/2026. La [tercera entrega](coleccion-3.md) amplía el catálogo a 34 trajes y 14 accesorios o kits, actualiza las fotos y deja piloto únicamente en Profesiones.

El inicio conserva las dos colecciones de trajes y destaca Accesorios con una tercera tarjeta, carrusel y enlace en el menú. Véase [inicio y colecciones](inicio-colecciones.md). Se ofrecen kits y accesorios de Charlestón, caballero años 20, marinero, hawaiano, Michael Jackson, pirata, princesa, rosas con velo y capa. La selección admite trajes y kits juntos.

Piloto completo pertenece a Profesiones. El kit suelto se retiró por indicación del negocio. La foto actual muestra camisa blanca, pantalón y distintivos montados en el uniforme. Cantidad y talla siguen pendientes.

`prepare-accessory-rentals.ts` es transaccional e idempotente, crea una copia local previa y auditoría. Conserva 296 unidades listas y 759 archivadas. No crea unidades de accesorios con cantidades supuestas. Las referencias físicas compartidas entre kit y traje evitan reservas simultáneas de una misma pieza cuando se registre su stock. Los precios siguen pendientes y el servidor conserva el bloqueo de solicitudes sin tarifa.

Tres referencias con personas o anuncios se editaron con image_gen. Maestros: `Multimedia_Adjunta/Estudio/Accesorios`. Las fichas señalan que son ediciones con IA. El manifiesto `fotos-accesorios.json` registra las referencias y los prompts.

El Excel privado contiene cuatro tablas filtrables con fotos y encabezados inmovilizados:

- Inventario: 34 modelos, fotos y totales por modelo.
- Tallas: 246 registros, cantidades y estados de prendas, sin duplicar el stock cultural por color.
- Accesorios: 66 tipos de piezas en 74 filas por tipo/color y campos de cantidad, estado y tarifa pendientes de recuento.
- Kits: catorce ofertas, sus variantes por color y un registro de piloto marcado como retirado. Su capacidad usa las piezas de Accesorios; no son existencias adicionales.

Se comprobó la suma de 296 unidades, la ausencia de cantidades inventadas para piloto, el cálculo de disponibilidad tras modificar cantidades, la capacidad de un kit, la restauración de esos cambios y la ausencia de errores de fórmulas. Se renderizaron y revisaron las cuatro hojas. No se verificó la apertura en Microsoft Excel. La edición del archivo no actualiza la base de datos ni GitHub Pages automáticamente.

Validación de la primera incorporación de accesorios: typecheck, compilación estática, 23 pruebas unitarias, 26 de integración y 10 de navegador en escritorio/móvil. Auditoría del inventario: `scripts/audit-accessory-inventory.ts`.

Publicación anterior verificada el 29/10/2026: ejecución [40885186996](https://github.com/Alquiler-Trajes/Alquiler-Trajes/actions/runs/40885186996), resultado correcto. Commit remoto `629f7092465ed12314a995346d249b8ad9f86be6`. El paquete corresponde al código local `f7fcc83`; SHA256 `373b9ca539f384d612e4029b90370dec04156b8cf11730c657687f5dc7ed1418`. El catálogo público confirma 38 modelos, nueve ofertas de accesorios y las dos opciones de piloto. El Excel privado contiene 102 imágenes incrustadas, cuatro tablas y cuatro vistas con encabezados fijos.
