# Inicio y colecciones · 29/10/2026

El inicio presenta tres entradas con fotos: Danzas y cultura, Disfraces, y Accesorios. Las dos familias de trajes se conservan; los accesorios tienen una entrada propia del mismo tamaño y un enlace destacado en el menú, también en móviles de 320 px.

Michael Jackson completo, Caballero años 20 completo y Oficial de época pertenecen a Danzas y cultura, dentro de «Época y escenario». Sus kits siguen en Accesorios. La clasificación toma la categoría final, para evitar que Piratas herede la agrupación de su categoría superior Personajes de época. El orden es culturales/danza, época/escenario, princesas, profesiones, disfraces y accesorios.

La distribución actual es 15 trajes en Danzas y cultura, 19 en Disfraces y 14 accesorios o kits. Las ocho princesas se agrupan en Disfraces, junto a profesiones, piratas y personajes. No se modificaron fichas, existencias, tarifas ni el Excel privado.

Las portadas usan una selección de 20 fotografías existentes: cinco de cultura/escenario, nueve de princesas/profesiones/disfraces y seis de accesorios. Las fotos de princesa se trasladaron al carrusel central. Los marcos muestran la foto actual y adelantos laterales. El título de colección aparece encima de las fotos, y cada tarjeta tiene una acción clara para abrir su catálogo.

Los carruseles avanzan cada siete segundos, permiten recorrer las fotos y tienen un control común de pausa antes de las tarjetas. Se detienen al recibir foco de teclado, al usar las flechas, al ocultar la página y al activar movimiento reducido. El puntero también pausa la tarjeta sobre la que se encuentra. La navegación manual sigue disponible.

Validación: tipos correctos, 24 pruebas unitarias, 26 de integración y 14 de navegador en escritorio/móvil. Se verificaron cambio automático de fotos, pausa, teclado, agrupación, acceso a accesorios desde otra colección, movimiento reducido, ausencia de desbordamiento a 320 px, rutas y fotos, selección x1/x6 y descarga. Después de corregir la altura del encabezado móvil, se repitieron las pruebas dirigidas de inicio y diseño adaptable. Revisión visual en 390 px y escritorio mediante navegador.

La compilación de GitHub Pages se generó con la ruta /Alquiler-Trajes/. El sitio público conserva su funcionamiento como catálogo y selección; la disponibilidad y las reservas requieren la aplicación con API y base de datos.

Publicación verificada: [ejecución 40903916053](https://github.com/Alquiler-Trajes/Alquiler-Trajes/actions/runs/40903916053), resultado success, commit remoto `f9581612ddb4bac13f435633d5d300651c4c4104`. Fuente local `bf63a1fc019f8dff827ce66949785c9ab01a795f`; SHA256 del paquete `ec8a709ab26ac48f0ad96210b407ce88727063ce842ad28916e6b316723ee56c`. El navegador público confirmó las tres entradas, los tres modelos dentro de Época y escenario y el enlace del menú a los catorce accesorios. Captura local: `.runtime/entrega/inicio-carruseles-publicado.png`.
