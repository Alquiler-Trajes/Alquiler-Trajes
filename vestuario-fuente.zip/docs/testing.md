# Validación

## Estrategia

Las pruebas unitarias comprueban el intérprete y el ajuste sin UI o servicios externos. Integración usa Nest compilado por HTTP, Prisma real y una base PostgreSQL independiente (`vestuario_test`). Las pruebas E2E usan Next y Nest reales, Edge de escritorio y un iPhone 13 emulado en Chromium; no sustituyen respuestas de red con mocks.

Los casos crean datos ficticios con identificadores únicos. No se ejecutan eliminaciones masivas ni se reutiliza la base comercial. Los servidores temporales se detienen al finalizar las suites. Los artefactos de Playwright se ignoran en Git.

## Correspondencia con los casos solicitados

| Caso                                   | Verificación                                                |
| -------------------------------------- | ----------------------------------------------------------- |
| Cenicienta con edad, sin medidas       | Unitarias, integración y E2E.                               |
| mapale encuentra Mapalé                | Unitarias, integración y E2E.                               |
| Catálogo sin filtros                   | Integración y E2E.                                          |
| Varias unidades del mismo diseño       | Integración y E2E administrativo.                           |
| Datos insuficientes no verifican talla | Unitarias, integración y E2E.                               |
| Reservar unidad disponible             | Integración.                                                |
| Rechazar superposición                 | Integración HTTP y escritura PostgreSQL directa.            |
| Confirmaciones concurrentes            | Dos solicitudes HTTP simultáneas; exactamente una gana.     |
| Conjunto completo                      | Integración flexible y fijo.                                |
| Componentes compartidos                | Integración; incluye sustitución con asignación global.     |
| Devolución                             | Integración total y parcial.                                |
| Limpieza y reparación                  | Integración con estado y liberación.                        |
| Público sin acceso administrativo      | Integración 401 y E2E con redirección al login.             |
| XLSX válido                            | Libro real generado con ExcelJS, preview y commit.          |
| Filas inválidas                        | Preview sin escrituras y commit revalidado, sin corrupción. |

También se comprueban ausencia de holguras/rangos inventados, errores tipográficos, fechas colombianas, intervalos adyacentes, conservación histórica al cancelar, pagos y cierre, devolución de dinero no recibido, origen externo, validación estricta, imagen falsa y real, archivo ZIP inválido, devolución tardía cuando la próxima reserva ya comenzó y ausencia de desbordamiento horizontal móvil.

## Ejecutar

```powershell
pnpm test
pnpm test:integration
pnpm test:e2e
pnpm typecheck
pnpm build
pnpm audit --prod
```

PostgreSQL debe estar iniciado. Integración y E2E no deben ejecutarse a la vez: usan 4001 y la misma base de pruebas. El comando E2E usa además el puerto 3100. Edge instalado evita descargar otro navegador. Para Linux/macOS, ajustar `channel` en `playwright.config.ts` o instalar Chromium y retirar el canal.

Resultados de esta entrega y comandos exactos ejecutados: ver `docs/validation-results.md`.
