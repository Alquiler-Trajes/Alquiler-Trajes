# Arquitectura y datos

## Límites

`apps/web` consume REST a través de `/api`. Next reescribe las llamadas a Nest y expone las imágenes locales en `/uploads`. No se entrega la URL de PostgreSQL al navegador. La selección del visitante se guarda en localStorage, se valida al recuperarse y se revalida y cotiza en el servidor al solicitar.

Nest organiza controladores y servicios por función: `auth.ts`, `catalog.ts`, `inventory.ts`, `availability.ts`, `rentals.ts` e `imports.ts`. `Db` centraliza Prisma y las transacciones; `Errors` transforma errores de Zod, negocio, integridad y concurrencia en respuestas comprensibles. `ImageStorage` es el punto de extensión para almacenamiento externo. Los tipos de ajuste y búsqueda independientes de React viven en `packages/shared`.

## Relaciones principales

```mermaid
erDiagram
  Category ||--o{ Category : contiene
  Category ||--o{ Costume : clasifica
  Costume ||--o{ Variant : tiene
  Variant ||--o{ Unit : materializa
  Unit ||--o{ Measurement : mide
  Unit ||--o{ Movement : registra
  Variant ||--o| Outfit : representa
  Outfit ||--|{ OutfitComponent : incluye
  OutfitComponent ||--o{ ComponentOption : sustituye
  Customer ||--o{ Rental : solicita
  Rental ||--|{ RentalItem : cotiza
  RentalItem ||--o{ Allocation : asigna
  Unit ||--o{ Allocation : presta
  Unit ||--o{ InventoryBlock : bloquea
  Allocation ||--o| InventoryBlock : protege
  Rental ||--o{ Payment : registra
  Admin ||--o{ Session : autentica
```

Un modelo (`Costume`) contiene descripción, categoría, etiquetas, búsquedas, fotos y medidas necesarias. La variante contiene talla comercial, color, elasticidad y precio. La unidad contiene código único, estado físico, medidas reales, ubicación, adquisición, fotos y observaciones.

`Measurement.garmentCm` es una dimensión de prenda. `bodyMinCm/bodyMaxCm` son rangos corporales registrados. `easeCm` es la holgura mínima introducida por el negocio, no una tabla antropométrica. No se infieren campos ausentes.

Un `Outfit` representa una variante sin unidades propias. Sus componentes apuntan a una unidad fija o a una variante física. `ComponentOption` contiene variantes sustitutas explícitas. No se permiten conjuntos anidados. Editar la definición no modifica las asignaciones históricas de reservas ya confirmadas.

`RentalItem` conserva precio al solicitar. `Allocation` conserva la prenda realmente asignada y su devolución independiente. `InventoryBlock` representa reservas, limpieza, reparación e indisponibilidad. Los bloqueos cancelados se conservan con `active=false`. Los diseños se archivan y las prendas se retiran, sin eliminar historial financiero o físico.

## Concurrencia

Cada confirmación ejecuta una transacción `Serializable`. Lee todas las variantes y los componentes, construye un grafo de candidatos disponibles y encuentra un emparejamiento de unidades para la solicitud completa. Una unidad solo aparece una vez en el plan. Después crea asignaciones y bloqueos.

La restricción `no_unit_overlap` en PostgreSQL excluye para una misma unidad cualquier par de `tstzrange(startsAt, endsAt, '[)')` activo que se solape. `endsAt=NULL` es un final abierto. GiST y `btree_gist` permiten esa exclusión. El intervalo de entrega y el de devolución pueden ser adyacentes. El servidor reintenta hasta tres conflictos de serialización; si no hay solución disponible devuelve 409.

No reemplazar las migraciones con `db push`: Prisma no representa la exclusión GiST en su DSL. El SQL de `prisma/migrations` contiene también CHECK de fechas, importes, cantidades y medidas, y los índices de texto/trigramas. Se verificó una instalación sobre una base de pruebas nueva.

## Tiempo, dinero y operación

Instantes en `timestamptz(3)` y REST ISO 8601 con desplazamiento explícito. La interfaz interpreta los campos datetime-local como hora de Bogotá usando `-05:00`, independientemente de la zona del navegador. COP se guarda como enteros, sin números flotantes para dinero.

Una prenda entregada y vencida se excluye de nuevas asignaciones hasta registrar su devolución. Una reserva futura ya confirmada puede verse afectada por el retraso; no se reasigna silenciosamente. No se permite entregarla mientras la unidad siga en otro alquiler o no esté lista. Las prórrogas se someten a la restricción de exclusión.

Al devolver, se liberan los bloqueos de alquiler y la unidad pasa a limpieza/reparación. El nuevo bloqueo de revisión termina al inicio de la próxima reserva, si existe, y el estado físico continúa impidiendo entregar la prenda hasta terminar la revisión. Si la próxima reserva ya empezó, se guarda el movimiento de revisión como histórico inactivo para no violar su bloqueo; el estado físico continúa bloqueando la operación y debe resolverse manualmente.

## Seguridad

- Contraseñas bcrypt coste 12; token de sesión aleatorio de 256 bits. Solo su SHA-256 se almacena en PostgreSQL.
- Cookie HttpOnly, SameSite Strict, ocho horas; Secure bajo `NODE_ENV=production`. Logout elimina la sesión del servidor.
- Guard administrativo para inventario, datos de clientes, reservas, importación, imágenes y pagos.
- Validación estricta Zod, límites de cadenas/listas y rechazo de campos inesperados.
- Comprobación de origen para mutaciones y rechazo de mutaciones autenticadas sin Origin. Las aplicaciones REST deben enviar el origen configurado.
- Límites de solicitudes/login y cabeceras Helmet en la API. La API escucha solo loopback por defecto.
- Imágenes hasta 5 MB y 20 megapíxeles; solo JPEG/PNG/WebP, decodificación real, orientación y recodificación a WebP con nombre aleatorio. SVG subido por usuarios no se acepta.
- XLSX hasta 2 MB comprimidos, 20 MB descomprimidos, 1000 entradas ZIP y 500 filas. Verifica metadatos ZIP y descomprime con límite antes de ExcelJS. Se rechazan fórmulas, hipervínculos y objetos de celda.
- Auditoría transaccional para operaciones críticas y auditoría general de mutaciones administrativas exitosas. Sin contraseñas ni cuerpos de formularios en el log.
- `.env`, sesiones, resultados de pruebas e imágenes subidas están excluidos de Git.

Las dependencias de producción se auditaron y sus versiones se fijaron en el lockfile. Las sustituciones transitivas de Multer, js-yaml, uuid y deepmerge-ts eliminan avisos conocidos y están cubiertas por las pruebas de arranque, Swagger, importación y carga de archivos. Deben revisarse al actualizar sus paquetes principales.
