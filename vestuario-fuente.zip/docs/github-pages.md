# Publicar el catálogo

Destino solicitado: `Alquiler-Trajes/Alquiler-Trajes`.
Dirección prevista: `https://alquiler-trajes.github.io/Alquiler-Trajes/`.

## Contacto por Instagram y textos simplificados · 29 de octubre de 2026

El inicio conserva las tres tarjetas con carruseles de Danzas y cultura, Disfraces y Accesorios. Se redujeron los textos de presentación y se eliminaron eslóganes e instrucciones repetidas. El botón «Escríbenos» abre `https://ig.me/m/alquileresbga`; el pie de página enlaza al perfil como alternativa. En «Mi selección», «Copiar y abrir Instagram» copia nombres, tallas, colores y cantidades para pegarlos en el chat. Se conservan copiar, descargar y ver el resumen. El sitio no envía mensajes automáticamente ni confirma reservas.

Validación de esta actualización: tipos y compilación estática correctos; comprobación en navegador de las colecciones, juego de seis, copia del resumen y apertura del chat correcto. Se conserva la cobertura de los carruseles y se añadió una comprobación de consulta por Instagram. No se modificó el inventario ni el Excel.

## Princesas dentro de Disfraces · 29 de octubre de 2026

El [despliegue 40905872884](https://github.com/Alquiler-Trajes/Alquiler-Trajes/actions/runs/40905872884) terminó correctamente, revisión remota `96a789582bd5a105d25427461ea7630568226536`. La tarjeta central se llama Disfraces y reúne 19 trajes: ocho princesas, cuatro profesiones y siete personajes, incluidos piratas. Danzas y cultura conserva 15 modelos y Accesorios 14 ofertas. Las fotos de princesa se trasladaron al carrusel central. Verificado en el navegador público.

Fuente local `97948a0755883f7492e83d7faff300e4b13d42aa`; SHA256 `8d92b7ce1dd66e7897a1051486bcf6ad041d67997f523b3827c97336b4a77ae4`. Tipos, compilación, 24 pruebas unitarias, 26 de integración y 14 de navegador aprobados.

## Inicio con carruseles publicado el 29 de octubre de 2026

El [despliegue 40903916053](https://github.com/Alquiler-Trajes/Alquiler-Trajes/actions/runs/40903916053) terminó correctamente, revisión remota `f9581612ddb4bac13f435633d5d300651c4c4104`. Se verificaron en la página pública las tres tarjetas con carruseles, Danzas y cultura con 23 trajes (incluidos Michael Jackson, Caballero años 20 y Oficial de época) y el acceso destacado a los 14 accesorios. Profesiones y disfraces reúne los otros 11 trajes. Detalles en [inicio-colecciones.md](inicio-colecciones.md).

Fuente local `bf63a1fc019f8dff827ce66949785c9ab01a795f`, SHA256 del paquete `ec8a709ab26ac48f0ad96210b407ce88727063ce842ad28916e6b316723ee56c`. Se publicaron juntos compilación, checksum, copia de fuentes y README de entrega. La cuenta y el método de despliegue se conservaron.

## Primera publicación verificada el 28 de octubre de 2026

Sitio público: **https://alquiler-trajes.github.io/Alquiler-Trajes/**.

GitHub Actions completó correctamente el [despliegue 40800739683](https://github.com/Alquiler-Trajes/Alquiler-Trajes/actions/runs/40800739683), revisión `3aa517ed4f4895c613ab0e5c262d81c626b3f39b`. La portada devuelve HTTP 200. El repositorio se hizo público para habilitar GitHub Pages gratuito, con origen GitHub Actions y HTTPS obligatorio.

La sesión disponible para publicar fue la del navegador. El repositorio remoto contiene `github-pages-listo.zip`, `vestuario-fuente.zip`, un README de entrega y el flujo de despliegue. El flujo remoto verifica el SHA-256 y extrae la compilación ya probada; esta copia local conserva el código fuente desarrollado y su flujo de compilación desde código. Las historias Git local y remota son distintas: no hacer push forzado ni sustituir la entrega remota sin conservar sus archivos.

Para actualizar desde esta modalidad, reemplazar juntos el ZIP compilado y `github-pages.sha256` en el remoto. El flujo comprueba esa suma antes de desplegar y mantiene compatibilidad con la primera entrega. El ZIP de código fuente es una instantánea de la entrega; las credenciales de la terminal continúan asociadas a otra cuenta y no se cambiaron.

El repositorio actual genera un sitio de proyecto, por eso incluye `/Alquiler-Trajes/` en la dirección. Una dirección sin esa ruta requiere un repositorio llamado `Alquiler-Trajes.github.io` y compilar con `NEXT_PUBLIC_BASE_PATH` vacío.

## Rediseño publicado el 28 de octubre de 2026

El [despliegue 40804292401](https://github.com/Alquiler-Trajes/Alquiler-Trajes/actions/runs/40804292401) terminó correctamente, revisión remota `502131c8f9b0fcb27a96615514b27fd55b68ba48`. La portada pública responde HTTP 200 y muestra las dos colecciones. Se comprobó en el navegador el orden culturales/princesas (20 modelos) y profesiones/disfraces (8), y se dejó abierto el nuevo inicio.

El paquete corresponde a los fuentes locales de la revisión `91ff480c0f32de17858bf1c380e8f82b11f66814`, con 70 pruebas aprobadas. SHA-256 de `github-pages-listo.zip`: `5f3ee2dd42de26dc8a517b749a331e7f3eceb5dd3e0399b22828eeffb2230186`. El mismo valor figura en `github-pages.sha256` del remoto.

## Preparación realizada

- 28 modelos y 261 variantes comerciales en una instantánea pública revisada.
- 40 imágenes: 27 presentaciones de estudio, una referencia de Spider-Man y doce juegos x6.
- Filtros por categoría, danza o región, talla, color y búsqueda en español.
- Inicio con dos colecciones: Danzas y princesas (20 modelos), y Profesiones y disfraces (8).
- Orden fijo: culturales, princesas, profesiones y disfraces; dos fotos por fila, y una por fila en pantallas de 320 px para mantener la lectura.
- Galería ampliable; un selector «1 traje / Juego de 6» actualiza el formato y su fotografía.
- Navegación Inicio/Mis trajes, filtros y detalles plegados, texto legible y movimiento reducido.
- Selección x1/x6, agrupación del juego, conservación en el navegador, copiar y descargar resumen.
- Precios pendientes indicados como tarifa por confirmar.
- El catálogo público no ofrece confirmación automática de disponibilidad ni registra reservas.
- El panel privado no se ofrece en la página estática. Sus rutas muestran una explicación sin pedir credenciales.
- Se excluyen `.env`, originales con rostros/conversaciones, copias de seguridad, datos de clientes, reservas, movimientos y códigos físicos de prendas.

## Configuración de GitHub Pages

Con acceso de escritura al repositorio:

1. Subir la versión preparada al repositorio solicitado. No subir `.env`, `uploads`, `Multimedia_Adjunta` ni `.runtime`.
2. En **Settings → Pages → Build and deployment**, seleccionar **GitHub Actions** como origen.
3. El flujo **Publicar catálogo en GitHub Pages** se ejecuta en cada push a `main` o `master`; también puede iniciarse con **Run workflow**.
4. Esperar a que el trabajo `deploy` termine correctamente y abrir la dirección informada por GitHub. Una compilación local correcta no confirma publicación.

GitHub Free permite Pages en repositorios públicos. Si el repositorio es privado, requiere un plan compatible o cambiar su visibilidad desde la cuenta propietaria.

## Actualizar modelos, fotos o contacto

Desde la aplicación local y con PostgreSQL iniciado:

```powershell
pnpm pages:snapshot
pnpm pages:build
pnpm pages:test
```

Revisar `apps/web/public/data/catalog.json` y `apps/web/public/media`, luego subir los cambios. La instantánea permite que GitHub compile sin conectarse a tu equipo ni a la base privada. El script copia únicamente imágenes revisadas de las fichas públicas.

Para incorporar el botón de WhatsApp, completar el número real del negocio en `WHATSAPP_NUMBER` dentro de `.env`, regenerar la instantánea y publicar. `.env` sigue siendo privado. Mientras no exista un número, se ofrecen copiar y descargar el resumen.

Si se cambia el nombre del repositorio, ajustar la ruta de compilación `NEXT_PUBLIC_BASE_PATH`. Las reservas en línea, los pagos y la administración remota requieren desplegar la API y PostgreSQL en un servicio aparte y conectar el dominio público a ese servicio.

Referencias: [GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages), [flujos de publicación](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages), [exportación estática de Next.js](https://nextjs.org/docs/app/guides/static-exports).
