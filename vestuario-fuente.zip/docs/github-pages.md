# Publicar el catálogo

Destino solicitado: `Alquiler-Trajes/Alquiler-Trajes`.
Dirección prevista: `https://alquiler-trajes.github.io/Alquiler-Trajes/`.

El repositorio actual genera un sitio de proyecto, por eso incluye `/Alquiler-Trajes/` en la dirección. Una dirección sin esa ruta requiere un repositorio llamado `Alquiler-Trajes.github.io` y compilar con `NEXT_PUBLIC_BASE_PATH` vacío.

## Preparación realizada

- 28 modelos y 261 variantes comerciales en una instantánea pública revisada.
- 40 imágenes: 27 presentaciones de estudio, una referencia de Spider-Man y doce juegos x6.
- Filtros por categoría, danza o región, talla, color y búsqueda en español.
- Galería ampliable; cambiar de foto no cambia el formato de alquiler.
- Selección x1/x6, agrupación del juego, conservación en el navegador, copiar y descargar resumen.
- Precios pendientes indicados como tarifa por confirmar.
- El catálogo público no ofrece confirmación automática de disponibilidad ni registra reservas.
- El panel privado no se ofrece en la página estática. Sus rutas muestran una explicación sin pedir credenciales.
- Se excluyen `.env`, originales con rostros/conversaciones, copias de seguridad, datos de clientes, reservas, movimientos y códigos físicos de prendas.

## Activar GitHub Pages

Con acceso de escritura al repositorio:

1. Subir la versión preparada al repositorio solicitado. No subir `.env`, `uploads`, `Multimedia_Adjunta` ni `.runtime`.
2. En **Settings → Pages → Build and deployment**, seleccionar **GitHub Actions** como origen.
3. El flujo **Publicar catálogo en GitHub Pages** se ejecuta en cada push a `main` o `master`; también puede iniciarse con **Run workflow**.
4. Esperar a que el trabajo `deploy` termine correctamente y abrir la dirección informada por GitHub. Una compilación local correcta no confirma publicación.

GitHub Free permite Pages en repositorios públicos. Si el repositorio es privado, requiere un plan compatible o cambiar su visibilidad desde la cuenta propietaria.

## Actualizar modelos, fotos o contacto

Desde la aplicación local y con PostgreSQL iniciado:

```powershell
pnpm pages:snapshot
pnpm pages:build
pnpm pages:test
```

Revisar `apps/web/public/data/catalog.json` y `apps/web/public/media`, luego subir los cambios. La instantánea permite que GitHub compile sin conectarse a tu equipo ni a la base privada. El script copia únicamente imágenes revisadas de las fichas públicas.

Para incorporar el botón de WhatsApp, completar el número real del negocio en `WHATSAPP_NUMBER` dentro de `.env`, regenerar la instantánea y publicar. `.env` sigue siendo privado. Mientras no exista un número, se ofrecen copiar y descargar el resumen.

Si se cambia el nombre del repositorio, ajustar la ruta de compilación `NEXT_PUBLIC_BASE_PATH`. Las reservas en línea, los pagos y la administración remota requieren desplegar la API y PostgreSQL en un servicio aparte y conectar el dominio público a ese servicio.

Referencias: [GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages), [flujos de publicación](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages), [exportación estática de Next.js](https://nextjs.org/docs/app/guides/static-exports).
