# Inventario de la colección real

Actualizado el 28 de octubre de 2026 según las cantidades confirmadas por el negocio.

## Colección cultural

Hay **12 modelos culturales y 72 unidades listas**. Cada modelo tiene seis unidades físicas independientes:

- Nueve modelos de niña: **3 S + 3 M**, destinados a niñas de 6.º y 7.º grado.
- Tres modelos de niño: **6 talla Niño**, sin desglose adicional de talla.
- Las opciones de color comparten las seis existencias del modelo. La combinación exacta de colores se confirma con el negocio; no representa seis prendas de cada color.
- Se puede solicitar **x1** o **juego x6**. El juego conserva la distribución escolar; no crea una talla ficticia ni duplica stock.
- El importe del juego es la suma de sus seis tarifas unitarias. No se aplicó un descuento no indicado.

La categoría se llama **Trajes culturales**. Se agrupa por tricolor, campesinos y estampados, faldas y volantes, blancos y tropicales, y camisas y conjuntos.

El campo **Danza o estilo** se edita en Administración → Inventario → Gestionar. Se aplicaron las etiquetas de la captura del negocio: Cumbia, Bambuco, Carranga, región pacífica y región cafetera. Los modelos masculinos presentes en más de una presentación conservan ambas etiquetas. Blanco tricolor y faldas satinadas tienen una clasificación provisional de Cumbia, autorizada por el negocio al no poder identificar las dos fotos del mensaje sin miniaturas. La ficha señala esta condición. Fuente y correspondencias: docs/etiquetas-culturales.json.

## Resto del vestuario y accesorios

Los otros 16 modelos de prendas conservan las tallas de la primera carga: infantiles 2–16 y XS–XXL, con una unidad por talla. En total hay **28 modelos públicos, 261 variantes públicas y 296 unidades listas**: 224 de esta colección y 72 culturales.

Los accesorios correspondientes se incluyen con el traje. Desde el 29/10/2026 también se ofrecen **ocho kits y una peineta por separado**. Los kits se presentan en Accesorios. Piloto también aparece como traje completo en Profesiones: el negocio confirmó camisa y pantalón, además de gorra, corbata, charreteras e insignia. Su foto actual muestra el kit y se identifica expresamente como tal.

Hay **38 ofertas públicas: 29 trajes y 9 accesorios/kits**. Las 296 unidades anteriores se conservan. No se inventaron cantidades ni tallas de los accesorios o del nuevo uniforme de piloto; se muestran por confirmar. El piloto completo y su kit utilizan las mismas variantes físicas de accesorios. Pirata aventurera comparte sus accesorios con el kit pirata; el motor de reservas evita asignar esas piezas dos veces. Las cantidades antiguas archivadas no se reactivaron.

El Excel local `outputs/inventario-2026-10-29/Inventario_Vestuario.xlsx` incluye Inventario, Tallas, Accesorios y Kits, con fotos incorporadas. Registra 64 tipos de accesorios, incluidos los descritos con cada traje. Las cantidades desconocidas quedan vacías, no en cero. Los campos amarillos se pueden completar; los totales por modelo y la capacidad de los kits se calculan con fórmulas. Las fotos de piezas sin toma individual muestran su traje o kit de referencia y se explican en Observaciones. El Excel se mantiene privado y no se sincroniza automáticamente con la web. Conservar las ediciones manuales al incorporar nuevas fotos.

Se retiraron administrativamente 759 unidades que respondían a las suposiciones de la carga inicial. Sus códigos e historial se conservaron. Las variantes antiguas están archivadas y pueden consultarse activando la opción correspondiente.

## Fotografías

Se prepararon **27 versiones de estudio** mediante la herramienta integrada image_gen: fondo uniforme, iluminación de catálogo, prendas sin personas y eliminación de anuncios o marcas de comercio. Las fichas explican que son ediciones con IA basadas en las referencias aportadas.

Spider-Man conserva su referencia recortada e identificada: la herramienta rechazó dos intentos de edición. El pendiente consta en fotos-estudio-pendientes.json.

Los originales permanecen intactos en Multimedia_Adjunta y su carpeta 2. Las nuevas copias están en Multimedia_Adjunta/Estudio; el catálogo sirve derivados WebP desde uploads. Las nueve ediciones anteriores con rostros anonimizados permanecen como archivo, pero las fichas culturales usan las nuevas presentaciones de estudio.

Fuentes, prompts, archivos y hashes: docs/fotos-estudio.json. Plan inicial: docs/plan-fotos-estudio.json.

Los doce modelos culturales disponen además de una **vista del juego completo x6**, generada con image_gen y revisada para contener exactamente seis trajes, sin personas ni anuncios. Se puede alternar entre modelo y juego, ampliar la fotografía y abrirla a tamaño completo. Elegir el alquiler x6 muestra automáticamente esa vista; cambiar únicamente la fotografía no cambia el formato de alquiler.

Son composiciones de referencia, con colores sujetos a confirmación; la distribución mostrada por color no representa cantidades nuevas de inventario. Las 72 existencias culturales se conservan. Maestros: Multimedia_Adjunta/Estudio/Juegos. Fuentes, prompts y hashes: docs/fotos-juegos.json.

## Precios y ajuste

No se usaron los precios de compra de Temu como tarifas de alquiler. La colección sigue mostrando **Precio por definir** y el servidor bloquea solicitudes hasta registrar tarifas. Se pueden aplicar a todas las tallas activas de un modelo desde Gestionar.

No se inventaron medidas a partir de edades o tallas. S y M son etiquetas escolares, no una verificación de ajuste.

## Trazabilidad

- scripts/cultural-policy.ts y apply-cultural-policy.ts: corrección inicial, transaccional e idempotente, con copia local previa y auditoría CULTURAL_POLICY.
- scripts/import-real-inventory.ts: conserva la política aplicada y evita reinstalar cantidades o fotos antiguas al repetir la carga.
- scripts/publish-studio-photos.ts: instala las imágenes de estudio y conserva originales.
- scripts/label-cultural-collection.ts: aplica las etiquetas de la captura una sola vez, con copia y auditoría; conserva cambios posteriores.
- scripts/publish-bundle-photos.ts: instala las fotografías de juegos en el campo bundleImage, independiente de las fotos del modelo.
- scripts/audit-current-inventory.ts: verifica cantidades, tallas, inventario compartido por color, disponibilidad combinada y URL de fotografías sin crear reservas.
- docs/inventario-real.json: instantánea verificada de la colección actual.
- .runtime/backups: copias locales ignoradas por Git.

Los 13 diseños de demostración se conservan separados de la colección actual.
