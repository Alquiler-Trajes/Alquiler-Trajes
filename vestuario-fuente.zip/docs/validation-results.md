# Resultados de validación

Verificación: 28 de octubre de 2026, America/Bogota.

- Prisma generado y migraciones aplicadas, incluida la exclusión GiST existente y los campos danceStyle, includedAccessories, bundleSize y bundleImage.
- pnpm typecheck: correcto en los tres paquetes.
- pnpm test: 22 pruebas unitarias aprobadas.
- pnpm test:integration: 25 pruebas aprobadas con API y PostgreSQL reales.
- pnpm test:e2e: 14 pruebas aprobadas, siete flujos en escritorio y los mismos siete en móvil.
- Total: **61 pruebas automatizadas**.
- pnpm build: compilación de producción de shared, API y web correcta. La aplicación se dejó ejecutando con su servidor local habitual en 127.0.0.1:3000.

La prueba nueva de integración confirma un juego de 3 S + 3 M, comprueba seis asignaciones distintas y demuestra que otro color no puede reutilizar esas prendas en las mismas fechas. Los accesorios descriptivos no requieren unidades ni bloqueos separados. También verifica guardar y leer la etiqueta de danza.

La prueba de navegador consulta disponibilidad combinada, agrega x1 y x6, conserva las tallas del juego, muestra el paquete como una sola tarjeta, permite quitar el juego completo y combina cantidades de variantes repetidas antes de enviar la solicitud. También verifica los filtros por danza, su conservación al volver al catálogo, la alternancia de fotos sin cambiar el alquiler y la ampliación con cierre mediante Escape. Se ejecuta en escritorio y móvil.

Se mantienen las comprobaciones de concurrencia, exclusión de solapamientos directa en PostgreSQL, conjuntos fijos y flexibles, devolución parcial, limpieza, pagos, importación atómica, autenticación y rechazo de tarifas pendientes.

La auditoría de la colección real comprueba 28 modelos públicos, 12 culturales, 72 unidades culturales listas, doce fotografías de juegos accesibles y las etiquetas culturales. Cada modelo tiene exactamente seis unidades y sus colores comparten inventario. Dos etiquetas se registran como provisionales según autorización del negocio. Las antiguas cantidades supuestas se conservaron como archivo. Véase inventario-real.json.

Se revisaron visualmente las 27 versiones de estudio y su integración en las fichas. Spider-Man conserva su referencia porque image_gen rechazó la edición; no se afirma que esté retocada.

No se crearon alquileres de prueba en la base real. Las pruebas automatizadas usan vestuario_test y puertos 4001/3100.

Las tarifas, el número de WhatsApp y las medidas reales siguen pendientes de aportar por el negocio. Las etiquetas de danza quedaron cargadas y siguen editables.

## Catálogo para GitHub Pages

`pnpm pages:build` genera la exportación de producción con la ruta `/Alquiler-Trajes/`. `pnpm pages:test` aprueba cuatro pruebas adicionales en escritorio y móvil: búsqueda y filtros por danza, navegación, foto x6 ampliable, selección agrupada, conservación tras recargar, descarga del resumen, ausencia de llamadas a una API inexistente, las 28 rutas de producto y las 40 imágenes públicas. El total con estas pruebas es **65**.

La exportación contiene solo fichas comerciales y fotos revisadas; no contiene calendarios, clientes, credenciales ni códigos físicos de las unidades. El servidor local conserva toda la funcionalidad de inventario y alquiler. PostgreSQL usa ahora el puerto configurable 15432 para evitar una reserva de puertos de Windows.

La publicación externa requiere acceso a `Alquiler-Trajes/Alquiler-Trajes`: el repositorio respondió 404 con la sesión disponible y el navegador solicitó iniciar sesión. No se presenta la dirección prevista como un sitio ya publicado.
