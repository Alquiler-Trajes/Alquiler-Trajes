# Resultados de validación

## Actualización del inicio · 29 de octubre de 2026

Tipos y compilación de Pages correctos; 24 pruebas unitarias, 26 de integración y 14 de navegador aprobadas. La agrupación actual es 15 trajes en Danzas y cultura, 19 en Disfraces y 14 accesorios. Las ocho princesas y sus fotos de portada se trasladaron a la colección central de Disfraces, junto a profesiones y piratas. La revisión visual comprobó títulos encima de las fotos, carruseles con pausa y acceso destacado a Accesorios en escritorio y móvil. Detalles en [inicio-colecciones.md](inicio-colecciones.md).

Los resultados siguientes documentan entregas anteriores.

Verificación: 28 de octubre de 2026, America/Bogota.

- Prisma generado y migraciones aplicadas, incluida la exclusión GiST existente y los campos danceStyle, includedAccessories, bundleSize y bundleImage.
- pnpm typecheck: correcto en los tres paquetes.
- pnpm test: 22 pruebas unitarias aprobadas.
- pnpm test:integration: 26 pruebas aprobadas con API y PostgreSQL reales.
- pnpm test:e2e: 14 pruebas aprobadas, siete flujos en escritorio y los mismos siete en móvil.
- pnpm pages:test: ocho pruebas aprobadas, cuatro recorridos en escritorio y los mismos cuatro en móvil.
- Total: **70 pruebas automatizadas** (22 + 26 + 14 + 8).
- pnpm build: compilación de producción de shared, API y web correcta. La aplicación se dejó ejecutando con su servidor local habitual en 127.0.0.1:3000.

La prueba nueva de integración confirma un juego de 3 S + 3 M, comprueba seis asignaciones distintas y demuestra que otro color no puede reutilizar esas prendas en las mismas fechas. Los accesorios descriptivos no requieren unidades ni bloqueos separados. También verifica guardar y leer la etiqueta de danza.

La prueba de navegador consulta disponibilidad combinada, agrega x1 y x6, conserva las tallas del juego, muestra el paquete como una sola tarjeta, permite quitar el juego completo y combina cantidades de variantes repetidas antes de enviar la solicitud. También verifica los filtros por danza, su conservación al volver al catálogo, el selector único que actualiza formato y foto, y la ampliación con cierre mediante Escape. Se ejecuta en escritorio y móvil. La comprobación responsive se repitió correctamente con una búsqueda aislada para que los modelos acumulados de otras pruebas no alteren la paginación.

Se mantienen las comprobaciones de concurrencia, exclusión de solapamientos directa en PostgreSQL, conjuntos fijos y flexibles, devolución parcial, limpieza, pagos, importación atómica, autenticación y rechazo de tarifas pendientes.

La auditoría de la colección real comprueba 28 modelos públicos, 12 culturales, 72 unidades culturales listas, doce fotografías de juegos accesibles y las etiquetas culturales. Cada modelo tiene exactamente seis unidades y sus colores comparten inventario. Dos etiquetas se registran como provisionales según autorización del negocio. Las antiguas cantidades supuestas se conservaron como archivo. Véase inventario-real.json.

Se revisaron visualmente las 27 versiones de estudio y su integración en las fichas. Spider-Man conserva su referencia porque image_gen rechazó la edición; no se afirma que esté retocada.

No se crearon alquileres de prueba en la base real. Las pruebas automatizadas usan vestuario_test y puertos 4001/3100.

Las tarifas, el número de WhatsApp y las medidas reales siguen pendientes de aportar por el negocio. Las etiquetas de danza quedaron cargadas y siguen editables.

## Catálogo para GitHub Pages

`pnpm pages:build` genera la exportación de producción con la ruta `/Alquiler-Trajes/`. `pnpm pages:test` aprueba ocho pruebas en escritorio y móvil: inicio con dos colecciones, orden culturales/princesas/profesiones/disfraces, fotos en parejas, filtros plegados, navegación con teclado, movimiento reducido, pantalla de 320 px, carga de más resultados, selector x1/x6 y galería ampliable, selección agrupada, conservación tras recargar, descarga del resumen, ausencia de llamadas a una API inexistente, las 28 rutas de producto y las 40 imágenes públicas.

La exportación contiene solo fichas comerciales y fotos revisadas; no contiene calendarios, clientes, credenciales ni códigos físicos de las unidades. El servidor local conserva toda la funcionalidad de inventario y alquiler. PostgreSQL usa ahora el puerto configurable 15432 para evitar una reserva de puertos de Windows.

La publicación externa se completó con la sesión de GitHub del navegador. GitHub Actions aprobó el despliegue 40800739683 de la revisión 3aa517ed4f4895c613ab0e5c262d81c626b3f39b. La portada pública https://alquiler-trajes.github.io/Alquiler-Trajes/ responde HTTP 200. El repositorio es público, Pages usa GitHub Actions y HTTPS está habilitado. El remoto contiene la entrega empaquetada y una copia del código fuente; esta copia local conserva los fuentes desarrollados.

La comprobación posterior en el dominio público validó las 28 rutas de producto y las 40 imágenes (68 recursos, sin fallos), incluidos los doce juegos de seis. También se revisó la portada publicada y la navegación de la galería en el navegador.

El rediseño posterior quedó publicado mediante el despliegue 40804292401, revisión remota 502131c8f9b0fcb27a96615514b27fd55b68ba48. Se verificó HTTP 200 con las dos entradas en el HTML y la navegación pública de ambas colecciones: 20 modelos en culturales/princesas y 8 en profesiones/disfraces, con los encabezados en el orden solicitado. El checksum publicado coincide con el paquete validado localmente.
