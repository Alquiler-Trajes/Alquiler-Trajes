import dotenv from "dotenv";
import { PrismaClient } from "@prisma/client";
import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import sharp from "../apps/api/node_modules/sharp";
import { assets, collectionTag, componentTag, looks, pieces, sizes } from "./real-collection";
import { folkCategories } from "./folk-collection";
import { applyCulturalPolicy, policyId } from "./cultural-policy";

dotenv.config({ quiet: true });
const db = new PrismaClient();
const sourceDir = path.resolve("Multimedia_Adjunta");
const uploadDir = path.resolve(process.env.UPLOAD_DIR || "uploads");
const imageUrls = new Map<string, string>();
const batch = "real-2026-10-28";

async function main() {
  if (await db.auditLog.findFirst({ where: { action: "CULTURAL_POLICY", entityId: policyId } })) {
    console.log("La política cultural de seis unidades ya está aplicada. Se conserva el inventario y las fotografías actuales.");
    return;
  }
  // Verify every original before writing to the database. Originals remain intact.
  await mkdir(uploadDir, { recursive: true });
  for (const [key, asset] of Object.entries(assets)) {
    const bytes = await readFile(path.join(sourceDir, asset.file));
    const pipeline = sharp(bytes).rotate();
    if (asset.crop) {
      const m = await sharp(bytes).metadata();
      const [x, y, width, height] = asset.crop;
      pipeline.extract({ left: Math.round(x * m.width!), top: Math.round(y * m.height!), width: Math.floor(width * m.width!), height: Math.floor(height * m.height!) });
    }
    const image = await pipeline.resize(1200, 1600, { fit: "inside", withoutEnlargement: true }).webp({ quality: 88 }).toBuffer();
    const hash = createHash("sha256").update(image).digest("hex").slice(0, 12);
    const filename = `${asset.edited ? batch : "real-2026-10-27"}-${key}-${hash}.webp`;
    await writeFile(path.join(uploadDir, filename), image);
    imageUrls.set(key, `/uploads/${filename}`);
  }
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const backupDir = path.resolve(".runtime/backups");
  await mkdir(backupDir, { recursive: true });
  const before = await db.costume.findMany({ include: { variants: { include: { units: { include: { measurements: true } }, outfit: { include: { components: { include: { options: true } } } } } } } });
  await writeFile(path.join(backupDir, `before-${batch}-${stamp}.json`), JSON.stringify({ recordedAt: new Date(), categories: await db.category.findMany(), inventory: before }, null, 2));

  const created = { models: 0, pieces: 0, variants: 0, units: 0, outfits: 0 };
  await db.$transaction(async (tx) => {
    const categories = new Map<string, string>();
    const defs = [
      ...folkCategories,
      ["fantasia", "Fantasía", null], ["hadas", "Hadas", "fantasia"],
      ["princesas", "Princesas", "fantasia"], ["superheroes", "Superhéroes", "fantasia"],
      ["personajes", "Personajes de época", null], ["piratas", "Piratas", "personajes"],
      ["epocas", "Años 20", "personajes"], ["profesiones", "Profesiones", null],
      ["fiesta", "Fiesta tropical", null], ["baile", "Baile y escenario", null],
      ["accesorios", "Accesorios", null],
    ] as const;
    for (const [slug, name, parent] of defs) {
      const existing = await tx.category.findFirst({ where: { OR: [{ slug }, { name }] } });
      const row = existing
        ? await tx.category.update({ where: { id: existing.id }, data: { parentId: parent ? categories.get(parent) : null } })
        : await tx.category.create({ data: { slug, name, parentId: parent ? categories.get(parent) : null } });
      categories.set(slug, row.id);
    }
    const variantIds = new Map<string, string>();
    for (const piece of pieces) {
      const slug = `real-pieza-${piece.key}`;
      let model = await tx.costume.findUnique({ where: { slug } });
      if (!model) {
        model = await tx.costume.create({ data: {
          slug, name: piece.name, categoryId: categories.get(piece.category || "accesorios")!,
          description: `${piece.name}. ${piece.note || "Pieza física vinculada a los conjuntos del inventario."}`,
          images: [imageUrls.get(piece.asset)!],
          tags: [collectionTag, ...(piece.public ? [] : [componentTag]), ...(assets[piece.asset].real ? ["foto-del-taller"] : ["foto-referencia"]), ...(assets[piece.asset].edited ? ["foto-retocada", "rostros-anonimizados"] : [])],
          searchTerms: `${piece.name} ${piece.color}`, requiredMetrics: piece.sized ? ["chest", "waist"] : [],
          demo: false, active: true,
        } });
        created.pieces++;
      }
      for (const size of piece.sized ? sizes : ["Única"]) {
        let v = await tx.variant.findUnique({ where: { costumeId_size_color: { costumeId: model.id, size, color: piece.color } } });
        if (!v) {
          v = await tx.variant.create({ data: { costumeId: model.id, size, color: piece.color, price: 0 } });
          created.variants++;
        }
        variantIds.set(`${piece.key}:${size}`, v.id);
        const code = `REAL-${piece.key.toUpperCase()}-${size === "Única" ? "UNI" : size}-001`;
        if (!(await tx.unit.findUnique({ where: { code } }))) {
          await tx.unit.create({ data: {
            code, variantId: v.id, state: "READY", location: `Colección real · ${piece.category || "piezas y accesorios"}`,
            images: assets[piece.asset].real ? [imageUrls.get(piece.asset)!] : [],
            notes: `Carga inicial solicitada por el negocio: una unidad por talla, todas listas. Fuente: ${assets[piece.asset].originalFile || assets[piece.asset].file}. Precio de alquiler y medidas pendientes de registrar. ${piece.note || ""}`,
            movements: { create: { type: "READY", detail: "Alta de inventario real: tallas listas por instrucción del negocio." } },
          } });
          created.units++;
        }
      }
    }
    for (const look of looks) {
      const slug = `real-${look.key}`;
      let model = await tx.costume.findUnique({ where: { slug } });
      if (!model) {
        model = await tx.costume.create({ data: {
          slug, name: look.name, description: look.description,
          categoryId: categories.get(look.category)!, tags: [collectionTag, "conjunto", ...(look.tags || []), ...(assets[look.asset].real ? ["foto-del-taller"] : ["foto-referencia"]), ...(assets[look.asset].edited ? ["foto-retocada", "rostros-anonimizados"] : [])],
          searchTerms: `${look.name} ${(look.tags || []).join(" ")} ${look.color} ${[...look.pieces, ...(look.colorways || []).flatMap(c => c.pieces)].map(p => pieces.find(x => x.key === (typeof p === "string" ? p : p.key))!.name).join(" ")}`,
          requiredMetrics: [], images: [look.asset, ...(look.gallery || [])].map(k => imageUrls.get(k)!),
          demo: false, active: true, featured: !!look.featured,
        } });
        created.models++;
      }
      for (const colorway of look.colorways || [{ color: look.color, pieces: look.pieces }]) {
      for (const size of look.oneSize ? ["Única"] : sizes) {
        let v = await tx.variant.findUnique({ where: { costumeId_size_color: { costumeId: model.id, size, color: colorway.color } } });
        if (!v) {
          v = await tx.variant.create({ data: { costumeId: model.id, size, color: colorway.color, price: 0 } });
          created.variants++;
        }
        if (!(await tx.outfit.findUnique({ where: { variantId: v.id } }))) {
          await tx.outfit.create({ data: {
            variantId: v.id, mode: "FLEXIBLE",
            components: { create: colorway.pieces.map(p => {
              const c = typeof p === "string" ? { key: p } : p;
              const def = pieces.find(x => x.key === c.key)!;
              const primary = variantIds.get(`${c.key}:${def.sized ? size : "Única"}`);
              if (!primary) throw new Error(`Falta componente ${c.key}, talla ${size}`);
              return { name: def.name, required: c.required !== false, quantity: 1, variantId: primary,
                allowSubstitution: !!c.alternatives?.length,
                options: { create: (c.alternatives || []).map(key => {
                  const alternative = pieces.find(x => x.key === key)!;
                  const variantId = variantIds.get(`${key}:${alternative.sized ? size : "Única"}`);
                  if (!variantId) throw new Error(`Falta alternativa ${key}, talla ${size}`);
                  return { variantId };
                }) },
              };
            }) },
          } });
          created.outfits++;
        }
      }
      }
    }
    if (Object.values(created).some(Boolean)) await tx.auditLog.create({ data: {
      action: "REAL_INVENTORY_IMPORT", entityId: batch,
      detail: { ...created, sizes, initialUnitsPerSize: 1, instruction: "Todas las tallas listas; agrupar accesorios por traje", pendingRentalPrices: true, measurementsInvented: false },
    } });
  }, { timeout: 120000 });

  const inventory = await db.costume.findMany({ where: { tags: { has: collectionTag } }, include: { variants: { include: { units: true, outfit: { include: { components: true } } } } } });
  const summary = {
    created,
    totals: { looks: looks.length, publicAccessories: pieces.filter(p => p.public).length, physicalPieceModels: pieces.length, variants: inventory.reduce((n, c) => n + c.variants.length, 0), readyUnits: inventory.flatMap(c => c.variants.flatMap(v => v.units)).filter(u => u.state === "READY").length },
    sizes, initialUnitsPerSize: 1,
    pending: ["Precios de alquiler", "Medidas reales"],
    originals: "Multimedia_Adjunta (sin cambios)",
    groups: looks.map(l => ({ name: l.name, sizes: l.oneSize ? ["Única"] : sizes, colors: (l.colorways || [{ color: l.color, pieces: l.pieces }]).map(c => ({ color: c.color, components: c.pieces.map(p => typeof p === "string" ? p : p.key) })) })),
  };
  await mkdir("docs", { recursive: true });
  await writeFile("docs/inventario-real.json", JSON.stringify(summary, null, 2));
  console.log(JSON.stringify({ created, totals: summary.totals, initialUnitsPerSize: 1 }, null, 2));
  await applyCulturalPolicy(db);
}
main().catch(e => { console.error(e.message); process.exitCode = 1; }).finally(() => db.$disconnect());
