import "dotenv/config";
import { PrismaClient } from "@prisma/client";
import { copyFile, mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
const db = new PrismaClient();
const publicDir = path.resolve("apps/web/public");
async function main() {
  const categories = await db.category.findMany();
  const rows = await db.costume.findMany({ where: { active: true, demo: false, tags: { has: "coleccion-real-octubre-2026" }, NOT: { tags: { has: "pieza-de-conjunto" } } }, include: { category: true, variants: { where: { active: true }, include: { outfit: { include: { components: true } } } } } });
  await mkdir(path.join(publicDir, "media"), { recursive: true });
  await mkdir(path.join(publicDir, "data"), { recursive: true });
  const images = new Set<string>();
  const publishImage = async (url: string) => {
    // No arbitrary path, original WhatsApp photo or private upload is published.
    if (!/^\/uploads\/[a-f0-9]{64}\.webp$/.test(url) && url !== "/uploads/real-2026-10-27-spiderman-8ed53dc85648.webp") throw new Error("Imagen pública no validada: " + url);
    const file = path.basename(url);
    await copyFile(path.resolve(process.env.UPLOAD_DIR || "uploads", file), path.join(publicDir, "media", file));
    images.add(file);
    return `/media/${file}`;
  };
  const items = [];
  for (const row of rows) {
    const variants = row.variants.map(v => ({ id: v.id, size: v.size, color: v.color, price: v.price,
      commercialAgeMin: v.commercialAgeMin, commercialAgeMax: v.commercialAgeMax, isOutfit: !!v.outfit,
      outfit: v.outfit ? { mode: v.outfit.mode, components: v.outfit.components.map(c => ({ name: c.name, required: c.required, quantity: c.quantity, allowSubstitution: c.allowSubstitution })) } : null }));
    items.push({ id: row.id, slug: row.slug, name: row.name, description: row.description, danceStyle: row.danceStyle,
      includedAccessories: row.includedAccessories, bundleSize: row.bundleSize,
      bundleImage: row.bundleImage ? await publishImage(row.bundleImage) : null,
      category: { id: row.category.id, name: row.category.name },
      images: await Promise.all(row.images.map(publishImage)), demo: false, featured: row.featured,
      minPrice: Math.min(...variants.map(v => v.price)), tags: row.tags, requiredMetrics: row.requiredMetrics, variants });
  }
  const counted = categories.map(c => {
    const ids = new Set([c.id]);
    for (let i = 0; i < categories.length; i++) for (const child of categories) if (child.parentId && ids.has(child.parentId)) ids.add(child.id);
    return { id: c.id, name: c.name, slug: c.slug, parentId: c.parentId, count: items.filter(item => ids.has(item.category.id)).length };
  }).filter(c => c.count);
  const technical = new Set(["infantiles", "folclor"]);
  const order = ["bailes", "fantasia", "princesas", "personajes", "profesiones", "baile", "fiesta", "accesorios"];
  const navigationCategories = counted.filter(c => !technical.has(c.slug) && (!c.parentId || technical.has(categories.find(parent => parent.id === c.parentId)?.slug || ""))).sort((a, b) => order.indexOf(a.slug) - order.indexOf(b.slug));
  const styles = [...new Set(items.flatMap(item => (item.danceStyle || "").split(" / ").filter(Boolean)))].sort((a, b) => a.localeCompare(b, "es")).map(name => ({ name, count: items.filter(item => item.danceStyle?.split(" / ").includes(name)).length }));
  const phone = (process.env.WHATSAPP_NUMBER || "").replace(/\D/g, "");
  const snapshot = { publishedAt: new Date().toISOString(), items, categories: counted, navigationCategories, styles,
    config: { whatsappUrl: phone ? `https://wa.me/${phone}` : null, timezone: "America/Bogota" } };
  await writeFile(path.join(publicDir, "data/catalog.json"), JSON.stringify(snapshot));
  console.log(`Catálogo público: ${items.length} modelos, ${items.filter(i => i.bundleImage).length} juegos x6 y ${images.size} imágenes. Sin clientes, reservas, credenciales ni códigos de unidades.`);
}
main().catch(error => { console.error(error.message); process.exitCode = 1; }).finally(() => db.$disconnect());
