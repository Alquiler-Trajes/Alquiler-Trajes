import "dotenv/config";
import { PrismaClient } from "@prisma/client";
import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import sharp from "../apps/api/node_modules/sharp";
import { looks } from "./real-collection";
const db = new PrismaClient();
async function main() {
  const manifest = JSON.parse(await readFile("docs/fotos-estudio.json", "utf8")) as { key: string; output: string; sha256?: string; url?: string }[];
  const dir = path.resolve(process.env.UPLOAD_DIR || "uploads");
  await mkdir(dir, { recursive: true });
  const updates = [];
  for (const entry of manifest) {
    const bytes = await readFile(entry.output);
    entry.sha256 = createHash("sha256").update(bytes).digest("hex");
    const webp = await sharp(bytes).resize(1200, 1800, { fit: "inside", withoutEnlargement: true }).webp({ quality: 90 }).toBuffer();
    const filename = createHash("sha256").update(webp).digest("hex") + ".webp";
    await writeFile(path.join(dir, filename), webp);
    entry.url = `/uploads/${filename}`;
    updates.push({ key: entry.key, url: entry.url });
  }
  const backupDir = path.resolve(".runtime/backups");
  await mkdir(backupDir, { recursive: true });
  await writeFile(path.join(backupDir, `before-studio-${Date.now()}.json`), JSON.stringify(await db.costume.findMany({ where: { slug: { startsWith: "real-" } }, select: { id: true, slug: true, images: true, tags: true } }), null, 2));
  await db.$transaction(async tx => {
    for (const entry of updates) {
      const look = looks.find(l => l.key === entry.key)!;
      const model = await tx.costume.findUniqueOrThrow({ where: { slug: `real-${look.key}` } });
      const oldTags = new Set(["foto-retocada", "rostros-anonimizados", "foto-referencia"]);
      const tags = [...new Set([...model.tags.filter(t => !oldTags.has(t)), "foto-estudio-ia"])];
      await tx.costume.update({ where: { id: model.id }, data: { images: [entry.url], tags } });
      const primary = look.pieces[0];
      const slugs = model.bundleSize === 6 ? [`real-pieza-cultural-${look.key}`] : [`real-pieza-${typeof primary === "string" ? primary : primary.key}`];
      await tx.costume.updateMany({ where: { slug: { in: slugs } }, data: { images: [entry.url] } });
      await tx.unit.updateMany({ where: { variant: { costume: { slug: { in: slugs }, active: true } }, state: { not: "RETIRED" } }, data: { images: [entry.url] } });
    }
    await tx.auditLog.create({ data: { action: "STUDIO_PHOTOS", entityId: "october-2026", detail: { count: updates.length, tool: "built-in image_gen", originalsPreserved: true } } });
  }, { timeout: 120000 });
  await writeFile("docs/fotos-estudio.json", JSON.stringify(manifest, null, 2));
  console.log(`${updates.length} fotografías de estudio instaladas. Originales conservados.`);
}
main().catch(e => { console.error(e.message); process.exitCode = 1; }).finally(() => db.$disconnect());
