import { spawnSync } from "node:child_process";
import { access, writeFile } from "node:fs/promises";
await access("apps/web/public/data/catalog.json");
const env = { ...process.env, NEXT_PUBLIC_STATIC_CATALOG: "true", NEXT_PUBLIC_BASE_PATH: process.env.NEXT_PUBLIC_BASE_PATH ?? "/Alquiler-Trajes", NEXT_DIST_DIR: "out" };
const pnpm = process.env.npm_execpath;
if (!pnpm) throw new Error("Ejecuta este script con pnpm pages:build.");
for (const args of [["--filter", "@vestuario/shared", "build"], ["--filter", "@vestuario/web", "build"]]) {
  const result = spawnSync(process.execPath, [pnpm, ...args], { env, stdio: "inherit" });
  if (result.status !== 0) process.exit(result.status || 1);
}
await writeFile("apps/web/out/.nojekyll", "");
console.log("GitHub Pages listo en apps/web/out.");
