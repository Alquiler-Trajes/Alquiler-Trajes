import http from "node:http";
import path from "node:path";
import { readFile, stat } from "node:fs/promises";
const root = path.resolve("apps/web/out");
const prefix = process.env.NEXT_PUBLIC_BASE_PATH ?? "/Alquiler-Trajes";
const types = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css", ".json": "application/json", ".txt": "text/plain; charset=utf-8", ".svg": "image/svg+xml", ".webp": "image/webp", ".png": "image/png", ".ico": "image/x-icon" };
http.createServer(async (req, res) => {
  try {
    const pathname = decodeURIComponent(new URL(req.url, "http://localhost").pathname);
    if (pathname === prefix) { res.writeHead(302, { Location: prefix + "/" }); res.end(); return; }
    if (!pathname.startsWith(prefix + "/")) throw new Error("Not found");
    let file = path.resolve(root, "." + pathname.slice(prefix.length));
    if (file !== root && !file.startsWith(root + path.sep)) throw new Error("Not found");
    if ((await stat(file)).isDirectory()) file = path.join(file, "index.html");
    const bytes = await readFile(file);
    res.writeHead(200, { "Content-Type": types[path.extname(file)] || "application/octet-stream" }); res.end(bytes);
  } catch { res.writeHead(404); res.end("Not found"); }
}).listen(8130, "127.0.0.1", () => console.log(`Catálogo GitHub Pages: http://127.0.0.1:8130${prefix}/`));
