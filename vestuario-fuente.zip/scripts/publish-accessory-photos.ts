import "dotenv/config";
import { PrismaClient } from "@prisma/client";
import { createHash } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import sharp from "../apps/api/node_modules/sharp";
const db=new PrismaClient();
async function main(){
  const entries=JSON.parse(await readFile("docs/fotos-accesorios.json","utf8"));
  for(const e of entries){
    const bytes=await sharp(await readFile(e.master)).resize(1200,1600,{fit:"inside",withoutEnlargement:true}).webp({quality:88}).toBuffer();
    const hash=createHash("sha256").update(bytes).digest("hex");
    await writeFile(path.resolve(process.env.UPLOAD_DIR||"uploads",hash+".webp"),bytes);
    const m=await db.costume.findUniqueOrThrow({where:{slug:e.slug}});
    if(m.tags.includes("foto-estudio-ia") && m.images[0]===`/uploads/${hash}.webp`)continue;
    await db.costume.update({where:{id:m.id},data:{images:[`/uploads/${hash}.webp`],tags:[...new Set([...m.tags,"foto-estudio-ia"])]}});
    await db.auditLog.create({data:{action:"ACCESSORY_STUDIO_PHOTO",entityId:m.id,detail:{source:e.source,master:e.master,hash,tool:e.tool}}});
  }
  console.log("Tres fotos de accesorios actualizadas. Originales y cantidades conservados.");
}
main().catch(e=>{console.error(e.message);process.exitCode=1;}).finally(()=>db.$disconnect());
