import { writeFile } from "node:fs/promises";
import path from "node:path";
import { assets, looks, pieces } from "./real-collection";
const accessoryOnly = new Set(["charleston", "gangster", "marinero", "piloto", "hawaiano", "michael-jackson", "pirata-clasico", "pirata-corsario"]);
const targets: Record<string, string> = {
  "folclor-tricolor-azul": "The girls' cobalt blue and red blouse with narrow yellow ribbon and cobalt blue long flared skirt with red ruffle and yellow ribbon. Exclude the unrelated beige blouse and fuchsia skirt at far left.",
  "folclor-multicolor": "The girls' cobalt blue and red blouse edged with yellow ribbon, and full skirt with horizontal lime green, orange, yellow and fuchsia bands.",
  "folclor-blanco-tricolor": "The girls' white blouse with yellow-blue-red off-shoulder ruffles and long white skirt with yellow-blue-red hem ruffles.",
  "folclor-satinado": "The white lace ruffled blouse and full satin skirt. Show three separate headless dress forms side by side: violet, blue, lime green skirts, preserving the actual trim variations visible in the reference.",
  "folclor-cintas": "The front girls' white off-shoulder lace blouse with narrow multicolor ribbons, and long black and white skirt with the same narrow ribbons. Preserve the white lace and all ribbon colors.",
  "folclor-aguamarina": "The white lace blouse and wide aqua/mint skirt with black waistband, black bands and white ruffles. Preserve the exact number and order of black/white ruffle bands.",
  "danza-blanco-encaje": "One of the girls' long plain white dresses with wide white lace ruffled neckline and white lace hem. Exclude the colorful boys' shirts.",
  "campesina-estampada": "The white lace off-shoulder blouses and printed country dance skirts, with green, orange and coral versions. Show three headless dress forms with one version each. Preserve actual fabric prints, hem length and lace.",
  "campesina-volantes": "The girls' printed dance ensembles with abundant white lace ruffles: blue, orange and lime green. Show three headless dress forms side by side displaying the actual different blouse designs and matching skirt colors.",
  "campesino-clasico": "One boys' complete white shirt and black trousers, with red neck scarf and black country hat. Place the hat neatly beside the headless mannequin. Do not include a person or a human head.",
  "folclor-blanco-pechera": "The boys' white shirt with decorative ruffled bib or colored ribbon strips, white trousers, red scarf, straw hat. Show the gold trim and multicolor ribbon shirt options on two headless forms; no people. Place hats beside them.",
  "camiseta-danza": "Only the boys' long sleeved shirts in yellow, green and orange, with matching head scarves and straw hats arranged beside them. Three upper-body headless clothing forms. Do not invent trousers or add the girls' dresses.",
};
async function main() {
  const plan = looks.filter(l => !accessoryOnly.has(l.key)).map(l => {
    const cultural = !!targets[l.key];
    const asset = assets[l.asset];
    const inputPaths = [path.resolve("Multimedia_Adjunta", asset.originalFile || asset.file)];
    if (l.key === "hada-verde") inputPaths.push(path.resolve("Multimedia_Adjunta", assets.hadaVerde.file));
    if (l.key === "folclor-blanco-pechera") inputPaths.push(path.resolve("Multimedia_Adjunta", assets.folkSatinados.originalFile!));
    const target = targets[l.key] || `${l.name}: ${l.description} Focus only on this named costume in the reference. The reference may be a shopping screenshot with other unrelated products; discard unrelated products.`;
    const prompt = `Use case: precise-object-edit. Asset type: professional costume rental catalog photograph. Input image 1 is the edit target and clothing source; additional inputs, if any, are supporting garment/accessory references only. Extract and restage the actual garment described here: ${target}\nCreate an exceptionally polished realistic studio product photograph, portrait 1024x1536, on a seamless warm ivory background with soft large softbox light, natural contact shadow, accurate white balance, crisp fabric texture, restrained elegant styling, complete garment visible and centered with generous margins. Use an invisible/ghost mannequin or a headless tailor's dress form, never a real person, human head, face, doll face, blurred face, skin-colored blank oval, school group or school setting. Preserve the exact garment cut, actual colors, prints, lace, crochet, embroidery, ruffles, ribbon order and visible fabric construction. Do not invent luxury detailing or extra clothing. Accessories that are visible in the reference may be neatly arranged beside the garment without dominating it. No added shoes unless clearly part of the costume. Remove all Temu logos, shop watermarks, promotional copy, prices, purchase buttons, screenshot borders, branding overlays, and background clutter. Preserve design emblems belonging to the costume itself. No text anywhere in the image, no captions, labels or watermark. This is faithful product photo editing for the supplied wardrobe, not an unrelated costume redesign.`;
    return { key: l.key, name: l.name.replace(/Folclor/g, "Cultural"), cultural, inputPaths, target, prompt, output: `Multimedia_Adjunta/Estudio/${l.key}.png` };
  });
  await writeFile("docs/plan-fotos-estudio.json", JSON.stringify(plan, null, 2));
  console.log(JSON.stringify({ images: plan.length, file: "docs/plan-fotos-estudio.json" }));
}
main();
