import type { Asset, Piece, Look } from "./real-collection";

export const folkCategories = [
  ["folclor", "Arte, cultura y folclor", null],
  ["bailes", "Bailes tradicionales", "folclor"],
  ["bailes-tricolor", "Folclor tricolor", "bailes"],
  ["bailes-campesinos", "Campesinos y estampados", "bailes"],
  ["bailes-volantes", "Faldas y volantes", "bailes"],
  ["bailes-tropical", "Blancos y tropicales", "bailes"],
  ["bailes-camisas", "Camisas y conjuntos", "bailes"],
] as const;

const photo = (name: string, original: string): Asset => ({
  file: `Editadas/2/${name}.png`, originalFile: `2/${original}`, real: true, edited: true,
});
export const folkAssets: Record<string, Asset> = {
  folkTricolorAzul: photo("01-tricolor-azul", "WhatsApp Image 2026-10-28 at 2.41.14 PM (1).jpeg"),
  folkMulticolor: photo("02-multicolor", "WhatsApp Image 2026-10-28 at 2.41.14 PM.jpeg"),
  folkBlancoTricolor: photo("03-blanco-tricolor", "WhatsApp Image 2026-10-28 at 2.42.13 PM.jpeg"),
  folkSatinados: photo("04-volantes-satinados", "WhatsApp Image 2026-10-28 at 2.43.56 PM.jpeg"),
  folkCintas: photo("05-cintas-multicolor", "WhatsApp Image 2026-10-28 at 2.46.07 PM.jpeg"),
  folkAguamarina: photo("06-aguamarina", "WhatsApp Image 2026-10-28 at 2.49.15 PM.jpeg"),
  folkBlancos: photo("07-blancos-y-camisas", "WhatsApp Image 2026-10-28 at 2.49.52 PM.jpeg"),
  folkCampesinos: photo("08-campesinos-estampados", "WhatsApp Image 2026-10-28 at 2.51.28 PM.jpeg"),
  folkCampesinosVolantes: photo("09-campesinos-volantes", "WhatsApp Image 2026-10-28 at 2.58.51 PM.jpeg"),
};

export const folkPieces: Piece[] = [
  { key: "blusa-tricolor-azul", name: "Blusa folclórica azul y roja con cinta amarilla", color: "Azul y rojo", asset: "folkTricolorAzul", sized: true },
  { key: "falda-tricolor-azul", name: "Falda azul con volante rojo y cinta amarilla", color: "Azul y rojo", asset: "folkTricolorAzul", sized: true },
  { key: "falda-multicolor", name: "Falda de franjas verde, naranja, amarilla y fucsia", color: "Multicolor", asset: "folkMulticolor", sized: true },
  { key: "blusa-blanca-tricolor", name: "Blusa blanca con volantes tricolor", color: "Blanco y tricolor", asset: "folkBlancoTricolor", sized: true },
  { key: "falda-blanca-tricolor", name: "Falda blanca con ruedo tricolor", color: "Blanco y tricolor", asset: "folkBlancoTricolor", sized: true },
  { key: "blusa-blanca-encaje-volantes", name: "Blusa blanca de encaje y volantes", color: "Blanco", asset: "folkSatinados", sized: true },
  ...[
    ["violeta", "Violeta"], ["azul", "Azul"], ["verde", "Verde"],
  ].map(([key, color]): Piece => ({ key: `falda-satinada-${key}`, name: `Falda folclórica satinada · ${color.toLowerCase()}`, color, asset: "folkSatinados", sized: true })),
  { key: "blusa-cintas", name: "Blusa blanca con encaje y cintas multicolor", color: "Blanco y multicolor", asset: "folkCintas", sized: true },
  { key: "falda-cintas", name: "Falda negra y blanca con cintas multicolor", color: "Negro y multicolor", asset: "folkCintas", sized: true },
  { key: "blusa-aguamarina", name: "Blusa blanca con encaje · aguamarina", color: "Blanco", asset: "folkAguamarina", sized: true },
  { key: "falda-aguamarina", name: "Falda aguamarina con volantes negros y blancos", color: "Aguamarina", asset: "folkAguamarina", sized: true },
  { key: "vestido-blanco-encaje", name: "Vestido blanco de encaje para danza", color: "Blanco", asset: "folkBlancos", sized: true },
  { key: "blusa-campesina", name: "Blusa campesina blanca con encaje", color: "Blanco", asset: "folkCampesinos", sized: true },
  ...[
    ["verde", "Verde"], ["naranja", "Naranja"], ["coral", "Coral"],
  ].map(([key, color]): Piece => ({ key: `falda-campesina-${key}`, name: `Falda campesina estampada · ${color.toLowerCase()}`, color, asset: "folkCampesinos", sized: true })),
  ...[
    ["azul", "Azul"], ["naranja", "Naranja"], ["verde", "Verde"],
  ].flatMap(([key, color]): Piece[] => [
    { key: `blusa-campesina-volantes-${key}`, name: `Blusa de volantes y encaje · ${color.toLowerCase()}`, color: color === "Azul" ? "Blanco" : `Blanco y ${color.toLowerCase()}`, asset: "folkCampesinosVolantes", sized: true },
    { key: `falda-campesina-volantes-${key}`, name: `Falda estampada de volantes y encaje · ${color.toLowerCase()}`, color, asset: "folkCampesinosVolantes", sized: true },
  ]),
  { key: "camisa-campesino", name: "Camisa blanca de campesino", color: "Blanco", asset: "folkCampesinosVolantes", sized: true },
  { key: "pantalon-campesino", name: "Pantalón negro de campesino", color: "Negro", asset: "folkCampesinosVolantes", sized: true },
  { key: "sombrero-campesino", name: "Sombrero negro campesino", color: "Negro", asset: "folkCampesinosVolantes", sized: true },
  { key: "panuelo-folclor-rojo", name: "Pañuelo folclórico rojo", color: "Rojo", asset: "folkTricolorAzul" },
  { key: "panuelo-folclor-negro", name: "Pañuelo folclórico negro", color: "Negro", asset: "folkCampesinosVolantes" },
  { key: "sombrero-paja-folclor", name: "Sombrero de paja folclórico", color: "Natural", asset: "folkTricolorAzul", sized: true },
  { key: "camisa-pechera-dorada", name: "Camisa blanca con pechera de volantes dorada", color: "Blanco y dorado", asset: "folkTricolorAzul", sized: true },
  { key: "camisa-pechera-multicolor", name: "Camisa blanca con cintas multicolor", color: "Blanco y multicolor", asset: "folkMulticolor", sized: true },
  { key: "pantalon-blanco-folclor", name: "Pantalón blanco folclórico", color: "Blanco", asset: "folkSatinados", sized: true },
  { key: "gorro-blanco-folclor", name: "Gorro blanco folclórico", color: "Blanco", asset: "folkSatinados", sized: true },
  ...[
    ["amarillo", "Amarillo"], ["verde", "Verde"], ["naranja", "Naranja"],
  ].flatMap(([key, color]): Piece[] => [
    { key: `camiseta-danza-${key}`, name: `Camiseta de danza de manga larga · ${color.toLowerCase()}`, color, asset: "folkBlancos", sized: true },
    { key: `panuelo-danza-${key}`, name: `Pañuelo de cabeza para danza · ${color.toLowerCase()}`, color, asset: "folkBlancos" },
  ]),
  { key: "tocado-folclor-multicolor", name: "Tocado de flores folclórico", color: "Multicolor", asset: "folkMulticolor" },
  { key: "tocado-folclor-tricolor", name: "Tocado de flores tricolor", color: "Tricolor", asset: "folkBlancoTricolor" },
  { key: "tocado-folclor-blanco", name: "Tocado de flores · blanco y colores", color: "Multicolor", asset: "folkAguamarina" },
  { key: "panuelo-falda", name: "Pañuelo blanco de danza", color: "Blanco", asset: "folkCintas" },
  { key: "machete-utileria-folclor", name: "Machete folclórico de utilería", color: "Natural", asset: "folkCampesinos", note: "Accesorio de utilería visible en la fotografía. No es una herramienta de corte." },
];

export const folkLooks: Look[] = [
  { key: "folclor-tricolor-azul", name: "Folclor tricolor · azul y rojo", category: "bailes-tricolor", color: "Azul y rojo", asset: "folkTricolorAzul", gallery: ["folkMulticolor"], pieces: ["blusa-tricolor-azul", "falda-tricolor-azul", "tocado-folclor-multicolor"], description: "Blusa azul y roja con cinta amarilla, falda amplia azul de volante rojo y tocado de flores. Fotografías del vestuario en presentación.", tags: ["folclor", "danza", "tricolor", "colombia"], featured: true },
  { key: "folclor-multicolor", name: "Folclor multicolor · falda de franjas", category: "bailes-tricolor", color: "Multicolor", asset: "folkMulticolor", pieces: ["blusa-tricolor-azul", "falda-multicolor", "tocado-folclor-multicolor"], description: "Blusa azul y roja con cinta amarilla y falda de franjas verde, naranja, amarilla y fucsia. Se agrupa con su tocado de flores.", tags: ["folclor", "danza", "franjas", "multicolor"], featured: true },
  { key: "folclor-blanco-tricolor", name: "Folclor blanco · volantes tricolor", category: "bailes-tricolor", color: "Blanco y tricolor", asset: "folkBlancoTricolor", pieces: ["blusa-blanca-tricolor", "falda-blanca-tricolor", "tocado-folclor-tricolor"], description: "Conjunto blanco con volantes amarillos, azules y rojos en blusa y ruedo de falda. Incluye tocado de flores tricolor.", tags: ["folclor", "danza", "blanco", "tricolor"], featured: true },
  { key: "folclor-satinado", name: "Folclor satinado · faldas de vuelo", category: "bailes-volantes", color: "Violeta", asset: "folkSatinados", pieces: [], colorways: [
    { color: "Violeta", pieces: ["blusa-blanca-encaje-volantes", "falda-satinada-violeta"] },
    { color: "Azul", pieces: ["blusa-blanca-encaje-volantes", "falda-satinada-azul"] },
    { color: "Verde", pieces: ["blusa-blanca-encaje-volantes", "falda-satinada-verde"] },
  ], description: "Blusa blanca de encaje y falda satinada de vuelo. Las opciones violeta, azul y verde se controlan por color y talla.", tags: ["folclor", "danza", "volantes", "satén"], featured: true },
  { key: "folclor-cintas", name: "Folclor · cintas multicolor", category: "bailes-volantes", color: "Negro y multicolor", asset: "folkCintas", pieces: ["blusa-cintas", "falda-cintas", "tocado-folclor-multicolor", "panuelo-falda"], description: "Blusa blanca de encaje y falda negra y blanca con cintas multicolor. Incluye tocado floral y pañuelo blanco.", tags: ["folclor", "danza", "cintas", "encaje"] },
  { key: "folclor-aguamarina", name: "Folclor aguamarina · negro y blanco", category: "bailes-volantes", color: "Aguamarina", asset: "folkAguamarina", pieces: ["blusa-aguamarina", "falda-aguamarina", "tocado-folclor-blanco"], description: "Blusa blanca con encaje y falda amplia aguamarina, con bandas negras y volantes blancos. Incluye tocado floral.", tags: ["folclor", "danza", "aguamarina", "encaje"], featured: true },
  { key: "danza-blanco-encaje", name: "Danza · vestido blanco de encaje", category: "bailes-tropical", color: "Blanco", asset: "folkBlancos", pieces: ["vestido-blanco-encaje"], description: "Vestido blanco de danza con cuello amplio, encaje y falda larga. Pañuelos de cabeza se escogen como accesorios opcionales.", tags: ["danza", "vestido blanco", "encaje", "folclor"] },
  { key: "campesina-estampada", name: "Campesina · falda estampada", category: "bailes-campesinos", color: "Naranja", asset: "folkCampesinos", pieces: [], colorways: [
    { color: "Naranja", pieces: ["blusa-campesina", "falda-campesina-naranja"] },
    { color: "Verde", pieces: ["blusa-campesina", "falda-campesina-verde"] },
    { color: "Coral", pieces: ["blusa-campesina", "falda-campesina-coral"] },
  ], description: "Blusa blanca de encaje y falda campesina estampada. Opciones naranja, verde y coral, con existencias por talla y color. La utilería se acuerda por separado.", tags: ["campesina", "folclor", "estampado", "danza"] },
  { key: "campesina-volantes", name: "Campesina · volantes y encaje", category: "bailes-campesinos", color: "Azul", asset: "folkCampesinosVolantes", pieces: [], colorways: [
    { color: "Azul", pieces: ["blusa-campesina-volantes-azul", "falda-campesina-volantes-azul"] },
    { color: "Naranja", pieces: ["blusa-campesina-volantes-naranja", "falda-campesina-volantes-naranja"] },
    { color: "Verde", pieces: ["blusa-campesina-volantes-verde", "falda-campesina-volantes-verde"] },
  ], description: "Conjunto campesino de blusa y falda estampada con volantes y encaje blanco. Colores azul, naranja y verde organizados en una misma ficha.", tags: ["campesina", "folclor", "volantes", "encaje"], featured: true },
  { key: "campesino-clasico", name: "Campesino · blanco y negro", category: "bailes-camisas", color: "Blanco, negro y rojo", asset: "folkCampesinosVolantes", gallery: ["folkCampesinos", "folkCintas"], pieces: [], colorways: [
    { color: "Blanco, negro y rojo", pieces: ["camisa-campesino", "pantalon-campesino", "sombrero-campesino", "panuelo-folclor-rojo", { key: "machete-utileria-folclor", required: false }] },
    { color: "Blanco y negro", pieces: ["camisa-campesino", "pantalon-campesino", "sombrero-campesino", "panuelo-folclor-negro", { key: "machete-utileria-folclor", required: false }] },
  ], description: "Camisa blanca, pantalón y sombrero negros, con pañuelo rojo o negro. La utilería folclórica es opcional y se acuerda por separado.", tags: ["campesino", "folclor", "sombrero", "danza"] },
  { key: "folclor-blanco-pechera", name: "Folclor blanco · camisa de pechera", category: "bailes-camisas", color: "Blanco y dorado", asset: "folkTricolorAzul", gallery: ["folkMulticolor", "folkSatinados"], pieces: [], colorways: [
    { color: "Blanco y dorado", pieces: ["camisa-pechera-dorada", "pantalon-blanco-folclor", "sombrero-paja-folclor", "panuelo-folclor-rojo", { key: "gorro-blanco-folclor", required: false }] },
    { color: "Blanco y multicolor", pieces: ["camisa-pechera-multicolor", "pantalon-blanco-folclor", "sombrero-paja-folclor", "panuelo-folclor-rojo", { key: "gorro-blanco-folclor", required: false }] },
  ], description: "Camisa blanca con pechera o cintas, pantalón blanco, sombrero de paja y pañuelo rojo. El gorro blanco es una opción de presentación que se acuerda por separado.", tags: ["folclor", "blanco", "pechera", "sombrero", "danza"] },
  { key: "camiseta-danza", name: "Danza · camiseta de colores", category: "bailes-camisas", color: "Amarillo", asset: "folkBlancos", pieces: [], colorways: [
    { color: "Amarillo", pieces: ["camiseta-danza-amarillo", "panuelo-danza-amarillo", "sombrero-paja-folclor"] },
    { color: "Verde", pieces: ["camiseta-danza-verde", "panuelo-danza-verde", "sombrero-paja-folclor"] },
    { color: "Naranja", pieces: ["camiseta-danza-naranja", "panuelo-danza-naranja", "sombrero-paja-folclor"] },
  ], description: "Camiseta de manga larga para danza, pañuelo de cabeza y sombrero de paja. Opciones amarilla, verde y naranja. No incluye pantalón.", tags: ["danza", "camiseta", "tropical", "folclor"] },
];
