import "dotenv/config";
import { PrismaClient } from "@prisma/client";
import { applyCulturalPolicy } from "./cultural-policy";
const db = new PrismaClient();
applyCulturalPolicy(db).catch(e => { console.error(e.message); process.exitCode = 1; }).finally(() => db.$disconnect());
