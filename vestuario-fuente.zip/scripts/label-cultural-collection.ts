import "dotenv/config";
import { PrismaClient } from "@prisma/client";
import { mkdir, writeFile } from "node:fs/promises";
const db = new PrismaClient();
const labels = [
  { key: "folclor-tricolor-azul", label: "Cumbia", name: "Cumbia · azul y rojo", source: "Miniatura Cumbia, 5:19 p. m." },
  { key: "folclor-multicolor", label: "Región pacífica", name: "Región pacífica · falda multicolor", source: "Miniatura Región pacífica, 5:18 p. m." },
  { key: "folclor-blanco-tricolor", label: "Cumbia", name: "Cumbia · blanco tricolor", provisional: true, source: "Clasificación provisional autorizada por el negocio; el mensaje de dos fotos no muestra miniaturas." },
  { key: "folclor-satinado", label: "Cumbia", name: "Cumbia · faldas satinadas", provisional: true, source: "Clasificación provisional autorizada por el negocio; el mensaje de dos fotos no muestra miniaturas." },
  { key: "folclor-cintas", label: "Bambuco", name: "Bambuco · cintas multicolor", source: "Miniatura Bambuco, 5:20 p. m." },
  { key: "folclor-aguamarina", label: "Bambuco", name: "Bambuco · aguamarina", source: "Miniatura individual Bambuco, 5:20 p. m." },
  { key: "danza-blanco-encaje", label: "Región pacífica", name: "Región pacífica · vestido blanco", source: "Miniatura Región pacífico, 5:21 p. m." },
  { key: "campesina-estampada", label: "Carranga", name: "Carranga · falda estampada", source: "Miniatura Carranga, 5:21 p. m." },
  { key: "campesina-volantes", label: "Región cafetera", name: "Región cafetera · volantes y encaje", source: "Miniatura Región cafetera, 5:21 p. m." },
  { key: "campesino-clasico", label: "Carranga / Región cafetera", name: "Campesino · blanco y negro", source: "Prendas masculinas presentes en ambas fotos etiquetadas Carranga y Región cafetera." },
  { key: "folclor-blanco-pechera", label: "Cumbia / Región pacífica", name: "Traje blanco · pechera y cintas", source: "Prendas masculinas presentes en las fotos etiquetadas Cumbia y Región pacífica." },
  { key: "camiseta-danza", label: "Región pacífica", name: "Región pacífica · camiseta de danza", source: "Camisetas masculinas en la foto etiquetada Región pacífico." },
];
async function main() {
  if (await db.auditLog.findFirst({ where: { action: "CULTURAL_LABELS", entityId: "capture-2026-10-28-v1" } })) { console.log("Etiquetas ya aplicadas; se conservan las ediciones posteriores."); return; }
  const before = await db.costume.findMany({ where: { slug: { in: labels.map(l => `real-${l.key}`) } } });
  await mkdir(".runtime/backups", { recursive: true });
  await writeFile(`.runtime/backups/before-cultural-labels-${Date.now()}.json`, JSON.stringify(before, null, 2));
  await db.$transaction(async tx => {
    for (const l of labels) {
      const model = before.find(m => m.slug === `real-${l.key}`)!;
      const tags = [...new Set([...model.tags.filter(t => t !== "etiqueta-provisional"), ...l.label.split(" / "), ...(l.provisional ? ["etiqueta-provisional"] : [])])];
      const description = model.description.replace(/ Para niñas de 6\.º y 7\.º grado: tres unidades S y tres M listas\. Alquiler individual o juego de seis\./, "").replace(/ Seis unidades listas, talla Niño\. Alquiler individual o juego de seis\./, "");
      await tx.costume.update({ where: { id: model.id }, data: { name: l.name, danceStyle: l.label, tags, description, searchTerms: `${model.searchTerms} ${l.label}`.slice(0, 1000) } });
    }
    await tx.auditLog.create({ data: { action: "CULTURAL_LABELS", entityId: "capture-2026-10-28-v1", detail: { source: "Captura aportada por el negocio", labels } } });
  }, { timeout: 30000 });
  await writeFile("docs/etiquetas-culturales.json", JSON.stringify({ source: "Multimedia_Adjunta/Etiquetas/captura-2026-10-28.png", provisionalInstruction: "No sé, pon algo acorde por ahora", labels }, null, 2));
  console.log("12 modelos etiquetados; dos clasificaciones provisionales editables.");
}
main().catch(e => { console.error(e.message); process.exitCode = 1; }).finally(() => db.$disconnect());
