import "dotenv/config";
import { PrismaClient } from "@prisma/client";
import { createHash } from "node:crypto";
import { copyFile, mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { accessoryOnly } from "./cultural-policy";
import { collectionTag, componentTag, looks, pieces } from "./real-collection";

const db = new PrismaClient();
const policy = "accessory-rentals-v1";
async function main() {
  if (await db.auditLog.findFirst({ where: { action: "ACCESSORY_RENTALS", entityId: policy } })) {
    console.log("Los accesorios ya están preparados. Se conservan los cambios posteriores."); return;
  }
  const inventory = await db.costume.findMany({ where: { tags: { has: collectionTag } }, include: {
    variants: { include: { units: true, outfit: { include: { components: { include: { options: true } } } } } },
  } });
  const readyBefore = inventory.flatMap(m => m.variants.flatMap(v => v.units)).filter(u => u.state === "READY").length;
  await mkdir(".runtime/backups", { recursive: true });
  await writeFile(`.runtime/backups/before-${policy}-${Date.now()}.json`, JSON.stringify(inventory));
  const photos = new Map<string, string>();
  for (const key of [...accessoryOnly, "pieza-peineta-rosas"]) {
    const original = inventory.find(m => m.slug === `real-${key}`)!;
    const bytes = await readFile(path.resolve(process.env.UPLOAD_DIR || "uploads", path.basename(original.images[0])));
    const file = createHash("sha256").update(bytes).digest("hex") + ".webp";
    await copyFile(path.resolve(process.env.UPLOAD_DIR || "uploads", path.basename(original.images[0])), path.resolve(process.env.UPLOAD_DIR || "uploads", file));
    photos.set(key, "/uploads/" + file);
  }
  await db.$transaction(async tx => {
    const accessoryCategory = await tx.category.findUniqueOrThrow({ where: { slug: "accesorios" } });
    const professionCategory = await tx.category.findUniqueOrThrow({ where: { slug: "profesiones" } });
    const accessoryKeys = new Set<string>();
    for (const look of looks.filter(l => accessoryOnly.has(l.key))) for (const p of look.pieces) {
      const item = typeof p === "string" ? { key: p } : p;
      accessoryKeys.add(item.key); item.alternatives?.forEach(k => accessoryKeys.add(k));
    }
    accessoryKeys.add("peineta-rosas");
    const physicalVariants = new Map<string, string>();
    for (const key of accessoryKeys) {
      const piece = pieces.find(p => p.key === key)!;
      const model = await tx.costume.findUniqueOrThrow({ where: { slug: `real-pieza-${key}` } });
      await tx.costume.update({ where: { id: model.id }, data: { active: true, tags: [...new Set([...model.tags, componentTag, "accesorio-fisico", "cantidad-por-confirmar"])] } });
      await tx.variant.updateMany({ where: { costumeId: model.id }, data: { active: false } });
      const variant = await tx.variant.upsert({ where: { costumeId_size_color: { costumeId: model.id, size: piece.sized ? "Por confirmar" : "Única", color: piece.color } },
        create: { costumeId: model.id, size: piece.sized ? "Por confirmar" : "Única", color: piece.color, price: 0 }, update: { active: true } });
      physicalVariants.set(key, variant.id);
    }
    for (const look of looks.filter(l => accessoryOnly.has(l.key))) {
      const source = inventory.find(m => m.slug === `real-${look.key}`)!;
      const slug = look.key === "piloto" ? "real-kit-piloto" : source.slug;
      const size = look.oneSize ? "Única" : "Por confirmar";
      const related = look.key === "piloto" ? ["traje-relacionado:real-piloto"] : look.key === "pirata-clasico" ? ["traje-relacionado:real-pirata-aventurera"] : [];
      const model = await tx.costume.upsert({ where: { slug }, create: { slug, name: look.name, categoryId: accessoryCategory.id, description: look.description,
        images: [photos.get(look.key)!], tags: [collectionTag, "accesorio-alquilable", "cantidad-por-confirmar", "foto-referencia", ...related], searchTerms: look.name, requiredMetrics: [], demo: false },
        update: { active: true, categoryId: accessoryCategory.id, images: [photos.get(look.key)!], tags: [collectionTag, "accesorio-alquilable", "cantidad-por-confirmar", "foto-referencia", ...related] } });
      await tx.variant.updateMany({ where: { costumeId: model.id }, data: { active: false } });
      const variant = await tx.variant.upsert({ where: { costumeId_size_color: { costumeId: model.id, size, color: look.color } },
        create: { costumeId: model.id, size, color: look.color, price: 0 }, update: { active: true } });
      const outfit = await tx.outfit.upsert({ where: { variantId: variant.id }, create: { variantId: variant.id, mode: "FLEXIBLE" }, update: {} });
      await tx.outfitComponent.deleteMany({ where: { outfitId: outfit.id } });
      for (const p of look.pieces) {
        const item = typeof p === "string" ? { key: p } : p;
        await tx.outfitComponent.create({ data: { outfitId: outfit.id, name: pieces.find(def => def.key === item.key)!.name, quantity: 1, required: item.required !== false, variantId: physicalVariants.get(item.key)!,
          allowSubstitution: !!item.alternatives?.length, options: { create: (item.alternatives || []).map(k => ({ variantId: physicalVariants.get(k)! })) } } });
      }
    }
    // Reattach rentable accessories to complete costumes. A rental of a kit and
    // a complete costume must compete for the same physical accessory units.
    for (const look of looks.filter(l => !accessoryOnly.has(l.key))) {
      const shared = look.pieces.map(p => typeof p === "string" ? { key: p } : p).filter(p => physicalVariants.has(p.key));
      if (!shared.length) continue;
      const model = inventory.find(m => m.slug === `real-${look.key}`);
      if (!model?.active) continue;
      for (const v of model.variants.filter(v => v.active && v.outfit)) for (const item of shared) {
        await tx.outfitComponent.create({ data: { outfitId: v.outfit!.id, name: pieces.find(p => p.key === item.key)!.name,
          variantId: physicalVariants.get(item.key)!, required: item.required !== false,
          allowSubstitution: !!item.alternatives?.length, options: { create: (item.alternatives || []).filter(k => physicalVariants.has(k)).map(k => ({ variantId: physicalVariants.get(k)! })) } } });
      }
    }
    const peineta = await tx.costume.findUniqueOrThrow({ where: { slug: "real-pieza-peineta-rosas" } });
    await tx.costume.update({ where: { id: peineta.id }, data: { active: true, categoryId: accessoryCategory.id, images: [photos.get("pieza-peineta-rosas")!],
      tags: [collectionTag, "accesorio-alquilable", "accesorio-fisico", "cantidad-por-confirmar", "foto-referencia"] } });
    // The confirmed pilot clothing has no invented size or quantity. Historical
    // assumed accessory units remain retired; both offers use the same pieces.
    const uniform = await tx.costume.create({ data: { slug: "real-pieza-uniforme-piloto", name: "Piloto · camisa y pantalón", description: "Camisa y pantalón confirmados por el negocio el 29/10/2026. Cantidad y tallas pendientes.",
      categoryId: professionCategory.id, tags: [collectionTag, componentTag, "cantidad-por-confirmar"], requiredMetrics: [], searchTerms: "piloto camisa pantalón", demo: false } });
    const uniformVariant = await tx.variant.create({ data: { costumeId: uniform.id, size: "Por confirmar", color: "Por confirmar", price: 0 } });
    const pilot = await tx.costume.findUniqueOrThrow({ where: { slug: "real-piloto" } });
    await tx.costume.update({ where: { id: pilot.id }, data: { name: "Piloto · traje completo", active: true, categoryId: professionCategory.id,
      description: "Traje de piloto con camisa, pantalón, gorra, corbata, par de charreteras e insignia de alas. La fotografía actual muestra el kit de accesorios; la foto del traje completo está pendiente.",
      images: [photos.get("piloto")!], includedAccessories: ["Gorra de piloto", "Corbata de piloto", "Par de charreteras de piloto", "Insignia de alas de piloto"],
      tags: [collectionTag, "conjunto", "cantidad-por-confirmar", "foto-del-kit", "accesorio-relacionado:real-kit-piloto"], searchTerms: "piloto aviador capitán camisa pantalón uniforme completo" } });
    await tx.variant.updateMany({ where: { costumeId: pilot.id }, data: { active: false } });
    const pilotVariant = await tx.variant.create({ data: { costumeId: pilot.id, size: "Por confirmar", color: "Por confirmar", price: 0 } });
    await tx.outfit.create({ data: { variantId: pilotVariant.id, mode: "FLEXIBLE", components: { create: [
      { name: "Camisa y pantalón", variantId: uniformVariant.id },
      ...["gorra-piloto", "corbata-piloto", "charreteras", "insignia-piloto"].map(key => ({ name: pieces.find(p => p.key === key)!.name, variantId: physicalVariants.get(key)! })),
    ] } } });
    const readyAfter = await tx.unit.count({ where: { state: "READY", variant: { costume: { tags: { has: collectionTag } } } } });
    if (readyAfter !== readyBefore) throw new Error("La preparación no debe cambiar cantidades físicas.");
    await tx.auditLog.create({ data: { action: "ACCESSORY_RENTALS", entityId: policy,
      detail: { rentalOffers: 9, pilotClothingConfirmed: true, quantitiesPending: true, readyUnitsUnchanged: readyAfter, sharedAccessoryVariants: true } } });
  }, { timeout: 120000 });
  console.log("9 ofertas de accesorios y piloto completo. Cantidades pendientes; 296 unidades existentes conservadas.");
}
main().catch(e => { console.error(e.message); process.exitCode = 1; }).finally(() => db.$disconnect());
