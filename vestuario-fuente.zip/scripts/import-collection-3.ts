import "dotenv/config";
import { PrismaClient } from "@prisma/client";
import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import sharp from "../apps/api/node_modules/sharp";
const db=new PrismaClient();
const collection="coleccion-real-octubre-2026", piece="pieza-de-conjunto", policy="coleccion-3-v1";
const unique=(xs:string[])=>[...new Set(xs)];
async function main(){
 if(await db.auditLog.findFirst({where:{action:"COLLECTION_3",entityId:policy}})){console.log("Colección 3 ya incorporada; cambios posteriores conservados.");return;}
 const plan=JSON.parse(await readFile("docs/fotos-coleccion-3.json","utf8"));
 const images=new Map<string,string>();
 for(const p of plan.images){
  const bytes=await sharp(await readFile(p.master)).resize(1200,1600,{fit:"inside",withoutEnlargement:true}).webp({quality:88}).toBuffer();
  const hash=createHash("sha256").update(bytes).digest("hex");
  await writeFile(path.resolve(process.env.UPLOAD_DIR||"uploads",hash+".webp"),bytes);images.set(p.key,`/uploads/${hash}.webp`);
 }
 const before=await db.costume.findMany({where:{tags:{has:collection}},include:{variants:{include:{units:true,outfit:{include:{components:{include:{options:true}}}}}}}});
 await mkdir(".runtime/backups",{recursive:true});
 await writeFile(`.runtime/backups/before-${policy}-${Date.now()}.json`,JSON.stringify(before));
 const readyBefore=await db.unit.count({where:{state:"READY",variant:{costume:{tags:{has:collection}}}}});
 await db.$transaction(async tx=>{
  const cat=Object.fromEntries((await tx.category.findMany()).map(c=>[c.slug,c.id]));
  const tags=(extra:string[]=[])=>unique([collection,"foto-estudio-ia","cantidad-por-confirmar",...extra]);
  async function physical(key:string,name:string,color:string,size="Única",image?:string,publicOffer=false){
   const slug=`real-pieza-${key}`;
   const old=await tx.costume.findUnique({where:{slug}});
   const model=await tx.costume.upsert({where:{slug},create:{slug,name,description:`${name}. Cantidad y ajuste por confirmar.`,categoryId:cat.accesorios,images:image?[image]:[],tags:tags(["accesorio-fisico",...(publicOffer?["accesorio-alquilable"]:[piece])]),searchTerms:name,requiredMetrics:[],demo:false},
    update:{name,active:true,categoryId:cat.accesorios,...(image?{images:[image]}:{}),tags:tags(unique([...(old?.tags||[]).filter(t=>t!==piece&&t!=="accesorio-incluido"&&t!=="foto-referencia"),"accesorio-fisico",...(publicOffer?["accesorio-alquilable"]:[piece])]))}});
   const prior=await tx.variant.findFirst({where:{costumeId:model.id,size,color:{equals:color,mode:"insensitive"}}});
   const v=prior ? await tx.variant.update({where:{id:prior.id},data:{color,active:true}}) : await tx.variant.create({data:{costumeId:model.id,size,color,price:0}});
   return {model,variant:v};
  }
  async function offer(slug:string,name:string,categoryId:string,description:string,photos:string[],links:{color:string;components:{name:string;variantId:string;required?:boolean;quantity?:number;allowSubstitution?:boolean;options?:string[]}[]}[],extra:string[]=[]){
   const old=await tx.costume.findUnique({where:{slug}});
   const model=await tx.costume.upsert({where:{slug},create:{slug,name,description,categoryId,images:photos,tags:tags(extra),searchTerms:`${name} ${description}`,requiredMetrics:[],demo:false},update:{name,description,categoryId,images:photos,active:true,tags:tags(extra),searchTerms:`${name} ${description}`}});
   if(old)await tx.variant.updateMany({where:{costumeId:model.id},data:{active:false}});
   for(const row of links){
    const v=await tx.variant.upsert({where:{costumeId_size_color:{costumeId:model.id,size:"Por confirmar",color:row.color}},create:{costumeId:model.id,size:"Por confirmar",color:row.color,price:0},update:{active:true}});
    const o=await tx.outfit.upsert({where:{variantId:v.id},create:{variantId:v.id,mode:"FLEXIBLE"},update:{mode:"FLEXIBLE"}});
    await tx.outfitComponent.deleteMany({where:{outfitId:o.id}});
    for(const c of row.components)await tx.outfitComponent.create({data:{outfitId:o.id,name:c.name,variantId:c.variantId,required:c.required!==false,quantity:c.quantity||1,allowSubstitution:!!c.allowSubstitution,options:{create:(c.options||[]).map(variantId=>({variantId}))}}});
   }
   return model;
  }
  async function kitParts(slug:string){
   const m=await tx.costume.findUniqueOrThrow({where:{slug},include:{variants:{where:{active:true},include:{outfit:{include:{components:{include:{options:true}}}}}}}});
   return m.variants[0].outfit!.components.filter(c=>c.variantId).map(c=>({name:c.name,variantId:c.variantId!,required:c.required,quantity:c.quantity,allowSubstitution:c.allowSubstitution,options:c.options.map(o=>o.variantId)}));
  }
  // A single, uncounted basic clothing pool is shared by the new combinations.
  const base=await tx.costume.findUniqueOrThrow({where:{slug:"real-pieza-uniforme-piloto"},include:{variants:{where:{active:true}}}});
  await tx.costume.update({where:{id:base.id},data:{name:"Base · camisa blanca y pantalón negro",description:"Prendas básicas compartidas entre presentaciones. Cantidades y tallas pendientes de recuento."}});
  const baseVariant=await tx.variant.update({where:{id:base.variants[0].id},data:{color:"Blanco y negro"}});
  const shirt={name:"Camisa blanca y pantalón negro",variantId:baseVariant.id};
  const pilot=await tx.costume.findUniqueOrThrow({where:{slug:"real-piloto"},include:{variants:{where:{active:true},include:{outfit:{include:{components:true}}}}}});
  await tx.costume.update({where:{id:pilot.id},data:{images:[images.get("piloto-completo")!],description:"Traje completo con camisa blanca, pantalón negro, gorra de piloto, corbata azul oscuro, charreteras en los hombros e insignia de alas en el pecho. Fotografía de presentación editada con IA a partir del kit de referencia.",tags:tags(["conjunto"]),searchTerms:"piloto aviador capitán traje uniforme camisa blanca pantalón negro charreteras insignia"}});
  await tx.variant.update({where:{id:pilot.variants[0].id},data:{color:"Blanco y negro"}});
  await tx.outfitComponent.updateMany({where:{outfitId:pilot.variants[0].outfit!.id,variantId:baseVariant.id},data:{name:shirt.name}});
  await tx.costume.update({where:{slug:"real-kit-piloto"},data:{active:false}});
  const fullDefs=[
   ["real-marinero-completo","Marinero · traje completo","profesiones","marinero-completo","real-marinero"],
   ["real-caballero-anos-20-completo","Caballero años 20 · traje completo","epocas","caballero-completo","real-gangster"],
   ["real-michael-jackson-completo","Michael Jackson · traje de baile","baile","michael-completo","real-michael-jackson"],
   ["real-pirata-clasico-completo","Pirata clásico · traje completo","piratas","pirata-completo","real-pirata-clasico"],
  ];
  for(const [slug,name,category,photo,kitSlug] of fullDefs){
   const parts=await kitParts(kitSlug);
   const model=await offer(slug,name,cat[category],`Conjunto con camisa blanca, pantalón negro y ${parts.filter(p=>p.required).map(p=>p.name.toLowerCase()).join(", ")}. Presentación completa editada con IA. Confirma tallas y disponibilidad con el negocio.`,[images.get(photo)!],[{color:"Blanco y negro",components:[shirt,...parts]}],["conjunto",`accesorio-relacionado:${kitSlug}`]);
   await tx.costume.update({where:{id:model.id},data:{includedAccessories:parts.filter(p=>p.required).map(p=>p.name)}});
   const kit=await tx.costume.findUniqueOrThrow({where:{slug:kitSlug}});
   await tx.costume.update({where:{id:kit.id},data:{tags:unique([...kit.tags.filter(t=>!t.startsWith("traje-relacionado:")),`traje-relacionado:${slug}`])}});
  }
  const cape=await physical("capa-negra-roja","Capa reversible negra y roja","Negro y rojo","Por confirmar",images.get("capa-negra-roja"),true);
  const vampire=await offer("real-vampiro-completo","Vampiro · capa negra y roja",cat.fantasia,"Conjunto con camisa blanca, pantalón negro y capa reversible negra y roja de cuello alto. Presentación completa editada con IA. Cantidades y ajuste por confirmar.",[images.get("vampiro-completo")!],[{color:"Negro y rojo",components:[shirt,{name:"Capa reversible negra y roja",variantId:cape.variant.id}]}],["conjunto",`accesorio-relacionado:${cape.model.slug}`]);
  await tx.costume.update({where:{id:vampire.id},data:{includedAccessories:["Capa reversible negra y roja"]}});
  await tx.costume.update({where:{id:cape.model.id},data:{tags:tags(["accesorio-fisico","accesorio-alquilable",`traje-relacionado:${vampire.slug}`])}});
  for(const color of ["Negro","Verde","Rojo","Blanco"])await physical("diadema-charleston","Diadema de plumas y brillos",color,"Única",images.get("diademas-plumas"),true);
  const feather=await tx.costume.findUniqueOrThrow({where:{slug:"real-pieza-diadema-charleston"}});
  await tx.costume.update({where:{id:feather.id},data:{description:"Diadema de plumas y brillos. Alquiler por unidad, eligiendo color; la foto reúne opciones de referencia. También forma parte del kit de Charlestón.",tags:unique([...feather.tags,"muestra-colores"])}});
  for(const [color,photo] of [["Negro","velo-negro"],["Negro y rojo","velo-rojo"]])await physical("diadema-rosas-velo","Diadema de rosas con velo",color,"Única",images.get(photo),true);
  const veil=await tx.costume.findUniqueOrThrow({where:{slug:"real-pieza-diadema-rosas-velo"}});
  await tx.costume.update({where:{id:veil.id},data:{images:[images.get("velo-negro")!,images.get("velo-rojo")!],tags:unique([...veil.tags,"foto-color:Negro:0","foto-color:Negro y rojo:1"])}});
  const princessRows=[];
  for(const [color,photo] of [["Azul","princesa-corazon-azul"],["Rosado","princesa-corazon-rosa"],["Violeta","princesa-corazon-violeta"]]){
   const crown=await physical("corona-azul","Corona de princesa de corazón",color,"Única",images.get(photo));
   const wand=await physical("varita-azul","Varita de princesa de corazón",color,"Única",images.get(photo));
   princessRows.push({color,components:[{name:"Corona de princesa",variantId:crown.variant.id},{name:"Varita de princesa",variantId:wand.variant.id}]});
  }
  await offer("real-princesa-corona-varita","Princesa · corona y varita",cat.accesorios,"Juego de dos accesorios: una corona y una varita de corazón del color elegido. Opciones azul, rosado y violeta. Las fotos muestran un juego por color.",[images.get("princesa-corazon-azul")!,images.get("princesa-corazon-rosa")!,images.get("princesa-corazon-violeta")!],princessRows,["accesorio-alquilable","foto-color:Azul:0","foto-color:Rosado:1","foto-color:Violeta:2"]);
  const jewelry=await physical("joyeria-azul","Joyería azul · collar, pulsera, aretes y anillo","Azul","Única",images.get("princesa-joyas-azules"));
  await offer("real-princesa-joyeria-azul","Princesa · joyería azul de 6 piezas",cat.accesorios,"Juego completo de corona, varita, collar, pulsera, par de aretes y anillo de fantasía azul. El par de aretes se controla junto. Este juego comparte corona y varita con la opción de dos accesorios.",[images.get("princesa-joyas-azules")!],[{color:"Azul",components:[...princessRows[0].components,{name:"Collar, pulsera, aretes y anillo",variantId:jewelry.variant.id}]}],["accesorio-alquilable"]);
  // Reuse the existing pieces, not a second copy of the same accessory stock.
  for(const slug of ["real-elsa","real-cenicienta"]){
   const m=await tx.costume.findUniqueOrThrow({where:{slug},include:{variants:{where:{active:true},include:{outfit:true}}}});
   for(const v of m.variants)if(v.outfit)for(const c of [...princessRows[0].components,{name:"Joyería azul",variantId:jewelry.variant.id}]){
    if(!await tx.outfitComponent.findFirst({where:{outfitId:v.outfit.id,variantId:c.variantId}}))await tx.outfitComponent.create({data:{outfitId:v.outfit.id,...c}});
   }
  }
  const explorer=[];
  for(const [key,name,color] of [["catalejo-explorador","Catalejo pirata de explorador","Bronce"],["brujula-pirata","Brújula pirata de utilería","Bronce"],["parche-pirata","Parche pirata","Negro"]]){
   const p=await physical(key,name,color,"Única",images.get("pirata-explorador-kit"));explorer.push({name,variantId:p.variant.id});
  }
  await offer("real-pirata-explorador-kit","Pirata explorador · kit de 3 piezas",cat.accesorios,"Juego de catalejo de explorador, brújula y parche de utilería. Diferente del juego pirata clásico de ocho accesorios; ambos comparten las piezas correspondientes.",[images.get("pirata-explorador-kit")!],[{color:"Bronce y negro",components:explorer}],["accesorio-alquilable","traje-relacionado:real-pirata-clasico-completo"]);
  for(const [slug,key] of [["real-marinero","marinero-kit"],["real-michael-jackson","michael-kit"],["real-pirata-clasico","pirata-clasico-kit"],["real-pirata-corsario","corsario-kit"],["real-pieza-peineta-rosas","peineta-rosas"]]){
   const m=await tx.costume.findUniqueOrThrow({where:{slug}});
   await tx.costume.update({where:{id:m.id},data:{images:[images.get(key)!],tags:unique([...m.tags,"foto-estudio-ia"])}});
  }
  const readyAfter=await tx.unit.count({where:{state:"READY",variant:{costume:{tags:{has:collection}}}}});
  if(readyAfter!==readyBefore)throw new Error("La nueva presentación no debe inventar cantidades físicas.");
  await tx.auditLog.create({data:{action:"COLLECTION_3",entityId:policy,detail:{sourceFolder:"Multimedia_Adjunta/3",photos:plan.images.length,pilotOnlyInProfessions:true,newFullCostumes:5,sharedBasicClothing:true,quantitiesPending:true,readyUnitsUnchanged:readyAfter,ignoredDuplicates:["Astronauta","Hada violeta","Jasmine","Kits repetidos"],excluded:"Materiales de taller, cojín, funda de teclado y bandas deportivas"}}});
 },{timeout:120000});
 console.log("Colección 3 incorporada sin duplicar juegos ni crear unidades supuestas.");
}
main().catch(e=>{console.error(e.message);process.exitCode=1;}).finally(()=>db.$disconnect());
