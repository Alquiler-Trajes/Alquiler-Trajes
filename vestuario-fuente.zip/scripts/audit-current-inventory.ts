import "dotenv/config";
import assert from "node:assert/strict";
import { writeFile } from "node:fs/promises";
import { PrismaClient } from "@prisma/client";
import { collectionTag, componentTag } from "./real-collection";
const db = new PrismaClient();
async function main() {
  const all = await db.costume.findMany({ where: { tags: { has: collectionTag } }, include: { category: true, variants: { include: { units: true, outfit: { include: { components: { include: { variant: { include: { units: true } } } } } } } } } });
  const models = all.filter(m => m.active && !m.tags.includes(componentTag));
  const cultural = models.filter(m => m.bundleSize === 6);
  const culturalUnitIds = new Set<string>();
  const groups = [];
  const startsAt = "2030-12-01T14:00:00.000Z", endsAt = "2030-12-02T23:00:00.000Z";
  for (const m of models) {
    const variants = m.variants.filter(v => v.active);
    assert(variants.length > 0);
    const units = [...new Map(variants.flatMap(v => [...v.units, ...(v.outfit?.components.flatMap(c => c.variant?.units || []) || [])]).map(u => [u.id, u])).values()];
    if (m.bundleSize === 6) {
      assert(m.bundleImage, `${m.name}: foto del juego`);
      assert((await fetch("http://127.0.0.1:4000" + m.bundleImage)).ok, "Foto de juego accesible");
      assert(m.danceStyle, `${m.name}: etiqueta cultural`);
      assert.equal(units.length, 6, `${m.name}: seis unidades en total`);
      assert(units.every(u => u.state === "READY"));
      units.forEach(u => { assert(!culturalUnitIds.has(u.id), "Modelos culturales independientes"); culturalUnitIds.add(u.id); });
      const sizes = [...new Set(variants.map(v => v.size))];
      assert.deepEqual(sizes.slice().sort(), sizes.includes("Niño") ? ["Niño"] : ["M", "S"]);
      for (const size of sizes) {
        const sameSize = variants.filter(v => v.size === size);
        assert.equal(new Set(sameSize.map(v => v.outfit?.components[0]?.variantId)).size, 1, "Colores comparten existencias");
        assert.equal(sameSize[0].outfit?.components[0]?.variant?.units.length, size === "Niño" ? 6 : 3);
      }
      const color = variants[0].color;
      const items = variants.filter(v => v.color === color).map(v => ({ variantId: v.id, quantity: v.size === "Niño" ? 6 : 3 }));
      const response = await fetch("http://127.0.0.1:4000/api/catalog/selection/availability", { method: "POST", headers: { "Content-Type": "application/json", Origin: "http://127.0.0.1:3000" }, body: JSON.stringify({ startsAt, endsAt, items }) });
      const result = await response.json();
      assert(response.ok, `${m.slug}: ${response.status} ${JSON.stringify(result)}`); assert.equal(result.sufficient, true);
    }
    for (const url of m.images) assert((await fetch("http://127.0.0.1:4000" + url)).ok, `Imagen accesible ${m.slug}`);
    groups.push({ name: m.name, slug: m.slug, cultural: m.bundleSize === 6, sizes: [...new Set(variants.map(v => v.size))], colors: [...new Set(variants.map(v => v.color))], readyUnits: units.filter(u => u.state === "READY").length, includedAccessories: m.includedAccessories, danceStyle: m.danceStyle, provisionalLabel: m.tags.includes("etiqueta-provisional"), bundleImage: m.bundleImage, studioPhoto: m.tags.includes("foto-estudio-ia") });
  }
  assert.equal(models.length, 48); assert.equal(cultural.length, 12); assert.equal(culturalUnitIds.size, 72);
  assert.equal(models.filter(m => m.tags.includes("foto-estudio-ia")).length, 47);
  const report = { verifiedAt: new Date().toISOString(), totals: { publicModels: models.length, publicVariants: models.reduce((n, m) => n + m.variants.filter(v => v.active).length, 0), culturalModels: cultural.length, culturalUnits: culturalUnitIds.size, readyUnits: all.filter(m => m.active).flatMap(m => m.variants.filter(v => v.active).flatMap(v => v.units)).filter(u => u.state === "READY").length, archivedAssumedUnits: all.flatMap(m => m.variants.flatMap(v => v.units)).filter(u => u.state === "RETIRED").length, studioPhotos: 47, bundlePhotos: cultural.filter(m => m.bundleImage).length, provisionalLabels: cultural.filter(m => m.tags.includes("etiqueta-provisional")).length }, sources: "Multimedia_Adjunta (originales conservados)", groups };
  await writeFile("docs/inventario-real.json", JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report.totals));
}
main().catch(e => { console.error(e.message); process.exitCode = 1; }).finally(() => db.$disconnect());
