import "dotenv/config";
import { PrismaClient } from "@prisma/client";
import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import sharp from "../apps/api/node_modules/sharp";
const db = new PrismaClient();
async function main() {
  const manifest = JSON.parse(await readFile("docs/fotos-juegos.json", "utf8")) as { key: string; output: string; sha256?: string; url?: string }[];
  const dir = path.resolve(process.env.UPLOAD_DIR || "uploads");
  await mkdir(dir, { recursive: true });
  await mkdir(".runtime/backups", { recursive: true });
  await writeFile(`.runtime/backups/before-bundle-photos-${Date.now()}.json`, JSON.stringify(await db.costume.findMany({ where: { slug: { in: manifest.map(m => `real-${m.key}`) } }, select: { id: true, slug: true, bundleImage: true } }), null, 2));
  for (const entry of manifest) {
    const bytes = await readFile(entry.output);
    entry.sha256 = createHash("sha256").update(bytes).digest("hex");
    const webp = await sharp(bytes).resize(2048, 1536, { fit: "inside", withoutEnlargement: true }).webp({ quality: 91 }).toBuffer();
    const file = createHash("sha256").update(webp).digest("hex") + ".webp";
    await writeFile(path.join(dir, file), webp);
    entry.url = `/uploads/${file}`;
    await db.costume.update({ where: { slug: `real-${entry.key}` }, data: { bundleImage: entry.url } });
  }
  await writeFile("docs/fotos-juegos.json", JSON.stringify(manifest, null, 2));
  await db.auditLog.create({ data: { action: "BUNDLE_PHOTOS", entityId: "cultural-x6-2026-10-28", detail: { count: manifest.length, tool: "built-in image_gen", stockUnchanged: true } } });
  console.log(`${manifest.length} vistas de juegos de seis instaladas; cantidades sin cambios.`);
}
main().catch(e => { console.error(e.message); process.exitCode = 1; }).finally(() => db.$disconnect());
