import "dotenv/config";
import { PrismaClient } from "@prisma/client";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { collectionTag, componentTag, looks, pieces } from "./real-collection";
import { costumeOrder } from "../packages/shared/src/catalog";

const db = new PrismaClient();
async function main() {
  const categories = await db.category.findMany();
  const all = await db.costume.findMany({ where: { tags: { has: collectionTag } }, include: {
    category: true, variants: { where: { active: true }, include: { units: true, outfit: { include: { components: { include: { variant: { include: { units: true } } } } } } } },
  } });
  const publicModels = all.filter(m => m.active && !m.tags.includes(componentTag));
  const trajes = publicModels.filter(m => !m.tags.includes("accesorio-alquilable")).sort((a,b) => costumeOrder(a,categories)-costumeOrder(b,categories) || a.name.localeCompare(b.name,"es"));
  const kits = publicModels.filter(m => m.tags.includes("accesorio-alquilable")).sort((a,b) => a.name.localeCompare(b.name,"es"));
  const photo = (url?: string) => url ? path.resolve(process.env.UPLOAD_DIR || "uploads", path.basename(url)) : null;
  const tallaRows: any[] = [];
  const models = trajes.map((m, i) => {
    const id = `TRA-${String(i+1).padStart(3,"0")}`;
    const mainVariants = [...new Map(m.variants.flatMap(v => v.outfit ? v.outfit.components.filter(c => c.required && c.variant && !all.find(a => a.id === c.variant!.costumeId)?.tags.includes("accesorio-fisico")).map(c => c.variant!) : [v]).map(v => [v.id,v])).values()];
    for (const v of mainVariants) {
      const units = v.units.filter(u => u.state !== "RETIRED");
      const pending = m.tags.includes("cantidad-por-confirmar");
      tallaRows.push({ model: id, name: m.name, size: v.size, color: v.color, total: pending ? null : units.length,
        ready: pending ? null : units.filter(u=>u.state==="READY").length, cleaning: pending ? null : units.filter(u=>u.state==="CLEANING").length,
        repair: pending ? null : units.filter(u=>u.state==="REPAIR").length,
        price: m.variants.find(x=>x.size===v.size)?.price || null,
        location: [...new Set(units.map(u=>u.location).filter(Boolean))].join("; "),
        codes: units.map(u=>u.code).join("; "), notes: pending ? "Cantidad y tallas pendientes de recuento." : m.bundleSize===6 ? "Stock compartido entre colores. Accesorios incluidos." : "Accesorios incluidos; recuento independiente pendiente." });
    }
    return { id, slug:m.slug, name:m.name, category:m.category.name, photo:photo(m.images[0]), bundleSize:m.bundleSize, included:m.includedAccessories.join("; "),
      note: m.tags.includes("foto-del-kit") ? "Camisa y pantalón confirmados. Foto actual del kit; falta foto del uniforme y recuento." : m.tags.includes("foto-estudio-ia") ? "Foto de presentación editada con IA. Tarifas y medidas por registrar." : "Foto de referencia. Tarifas y medidas por registrar." };
  });
  const normalized = (s:string) => s.toLowerCase().normalize("NFD").replace(/\p{Diacritic}/gu,"").replace(/folclorico/g,"cultural").replace(/folclor/g,"cultural");
  const includedNames = new Set(trajes.flatMap(m=>m.includedAccessories).map(normalized));
  const accessoryModels = all.filter(m => m.tags.includes("accesorio-fisico") || (m.slug.startsWith("real-pieza-") && includedNames.has(normalized(m.name)))).sort((a,b)=>a.name.localeCompare(b.name,"es"));
  const accessories = accessoryModels.map((m,i)=>{
    const relatedKits = kits.filter(k=>k.id===m.id || k.variants.some(v=>v.outfit?.components.some(c=>c.variant?.costumeId===m.id)) || looks.find(l=>`real-${l.key}`===k.slug)?.pieces.some(p=>typeof p!=="string" && p.alternatives?.some(key=>`real-pieza-${key}`===m.slug)));
    const relatedTrajes = trajes.filter(k=>k.includedAccessories.some(n=>normalized(n)===normalized(m.name)) || k.variants.some(v=>v.outfit?.components.some(c=>c.variant?.costumeId===m.id)));
    return { id:`ACC-${String(i+1).padStart(3,"0")}`, key:m.slug, name:m.name, photo:photo(relatedKits[0]?.images[0] || relatedTrajes[0]?.images[0] || m.images[0]),
      color: m.variants[0]?.color || "Por confirmar", size: pieces.find(p=>`real-pieza-${p.key}`===m.slug)?.sized ? "Por confirmar" : "Única", total:null, cleaning:null, repair:null, rented:null, price:null,
      kits:relatedKits.map(k=>k.name).join("; "), trajes:relatedTrajes.map(k=>k.name).join("; "),
      note:m.slug==="real-pieza-peineta-rosas" ? "Foto de referencia. Cantidad y tarifa pendientes." : relatedKits.length ? `Foto del kit${relatedKits[0].tags.includes("foto-estudio-ia") ? " editada con IA" : ""}. Cantidad, estado y tarifa pendientes.` : "Incluido con el traje. Foto de referencia del traje; falta foto individual y recuento." };
  });
  const kitRows=kits.map((m,i)=>{
    const components=m.variants[0]?.outfit?.components || [];
    return { id:`KIT-${String(i+1).padStart(3,"0")}`, name:m.name, photo:photo(m.images[0]), contents:components.length ? components.map(c=>`${c.quantity} × ${c.name}${c.required ? "" : " (opcional)"}`).join("; ") : m.name,
      componentIds: components.length ? components.filter(c=>c.required).map(c=>accessories.find(a=>a.key===all.find(r=>r.id===c.variant?.costumeId)?.slug)?.id).filter(Boolean) : [accessories.find(a=>a.key===m.slug)?.id].filter(Boolean),
      price:null, complete:m.tags.find(t=>t.startsWith("traje-relacionado:"))?.slice("traje-relacionado:".length) || "", note:`${m.tags.includes("foto-estudio-ia") ? "Foto editada con IA. " : ""}Utiliza las existencias de Accesorios. No sumar kits como piezas nuevas.` };
  });
  const result={ date:"2026-10-29", models, sizes:tallaRows, accessories, kits:kitRows,
    source:"Inventario del negocio y fotos aportadas. Cantidades de trajes confirmadas el 28/10/2026. Piloto completo confirmado el 29/10/2026.",
    totals:{ models:models.length, kits:kitRows.length, accessoryTypes:accessories.length, knownUnits:tallaRows.reduce((n,r)=>n+(r.total||0),0) } };
  await mkdir(".runtime/inventario-excel",{recursive:true});
  await writeFile(".runtime/inventario-excel/source.json",JSON.stringify(result,null,2));
  console.log(JSON.stringify(result.totals));
}
main().catch(e=>{console.error(e.message);process.exitCode=1;}).finally(()=>db.$disconnect());
