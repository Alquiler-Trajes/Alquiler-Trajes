import "dotenv/config";
import assert from "node:assert/strict";
import { PrismaClient } from "@prisma/client";
const db=new PrismaClient();
async function main(){
 const rows=await db.costume.findMany({where:{active:true,demo:false,tags:{has:"coleccion-real-octubre-2026"},NOT:{tags:{has:"pieza-de-conjunto"}}},include:{category:true,variants:{where:{active:true},include:{outfit:{include:{components:{include:{variant:{include:{units:true}}}}}},units:true}}}});
 const accessories=rows.filter(m=>m.tags.includes("accesorio-alquilable"));
 assert.equal(rows.length,38);assert.equal(accessories.length,9);
 assert(accessories.every(m=>m.category.slug==="accesorios"));
 assert(accessories.every(m=>m.tags.includes("cantidad-por-confirmar")));
 const pilot=rows.find(m=>m.slug==="real-piloto")!;
 const kit=rows.find(m=>m.slug==="real-kit-piloto")!;
 assert.equal(pilot.category.slug,"profesiones");
 const fullRefs=pilot.variants[0].outfit!.components.map(c=>c.variantId);
 const kitRefs=kit.variants[0].outfit!.components.map(c=>c.variantId);
 assert.equal(kitRefs.length,4);assert(kitRefs.every(id=>fullRefs.includes(id)));
 assert(pilot.variants[0].outfit!.components.some(c=>c.name==="Camisa y pantalón"));
 const allReady=await db.unit.count({where:{state:"READY",variant:{costume:{tags:{has:"coleccion-real-octubre-2026"}}}}});
 assert.equal(allReady,296);
 const accessoryReady=await db.unit.count({where:{state:"READY",variantId:{in:kitRefs.filter((id):id is string=>!!id)}}});
 assert.equal(accessoryReady,0);
 const oldArchived=await db.unit.count({where:{state:"RETIRED",variant:{costume:{tags:{has:"coleccion-real-octubre-2026"}}}}});
 assert.equal(oldArchived,759);
 console.log(JSON.stringify({publicModels:38,costumes:29,accessoryOffers:9,readyUnits:296,archivedUnits:759,pilotSharedComponents:4,accessoryQuantitiesPending:true}));
}
main().catch(e=>{console.error(e.message);process.exitCode=1;}).finally(()=>db.$disconnect());
