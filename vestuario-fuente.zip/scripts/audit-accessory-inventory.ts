import "dotenv/config";
import assert from "node:assert/strict";
import { PrismaClient } from "@prisma/client";
const db=new PrismaClient();
async function main(){
 const rows=await db.costume.findMany({where:{active:true,demo:false,tags:{has:"coleccion-real-octubre-2026"},NOT:{tags:{has:"pieza-de-conjunto"}}},include:{category:true,variants:{where:{active:true},include:{outfit:{include:{components:{include:{variant:{include:{units:true}}}}}},units:true}}}});
 const accessories=rows.filter(m=>m.tags.includes("accesorio-alquilable"));
 assert.equal(rows.length,48);assert.equal(accessories.length,14);
 assert(accessories.every(m=>m.category.slug==="accesorios"));
 assert(accessories.every(m=>m.tags.includes("cantidad-por-confirmar")));
 const pilot=rows.find(m=>m.slug==="real-piloto")!;
 assert.equal(rows.find(m=>m.slug==="real-kit-piloto"),undefined);
 const kit=await db.costume.findUniqueOrThrow({where:{slug:"real-kit-piloto"},include:{variants:{where:{active:true},include:{outfit:{include:{components:true}}}}}});
 assert.equal(kit.active,false);
 assert.equal(pilot.category.slug,"profesiones");
 const fullRefs=pilot.variants[0].outfit!.components.map(c=>c.variantId);
 const kitRefs=kit.variants[0].outfit!.components.map(c=>c.variantId);
 assert.equal(kitRefs.length,4);assert(kitRefs.every(id=>fullRefs.includes(id)));
 assert(pilot.variants[0].outfit!.components.some(c=>c.name==="Camisa blanca y pantalón negro"));
 const small=rows.find(m=>m.slug==="real-princesa-corona-varita")!.variants.find(v=>v.color==="Azul")!.outfit!.components.map(c=>c.variantId);
 const large=rows.find(m=>m.slug==="real-princesa-joyeria-azul")!.variants[0].outfit!.components.map(c=>c.variantId);
 assert.equal(small.length,2);assert(small.every(id=>large.includes(id)));
 const base=pilot.variants[0].outfit!.components.find(c=>c.name==="Camisa blanca y pantalón negro")!.variantId;
 for(const slug of ["real-marinero-completo","real-caballero-anos-20-completo","real-michael-jackson-completo","real-pirata-clasico-completo","real-vampiro-completo"]){
  assert(rows.find(m=>m.slug===slug)!.variants[0].outfit!.components.some(c=>c.variantId===base));
 }
 const allReady=await db.unit.count({where:{state:"READY",variant:{costume:{tags:{has:"coleccion-real-octubre-2026"}}}}});
 assert.equal(allReady,296);
 const accessoryReady=await db.unit.count({where:{state:"READY",variantId:{in:kitRefs.filter((id):id is string=>!!id)}}});
 assert.equal(accessoryReady,0);
 const oldArchived=await db.unit.count({where:{state:"RETIRED",variant:{costume:{tags:{has:"coleccion-real-octubre-2026"}}}}});
 assert.equal(oldArchived,759);
 console.log(JSON.stringify({publicModels:48,costumes:34,accessoryOffers:14,readyUnits:296,archivedUnits:759,pilotOnlyAsProfession:true,sharedBaseAndAccessories:true,accessoryQuantitiesPending:true}));
}
main().catch(e=>{console.error(e.message);process.exitCode=1;}).finally(()=>db.$disconnect());
