import http from "node:http";
import fs from "node:fs/promises";
import path from "node:path";
const root=path.resolve("outputs/instagram-alquileresbga");
const types={".html":"text/html; charset=utf-8",".js":"text/javascript; charset=utf-8",".json":"application/json; charset=utf-8",".jpg":"image/jpeg",".png":"image/png",".svg":"image/svg+xml",".webp":"image/webp",".txt":"text/plain; charset=utf-8"};
http.createServer(async(request,response)=>{
  try{
    const pathname=decodeURIComponent(new URL(request.url,"http://localhost").pathname);
    const file=path.resolve(root,"."+(pathname==="/"?"/index.html":pathname));
    const relative=path.relative(root,file);
    if(relative.startsWith("..")||path.isAbsolute(relative)){response.writeHead(403);response.end();return;}
    const content=await fs.readFile(file);
    response.writeHead(200,{"Content-Type":types[path.extname(file)]||"application/octet-stream","Cache-Control":"no-store"});response.end(content);
  }catch{response.writeHead(404);response.end("Archivo no encontrado");}
}).listen(8170,"127.0.0.1",()=>console.log("Revisión de Instagram: http://127.0.0.1:8170/"));
