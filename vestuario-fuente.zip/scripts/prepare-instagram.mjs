import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import {createRequire} from "node:module";
const root=process.cwd(), source=path.join(root,"social/instagram");
const destination=path.join(root,process.argv[2]||"outputs/instagram-alquileresbga");
const apiRequire=createRequire(path.join(root,"apps/api/package.json"));
const webRequire=createRequire(path.join(root,"apps/web/package.json"));
const sharp=apiRequire("sharp"), React=webRequire("react"), {renderToStaticMarkup}=webRequire("react-dom/server"), icons=webRequire("lucide-react");
const templates=createRequire(import.meta.url)(path.join(source,"plantillas.cjs"));
const data=JSON.parse(await fs.readFile(path.join(source,"contenido.json"),"utf8"));
const snapshot=JSON.parse(await fs.readFile(path.join(root,"apps/web/public/data/catalog.json"),"utf8"));
if(data.profile.bio.length>150) throw new Error("La bio supera los 150 caracteres.");
for(const folder of ["01-perfil","02-publicaciones","03-destacadas","04-historias","05-textos","originales-web"]) await fs.mkdir(path.join(destination,folder),{recursive:true});
data.icons={};
for(const [key,name] of Object.entries({flower:"Flower2",sparkles:"Sparkles",gem:"Gem",help:"CircleHelp",ruler:"Ruler",pin:"MapPin"})) data.icons[key]=renderToStaticMarkup(React.createElement(icons[name],{size:32,strokeWidth:1.5}));
data.photos={};
const photoKeys=new Set([...data.posts.flatMap(p=>p.slides.flatMap(s=>s.photos)),...data.stories.map(s=>s.photo).filter(Boolean)]);
for(const key of photoKeys) {
  const [slug,format]=key.split(":"), model=snapshot.items.find(item=>item.slug===slug);
  if(!model) throw new Error(`No existe el modelo ${slug}`);
  const file=format==="bundle"?model.bundleImage:model.images[0];
  if(!file?.startsWith("/media/")) throw new Error(`Referencia no revisada: ${key}`);
  const bytes=await fs.readFile(path.join(root,"apps/web/public",file));
  const name=`${slug}${format?"-juego-de-6":""}.webp`;
  await fs.writeFile(path.join(destination,"originales-web",name),bytes);
  const embedded=await sharp(bytes).jpeg({quality:96,chromaSubsampling:"4:4:4"}).toBuffer();
  data.photos[key]={name:model.name,source:file,slug,sha256:crypto.createHash("sha256").update(bytes).digest("hex"),data:`data:image/jpeg;base64,${embedded.toString("base64")}`};
}
const manifest={createdAt:new Date().toISOString(),profile:data.profile.handle,source:"apps/web/public/data/catalog.json",photos:Object.fromEntries(Object.entries(data.photos).map(([key,{data,...ref}])=>[key,ref])),assets:[]};
async function render(relative,svg,width,height,jpeg=false) {
  const target=path.join(destination,relative);
  await fs.mkdir(path.dirname(target),{recursive:true});
  await fs.writeFile(target+".svg",svg);
  const pipeline=sharp(Buffer.from(svg)).resize(width,height);
  const image=jpeg?await pipeline.jpeg({quality:96,chromaSubsampling:"4:4:4"}).toBuffer():await pipeline.png().toBuffer();
  await fs.writeFile(target+(jpeg?".jpg":".png"),image);
  const metadata=await sharp(image).metadata();
  if(metadata.width!==width||metadata.height!==height) throw new Error(`Dimensiones incorrectas: ${relative}`);
  manifest.assets.push({file:relative+(jpeg?".jpg":".png"),width,height,sha256:crypto.createHash("sha256").update(image).digest("hex")});
}
await render("01-perfil/imagen-perfil",templates.avatar(data),1080,1080);
for(const post of data.posts) {
  for(const [i,slide] of post.slides.entries()) {
    slide.file=`02-publicaciones/${post.id}/${String(i+1).padStart(2,"0")}`;
    await render(slide.file,templates.poster(slide,data),1080,1350,true);
  }
  await fs.writeFile(path.join(destination,"02-publicaciones",post.id,"texto-y-accesibilidad.txt"),`${post.title}\n${"=".repeat(post.title.length)}\n\n${post.caption}\n\nTEXTOS ALTERNATIVOS\n${post.slides.map((s,i)=>`${i+1}. ${s.alt}`).join("\n\n")}\n`);
}
for(const cover of data.highlights) await render(`03-destacadas/${cover.id}`,templates.cover(cover,data),1080,1920);
for(const story of data.stories) await render(`04-historias/${story.id}`,templates.story(story,data),1080,1920);
await fs.writeFile(path.join(destination,"contenido.js"),`window.INSTAGRAM_KIT=${JSON.stringify(data)};`);
await fs.copyFile(path.join(source,"plantillas.cjs"),path.join(destination,"plantillas.js"));
await fs.copyFile(path.join(source,"revision.html"),path.join(destination,"index.html"));
await fs.copyFile(path.join(source,"README.md"),path.join(destination,"GUIA-DE-ENTREGA.md"));
await fs.copyFile(path.join(source,"contenido.json"),path.join(destination,"contenido-editable.json"));
for(const file of ["publicaciones.json","PUBLICACIONES-EN-INSTAGRAM.txt"]) {
  await fs.copyFile(path.join(source,file),path.join(destination,file));
}
await fs.writeFile(path.join(destination,"referencias-y-validacion.json"),JSON.stringify(manifest,null,2));
await fs.writeFile(path.join(destination,"01-perfil","perfil-para-copiar.txt"),`PERFIL: @${data.profile.handle}\nNombre actual: ${data.profile.currentName}\nNombre sugerido: ${data.profile.suggestedName}\n\nBIO (${data.profile.bio.length}/150 caracteres)\n${data.profile.bio}\n\nENLACE\nTítulo: ${data.profile.linkTitle}\n${data.profile.website}\n\nInstagram indica que los enlaces se editan desde su aplicación móvil. Perfil > Editar perfil > Enlaces > Agregar enlace externo.\n\nLa bio y el avatar son revisables. No se añadieron teléfono, dirección, tarifas u horarios sin confirmar.\n`);
await fs.writeFile(path.join(destination,"05-textos","respuestas-para-copiar.txt"),data.quickReplies.map(reply=>`/${reply.shortcut}\n${reply.text}`).join("\n\n---\n\n"));
await fs.writeFile(path.join(destination,"05-textos","plan-de-publicacion.txt"),`PROPUESTA, SIN PROGRAMACIÓN AUTOMÁTICA\n\n${data.posts.map((p,i)=>`${i+1}. Semana ${p.week} · ${p.title}${p.pin?" · Sugerida para fijar":""}\nCarpeta: ${p.id}`).join("\n\n")}\n\nPublica los carruseles siguiendo el número de sus láminas. Las tres colecciones son publicaciones independientes: no hay imágenes partidas que dependan del orden de la cuadrícula.\n\nDespués de publicar y revisar, fija Cultura, Disfraces y Accesorios. Las portadas de destacadas no crean destacadas por sí solas: primero hay que publicar o tener archivadas las historias y luego agruparlas. Las historias de Cultura y Accesorios admiten el enlace a su colección; el rectángulo del diseño no sustituye al sticker de enlace de Instagram.\n\nEl nombre comercial, tarifas, garantías, horarios, dirección, teléfono y condiciones de entrega deben confirmarse con el negocio antes de añadirlos. No se propone una promesa de disponibilidad ni un horario óptimo sin datos propios.\n`);
await fs.writeFile(path.join(destination,"LEEME.txt"),`ALQUILERESBGA · KIT DE INSTAGRAM\n\nAbre index.html para revisar y corregir textos, títulos y láminas. Las correcciones se guardan en este navegador; usa «Guardar correcciones» para conservarlas en un JSON. Cada publicación permite copiar el texto y descargar su lámina en PNG. Las imágenes JPG originales para subir están en 02-publicaciones.\n\n01-perfil: avatar y datos del perfil.\n02-publicaciones: nueve publicaciones (17 láminas), textos y accesibilidad.\n03-destacadas: seis portadas con el icono centrado para recorte circular.\n04-historias: seis historias de presentación.\n05-textos: respuestas y propuesta de orden.\noriginales-web: copias exactas de las fotos revisadas del catálogo.\n\nLos diseños usan SVG editable, con las fotos insertadas completas y sin nuevos retoques. Feed: 1080×1350. Historias y portadas: 1080×1920. Avatar: 1080×1080. El manifiesto registra dimensiones y procedencia. Las publicaciones llevan referencia a la edición con IA.\n\nEste kit no publica ni envía mensajes. Bio y avatar, si se aplican a Instagram, se verifican por separado en la sesión del usuario. El enlace del catálogo debe añadirse desde la app móvil, según indica el propio formulario de Instagram.\n`);
console.log(JSON.stringify({destination,posts:data.posts.length,slides:data.posts.reduce((n,p)=>n+p.slides.length,0),highlights:data.highlights.length,stories:data.stories.length,bioLength:data.profile.bio.length,images:manifest.assets.length},null,2));
