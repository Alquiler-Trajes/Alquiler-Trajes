import { PrismaClient } from "@prisma/client";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { collectionTag, componentTag, looks, pieces } from "./real-collection";
import { folkLooks } from "./folk-collection";

export const policyId = "cultural-six-v1";
export const accessoryOnly = new Set(["charleston", "gangster", "marinero", "piloto", "hawaiano", "michael-jackson", "pirata-clasico", "pirata-corsario"]);
const boys = new Set(["campesino-clasico", "folclor-blanco-pechera", "camiseta-danza"]);
export const culturalText = (s: string) => s.replace(/folclóricos/gi, "culturales").replace(/folclóricas/gi, "culturales").replace(/folclórico/gi, "cultural").replace(/folclórica/gi, "cultural").replace(/Folclor/g, "Cultural").replace(/folclor/g, "cultural");

export async function applyCulturalPolicy(db: PrismaClient) {
  if (await db.auditLog.findFirst({ where: { action: "CULTURAL_POLICY", entityId: policyId } })) return;
  // This initial correction replaces assumptions made during the first import.
  // Never rewrite an outfit already used by a real rental.
  if (await db.rental.count({ where: { demo: false } })) throw new Error("Hay alquileres reales: revisar su inventario antes de aplicar la corrección inicial.");
  const backupDir = path.resolve(".runtime/backups");
  await mkdir(backupDir, { recursive: true });
  await writeFile(path.join(backupDir, `before-${policyId}-${Date.now()}.json`), JSON.stringify({
    categories: await db.category.findMany(),
    inventory: await db.costume.findMany({ include: { variants: { include: { units: { include: { measurements: true } }, outfit: { include: { components: { include: { options: true } } } } } } } }),
  }, null, 2));
  const culturalKeys = new Set(folkLooks.map(l => l.key));
  const baseKeys = new Set(looks.filter(l => !culturalKeys.has(l.key) && !accessoryOnly.has(l.key)).map(l => {
    const p = l.pieces[0]; return typeof p === "string" ? p : p.key;
  }));
  const baseSlugs = [...baseKeys].map(k => `real-pieza-${k}`);
  await db.$transaction(async tx => {
    for (const category of await tx.category.findMany()) {
      const name = category.slug === "folclor" ? "Arte y cultura" : category.slug === "bailes" ? "Trajes culturales" : culturalText(category.name);
      if (name !== category.name) await tx.category.update({ where: { id: category.id }, data: { name } });
    }
    // Accessory counts and former per-size cultural assumptions are archived,
    // retaining codes, movements and all historical records.
    const retired = await tx.unit.findMany({ where: { state: { not: "RETIRED" }, variant: { costume: { tags: { has: collectionTag }, slug: { notIn: baseSlugs } } } }, select: { id: true } });
    if (retired.length) {
      await tx.unit.updateMany({ where: { id: { in: retired.map(u => u.id) } }, data: { state: "RETIRED" } });
      await tx.movement.createMany({ data: retired.map(u => ({ unitId: u.id, type: "RETIRED", detail: "Corrección de carga inicial: seis trajes por modelo cultural y accesorios incluidos, sin stock independiente." })) });
    }
    await tx.costume.updateMany({ where: { tags: { has: collectionTag }, slug: { startsWith: "real-pieza-", notIn: baseSlugs } }, data: { active: false } });
    for (const look of looks) {
      const model = await tx.costume.findUniqueOrThrow({ where: { slug: `real-${look.key}` } });
      if (accessoryOnly.has(look.key)) {
        await tx.costume.update({ where: { id: model.id }, data: { active: false, tags: [...new Set([...model.tags, "accesorio-incluido"])] } });
        continue;
      }
      const cultural = culturalKeys.has(look.key);
      const colorways = look.colorways || [{ color: look.color, pieces: look.pieces }];
      const definitions = [...new Set(colorways.flatMap(c => c.pieces.map(p => typeof p === "string" ? p : p.key)))].map(k => pieces.find(p => p.key === k)!);
      const accessories = definitions.filter(p => cultural ? /sombrero|pañuelo|gorro|tocado|machete/i.test(p.name) : !baseKeys.has(p.key)).map(p => culturalText(p.name));
      let description = culturalText(look.description)
        .replace(/Fotografías del vestuario en presentación\./g, "")
        .replace(/Las opciones violeta, azul y verde se controlan por color y talla\./g, "Opciones violeta, azul y verde.")
        .replace(/, con existencias por talla y color/g, "")
        .replace(/La utilería se acuerda por separado\./g, "")
        .replace(/La utilería cultural es opcional y se acuerda por separado\./g, "La utilería correspondiente está incluida.")
        .replace(/El gorro blanco es una opción de presentación que se acuerda por separado\./g, "Sombrero o gorro según la presentación.")
        .replace(/Pañuelos de cabeza se escogen como accesorios opcionales\./g, "").trim();
      if (cultural) description += boys.has(look.key) ? " Seis unidades listas, talla Niño. Alquiler individual o juego de seis." : " Para niñas de 6.º y 7.º grado: tres unidades S y tres M listas. Alquiler individual o juego de seis.";
      await tx.costume.update({ where: { id: model.id }, data: {
        name: culturalText(model.name), description, bundleSize: cultural ? 6 : 1,
        includedAccessories: accessories, tags: [...new Set(model.tags.map(culturalText))],
        searchTerms: culturalText(`${model.searchTerms} ${accessories.join(" ")} ${cultural ? "escolar cultural juego de seis S M niño" : ""}`),
      } });
      if (!cultural) {
        const base = await tx.costume.findUniqueOrThrow({ where: { slug: `real-pieza-${definitions[0].key}` } });
        const outfits = await tx.outfit.findMany({ where: { variant: { costumeId: model.id } }, include: { components: { include: { variant: true } } } });
        for (const outfit of outfits) {
          await tx.outfitComponent.deleteMany({ where: { outfitId: outfit.id, id: { in: outfit.components.filter(c => c.variant?.costumeId !== base.id).map(c => c.id) } } });
          await tx.outfitComponent.updateMany({ where: { outfitId: outfit.id }, data: { name: "Traje", required: true } });
        }
        continue;
      }
      await tx.variant.updateMany({ where: { costumeId: model.id }, data: { active: false } });
      const pool = await tx.costume.create({ data: {
        slug: `real-pieza-cultural-${look.key}`, name: `Existencias · ${culturalText(model.name)}`,
        description: "Traje completo; accesorios correspondientes incluidos. Un único inventario compartido entre las opciones de color.",
        categoryId: model.categoryId, tags: [collectionTag, componentTag, "stock-cultural"], requiredMetrics: ["chest", "waist"],
        images: model.images, searchTerms: culturalText(model.name), demo: false,
      } });
      const allocation = boys.has(look.key) ? [{ size: "Niño", quantity: 6 }] : [{ size: "S", quantity: 3 }, { size: "M", quantity: 3 }];
      for (const { size, quantity } of allocation) {
        const physical = await tx.variant.create({ data: { costumeId: pool.id, size, color: "Colores del modelo", price: 0 } });
        for (let n = 1; n <= quantity; n++) await tx.unit.create({ data: {
          variantId: physical.id, code: `CULT-${look.key.toUpperCase()}-${size === "Niño" ? "NINO" : size}-${String(n).padStart(3, "0")}`,
          state: "READY", location: "Colección cultural", images: model.images,
          notes: "Cantidad y talla confirmadas por el negocio el 28/10/2026. Colores comparten stock; combinación por confirmar. Accesorios incluidos.",
          movements: { create: { type: "READY", detail: "Seis unidades por modelo según confirmación del negocio." } },
        } });
        for (const colorway of colorways) {
          const old = await tx.variant.findUnique({ where: { costumeId_size_color: { costumeId: model.id, size, color: colorway.color } } });
          const visible = old ? await tx.variant.update({ where: { id: old.id }, data: { active: true } }) : await tx.variant.create({ data: { costumeId: model.id, size, color: colorway.color, price: 0 } });
          const outfit = await tx.outfit.upsert({ where: { variantId: visible.id }, create: { variantId: visible.id, mode: "FLEXIBLE" }, update: { mode: "FLEXIBLE" } });
          await tx.outfitComponent.deleteMany({ where: { outfitId: outfit.id } });
          await tx.outfitComponent.create({ data: { outfitId: outfit.id, name: look.key === "camiseta-danza" ? "Camiseta de danza" : "Traje cultural", required: true, quantity: 1, variantId: physical.id } });
        }
      }
    }
    await tx.auditLog.create({ data: { action: "CULTURAL_POLICY", entityId: policyId, detail: { culturalModels: 12, totalCulturalUnits: 72, girlsPerModel: { S: 3, M: 3 }, boysPerModel: { Niño: 6 }, sharedStockAcrossColors: true, accessoriesIncluded: true, archivedAssumedUnits: retired.length } } });
  }, { timeout: 120000 });
  console.log("Inventario cultural: 12 modelos, 72 unidades. Accesorios incluidos. Historial conservado.");
}
