import { mkdirSync, writeFileSync } from "node:fs";
const dir = "apps/web/public/demo";
mkdirSync(dir, { recursive: true });
const designs = {
  mapale: ["#F1BB3F", "#B45236", "#ead8b9", "skirt"],
  cumbia: ["#fffaf0", "#BF3E46", "#eaded2", "skirt"],
  joropo: ["#BA3D35", "#FAEADC", "#ddcfc0", "skirt"],
  bambuco: ["#CE7193", "#F4DEBA", "#e3d7da", "skirt"],
  tango: ["#A82F3E", "#27242A", "#d4d3d3", "slim"],
  cenicienta: ["#88B9D2", "#D9EAF4", "#d5e0df", "princess"],
  blancanieves: ["#EAC157", "#345A83", "#e4dfcc", "princess"],
  doctora: ["#F7F5EC", "#86AFA7", "#dde3dc", "coat"],
  bombera: ["#B34432", "#EDB847", "#e4d7c7", "coat"],
  tocado: ["#B64740", "#568061", "#e3dbce", "flowers"],
};
for (const [name, [color, trim, bg, kind]] of Object.entries(designs)) {
  const skirt = kind === "skirt" || kind === "princess";
  let shape = skirt
    ? `<path d="M165 127 Q132 142 111 173 L137 196 158 173 167 232 233 232 242 173 264 196 289 173 Q269 142 235 127 L221 148 179 148Z" fill="${kind === "princess" ? trim : "#fcf7ed"}"/><path d="M168 223 Q148 282 75 370 Q196 438 325 370 Q255 286 232 223Z" fill="${color}"/><path d="M169 229 116 378 M185 230 160 392 M215 230 241 394 M230 229 286 378" stroke="#000" opacity=".08" fill="none" stroke-width="3"/><path d="M88 353 Q200 418 312 353 L325 370 Q200 440 75 370Z" fill="${trim}"/><path d="M99 337 Q200 390 301 337" fill="none" stroke="${trim}" stroke-width="9"/><path d="M165 219 235 219 233 233 167 233Z" fill="${trim}"/>${kind === "princess" ? `<path d="M168 232 Q152 286 103 338 Q167 328 200 276 Q236 330 298 338 Q249 284 233 232Z" fill="${trim}" opacity=".65"/><path d="M155 155 169 176 M246 155 231 176" stroke="${color}" stroke-width="12"/>` : `<path d="M149 149 Q201 183 252 149" fill="none" stroke="${trim}" stroke-width="13"/><path d="M125 170 Q201 212 275 170" fill="none" stroke="${trim}" stroke-width="6"/>`}`
    : kind === "coat"
      ? `<path d="M160 128 112 156 85 275 126 285 154 205 148 379 253 379 247 205 276 285 315 275 290 156 240 128 222 152 178 152Z" fill="${color}"/><path d="M177 141 198 188 160 214 M222 141 201 188 240 214" fill="none" stroke="${trim}" stroke-width="8"/><path d="M199 188 199 375" stroke="${trim}" stroke-width="3"/><path d="M155 268 183 268 183 298 155 298 M216 268 244 268 244 298 216 298" fill="${trim}" opacity=".8"/>${name === "bombera" ? `<path d="M104 233 135 242 M267 242 299 232 M149 338 251 338" stroke="${trim}" stroke-width="16"/><path d="M160 101 Q164 64 200 64 Q238 64 241 101 L253 112 147 112Z" fill="${color}"/><path d="M181 75 181 102 219 102 219 75" fill="${trim}"/>` : `<path d="M166 95 166 63 233 63 233 95Z" fill="${color}"/><path d="M199 69 199 89 M189 79 209 79" stroke="${trim}" stroke-width="6"/>`}`
      : kind === "slim"
        ? `<path d="M168 119 183 158 215 158 231 119 244 126 233 236 267 393 Q209 416 143 392 L167 235 155 126Z" fill="${color}"/><path d="M232 236 267 393 216 352Z" fill="${trim}"/><path d="M169 222 234 222" stroke="${trim}" stroke-width="12"/>`
        : `<path d="M125 273 Q199 206 275 273" fill="none" stroke="${trim}" stroke-width="18"/>${[135, 169, 204, 238, 270].map((x, i) => `<g transform="translate(${x} ${247 - Math.sin(i) * 20})"><circle cx="0" cy="0" r="23" fill="${color}"/><circle cx="-15" cy="-8" r="16" fill="${color}"/><circle cx="9" cy="-18" r="16" fill="${color}"/><circle cx="0" cy="0" r="9" fill="#eabc6c"/></g>`).join("")}`;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="400" height="480" viewBox="0 0 400 480"><defs><radialGradient id="b"><stop stop-color="#fff" stop-opacity=".6"/><stop offset="1" stop-color="${bg}"/></radialGradient><filter id="s"><feDropShadow dx="0" dy="14" stdDeviation="12" flood-opacity=".13"/></filter><pattern id="grain" width="8" height="8" patternUnits="userSpaceOnUse"><circle cx="2" cy="2" r=".6" fill="#000" opacity=".05"/></pattern></defs><rect width="400" height="480" fill="${bg}"/><rect width="400" height="480" fill="url(#b)"/><circle cx="200" cy="234" r="161" fill="#fff" opacity=".13"/><path d="M200 64 Q217 65 215 80 Q214 89 200 96 L200 112 M146 130 200 111 255 130" stroke="#8a7763" stroke-width="4" fill="none" stroke-linecap="round"/><g filter="url(#s)">${shape}</g><rect width="400" height="480" fill="url(#grain)"/><text x="200" y="454" text-anchor="middle" font-family="Arial,sans-serif" font-size="9" letter-spacing="3" fill="#5a574e" opacity=".7">ILUSTRACIÓN DE DEMOSTRACIÓN</text></svg>`;
  writeFileSync(`${dir}/${name}.svg`, svg);
}
console.log("Ilustraciones vectoriales demo creadas.");
