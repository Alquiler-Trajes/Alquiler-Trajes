import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { randomBytes } from "node:crypto";
if (!existsSync(".env")) {
  const password = randomBytes(18).toString("base64url");
  writeFileSync(
    ".env",
    readFileSync(".env.example", "utf8").replace(
      "ADMIN_PASSWORD=",
      "ADMIN_PASSWORD=" + password,
    ),
  );
  console.log(
    "Configuración creada en .env. La contraseña administrativa está únicamente en ese archivo.",
  );
} else console.log("Se conserva el archivo .env existente.");
