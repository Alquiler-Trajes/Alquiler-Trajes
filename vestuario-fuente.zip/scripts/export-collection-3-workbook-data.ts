import "dotenv/config";
import { PrismaClient } from "@prisma/client";
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
const db=new PrismaClient();
const norm=(s:string)=>s.toLowerCase().normalize("NFD").replace(/\p{Diacritic}/gu,"").replace(/folclorico/g,"cultural").replace(/folclor/g,"cultural");
async function main(){
 const previous=JSON.parse(await readFile(".runtime/inventario-excel/source-before-3.json","utf8"));
 const all=await db.costume.findMany({where:{tags:{has:"coleccion-real-octubre-2026"}},include:{category:true,variants:{where:{active:true},include:{outfit:{include:{components:{include:{variant:true,options:true}}}}}}}});
 const visible=all.filter(m=>m.active&&!m.tags.includes("pieza-de-conjunto"));
 const clothes=visible.filter(m=>!m.tags.includes("accesorio-alquilable"));
 const offers=visible.filter(m=>m.tags.includes("accesorio-alquilable"));
 const photo=(m:typeof all[number],color?:string)=>{
  const mapping=color?m.tags.find(t=>t.startsWith(`foto-color:${color}:`)):undefined;
  const index=mapping?Number(mapping.split(":").at(-1)):0;
  return m.images[index]?path.resolve(process.env.UPLOAD_DIR||"uploads",path.basename(m.images[index])):null;
 };
 let nextModel=Math.max(...previous.models.map((m:any)=>Number(m.id.slice(4))))+1;
 const modelIds=new Map<string,string>(previous.models.map((m:any)=>[m.slug,m.id]));
 const pilotId=modelIds.get("real-piloto")!;
 const base=all.find(m=>m.slug==="real-pieza-uniforme-piloto")!.variants[0].id;
 const sizes=previous.sizes.map((s:any)=>s.model===pilotId?{...s,color:"Blanco y negro"}:s);
 const models=clothes.map(m=>{
  const id=modelIds.get(m.slug)||`TRA-${String(nextModel++).padStart(3,"0")}`;
  const usesBase=m.variants.some(v=>v.outfit?.components.some(c=>c.variantId===base));
  return {id,slug:m.slug,name:m.name,category:m.category.name,photo:photo(m),bundleSize:m.bundleSize,included:m.includedAccessories.join("; "),
   stockModelId:usesBase?pilotId:id,note:(m.tags.includes("foto-estudio-ia")?"Foto de presentación editada con IA. ":"Foto de referencia. ")+(usesBase?"Camisa y pantalón comparten un único registro de existencias con piloto. Cantidades y tallas por confirmar.":"Tarifas y medidas por registrar.")};
 }).sort((a,b)=>a.id.localeCompare(b.id));
 const names=new Set(clothes.flatMap(m=>m.includedAccessories).map(norm));
 const physical=all.filter(m=>m.tags.includes("accesorio-fisico")||(m.slug.startsWith("real-pieza-")&&names.has(norm(m.name))));
 let nextAcc=Math.max(...previous.accessories.map((a:any)=>Number(a.id.slice(4))))+1;
 const accessories=physical.flatMap(m=>{
  const colors=[...new Set(m.variants.map(v=>norm(v.color)))];
  return colors.map(colorKey=>{
   const v=m.variants.find(v=>norm(v.color)===colorKey)!;
   const old=previous.accessories.find((a:any)=>a.key===m.slug&&norm(a.color)===colorKey);
   const relatedKits=offers.filter(k=>k.id===m.id||k.variants.some(kv=>kv.outfit?.components.some(c=>c.variantId===v.id||c.options.some(o=>o.variantId===v.id))));
   const relatedTrajes=clothes.filter(k=>k.includedAccessories.some(n=>norm(n)===norm(m.name))||k.variants.some(kv=>kv.outfit?.components.some(c=>c.variant?.costumeId===m.id)));
   const p=m.tags.includes("accesorio-alquilable")?photo(m,v.color):relatedKits[0]?photo(relatedKits[0],v.color):relatedTrajes[0]?photo(relatedTrajes[0]):photo(m,v.color);
   return {id:old?.id||`ACC-${String(nextAcc++).padStart(3,"0")}`,key:m.slug,variantId:v.id,name:m.name,color:v.color,size:old?.size||(v.size==="Única"?"Única":"Por confirmar"),photo:p,
    kits:relatedKits.map(k=>k.name).join("; "),trajes:relatedTrajes.map(k=>k.name).join("; "),note:"Referencia del accesorio, kit o traje asociado; las presentaciones de estudio están editadas con IA. Cantidad y tarifa por confirmar."};
  });
 }).sort((a,b)=>a.id.localeCompare(b.id));
 // Every previous physical row survives, even if its public offer was removed.
 for(const old of previous.accessories)if(!accessories.some(a=>a.id===old.id))accessories.push(old);
 accessories.sort((a,b)=>a.id.localeCompare(b.id));
 let nextKit=Math.max(...previous.kits.map((k:any)=>Number(k.id.slice(4))))+1;
 const kits:any[]=[];
 for(const m of offers)for(const v of m.variants){
  const parts=v.outfit?.components||[];
  const old=previous.kits.find((k:any)=>k.name===m.name);
  const name=m.variants.length>1?`${m.name} · ${v.color}`:m.name;
  const refs=parts.filter(c=>c.required&&c.variantId).map(c=>accessories.find(a=>a.variantId===c.variantId)?.id).filter(Boolean);
  if(!parts.length)refs.push(accessories.find(a=>a.key===m.slug&&norm(a.color)===norm(v.color))!.id);
  kits.push({id:old?.id||`KIT-${String(nextKit++).padStart(3,"0")}`,slug:m.slug,name,active:true,photo:photo(m,v.color),componentIds:refs,
   contents:parts.length?parts.map(c=>`${c.quantity} × ${c.name}${c.required?"":" (opcional)"}`).join("; "):`1 × ${m.name} · ${v.color}`,
   complete:m.tags.find(t=>t.startsWith("traje-relacionado:"))?.slice("traje-relacionado:".length)||"",note:"Usa las mismas existencias de Accesorios. No sumar como piezas nuevas. Capacidad con piezas base; sustituciones por confirmar."});
 }
 for(const old of previous.kits)if(!kits.some(k=>k.id===old.id))kits.push({...old,active:false,name:old.name+" · retirado de oferta",note:"Piloto se ofrece únicamente como traje completo en Profesiones. Registro anterior conservado."});
 kits.sort((a,b)=>a.id.localeCompare(b.id));
 const result={models,sizes,accessories,kits,totals:{models:models.length,physicalRows:accessories.length,accessoryTypes:physical.length,offers:offers.length,knownUnits:sizes.reduce((n:number,s:any)=>n+(s.total||0),0)}};
 await writeFile(".runtime/inventario-excel/delta3.json",JSON.stringify(result,null,2));
 console.log(JSON.stringify(result.totals));
}
main().catch(e=>{console.error(e.message);process.exitCode=1;}).finally(()=>db.$disconnect());
