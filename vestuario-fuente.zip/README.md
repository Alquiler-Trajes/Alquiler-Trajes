# Vestuario

Aplicación local de inventario y alquiler de trajes. Incluye catálogo público sin registro, búsqueda en español, orientación de tallas, inventario físico, conjuntos, solicitudes, reservas, entregas, devoluciones parciales, pagos e importación XLSX.

Los diseños del seed, sus precios, medidas, clientes e ilustraciones son **ficticios**. Las fotografías reales se incorporan desde administración. Ninguna ilustración se presenta como una fotografía del negocio.

La colección aportada en `Multimedia_Adjunta`, incluida su carpeta `2`, contiene **34 trajes, 14 ofertas de accesorios/kits y 296 unidades listas registradas**. El uniforme de piloto y las cantidades independientes de accesorios están por contar. Los doce modelos culturales suman 72 unidades: seis por modelo, distribuidas en 3 S + 3 M para niña o 6 Niño. Admiten alquiler x1 o juego x6 con stock compartido entre colores y accesorios incluidos. Hay 47 fichas con presentaciones de estudio editadas con IA; Spider-Man conserva su referencia porque la herramienta rechazó la edición. Las tarifas y las medidas reales siguen pendientes. Ver [inventario real](docs/inventario-real.md) para cantidades, fotos, archivo y gestión.

El inicio ofrece dos colecciones: **Danzas y princesas** (20 modelos) y **Profesiones y disfraces** (14 modelos). El orden de presentación es culturales, princesas, profesiones y disfraces. Las fotos se muestran en parejas, con marcos, letras grandes, animaciones discretas y controles con texto. La búsqueda y «Filtrar» aparecen dentro del catálogo; los detalles secundarios quedan plegados.

Cada modelo cultural tiene una foto ampliable del juego de seis. Un único selector «1 traje / Juego de 6» actualiza la fotografía y la selección; «Mis trajes» reúne cada juego en una sola tarjeta. El catálogo conserva los filtros por danza o región y permite reducir el movimiento según la preferencia del dispositivo. Dos etiquetas culturales siguen siendo provisionales.

El inicio también permite alquilar accesorios por separado. Piloto se ofrece únicamente como traje completo en Profesiones. La tercera entrega añade presentaciones completas y nuevas opciones de accesorios, con stock compartido entre combinaciones. Ver [tercera entrega](docs/coleccion-3.md). Hay un Excel privado con fotos, tallas, accesorios y kits; ver [accesorios y Excel](docs/accesorios.md).

## Página pública en GitHub Pages

Se incluye una versión estática con los 48 modelos reales, las fotos de estudio, doce vistas x6, filtros y selección guardada en el navegador. Permite copiar o descargar el resumen para compartirlo con el negocio. Las tarifas pendientes no se muestran como gratuitas. GitHub Pages sirve archivos estáticos; el inventario privado, la disponibilidad en tiempo real y las reservas requieren el servidor y PostgreSQL.

Página publicada: [https://alquiler-trajes.github.io/Alquiler-Trajes/](https://alquiler-trajes.github.io/Alquiler-Trajes/). Verificada el 28 de octubre de 2026. La entrega remota se publicó desde el navegador mediante un paquete compilado y una copia del código fuente; consulta [la guía de publicación](docs/github-pages.md). El flujo de esta copia local permite compilar y publicar desde código al subirlo a `main` o `master`.

```powershell
pnpm pages:build
pnpm pages:test
node scripts/preview-pages.mjs
```

La vista local equivalente abre en `http://127.0.0.1:8130/Alquiler-Trajes/`. No necesita la base de datos para compilar: el catálogo público revisado y sus imágenes están en `apps/web/public/data` y `apps/web/public/media`. Para actualizarlo desde el inventario local, ejecuta `pnpm pages:snapshot` antes de compilar y subir los cambios. Consulta [la guía de publicación](docs/github-pages.md).

## Requisitos

- Node.js 22.22 o superior; verificado con Node 26.8.1 en Windows.
- pnpm 10.30.3 (`npm install -g pnpm@10.30.3`).
- Docker Desktop iniciado, con contenedores Linux.
- Puertos libres: 3000 (web), 4000 (API) y 15432 (PostgreSQL, configurable con `DB_PORT`).
- Para las pruebas de navegador: Microsoft Edge instalado. Se puede cambiar `channel: 'msedge'` en `playwright.config.ts` por Chromium y ejecutar `pnpm exec playwright install chromium`.

## Instalar desde una copia nueva

Ejecutar en la raíz del repositorio:

```powershell
pnpm install --frozen-lockfile
pnpm setup
pnpm db:generate
pnpm db:up
pnpm db:migrate
pnpm db:seed
pnpm dev
```

`pnpm setup` crea `.env` únicamente si no existe y genera una contraseña administrativa aleatoria. No imprime la contraseña ni la guarda en Git. Abre ese archivo local para consultar `ADMIN_EMAIL` y `ADMIN_PASSWORD`.

Si PostgreSQL aún está arrancando al ejecutar la migración, espera a que `docker compose ps` muestre `healthy` y repite `pnpm db:migrate`.

- Catálogo: [http://127.0.0.1:3000](http://127.0.0.1:3000)
- Administración: [http://127.0.0.1:3000/admin](http://127.0.0.1:3000/admin)
- Swagger: [http://127.0.0.1:4000/api/docs](http://127.0.0.1:4000/api/docs)
- OpenAPI JSON: [http://127.0.0.1:4000/api/docs-json](http://127.0.0.1:4000/api/docs-json)
- Salud y conexión real: [http://127.0.0.1:4000/api/health](http://127.0.0.1:4000/api/health)

Para volver a iniciar una instalación ya configurada:

```powershell
pnpm db:up
pnpm dev
```

Detén los procesos de desarrollo con `Ctrl+C`. `docker compose stop db` detiene la base conservando su volumen. Los datos no se borran al reiniciar.

### Certificados corporativos en Windows

Si la descarga de motores Prisma informa `unable to verify the first certificate`, utiliza los certificados del sistema con Node moderno:

```powershell
$env:NODE_OPTIONS='--use-system-ca'
pnpm db:generate
```

No es necesario desactivar TLS.

## Variables de entorno

| Variable                        | Uso                                                                                                                                |
| ------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------- |
| `DATABASE_URL`                  | PostgreSQL. En Compose: `postgresql://vestuario:vestuario_local@localhost:15432/vestuario?schema=public`.                          |
| `DB_PORT`                       | Puerto local de PostgreSQL en Compose; predeterminado 15432. Debe coincidir con `DATABASE_URL`.                                  |
| `POSTGRES_PASSWORD`             | Contraseña del contenedor al crear un volumen nuevo. Si se cambia, ajustar también `DATABASE_URL`.                                 |
| `API_PORT`                      | Puerto NestJS, predeterminado 4000.                                                                                                |
| `API_HOST`                      | Dirección de escucha, predeterminada `127.0.0.1`.                                                                                  |
| `WEB_ORIGIN`                    | Origen permitido para mutaciones. Predeterminado `http://localhost:3000`; en desarrollo se acepta también `http://127.0.0.1:3000`. |
| `API_INTERNAL_URL`              | Destino de las reescrituras de Next, predeterminado `http://localhost:4000`. Se evalúa al iniciar desarrollo o compilar.           |
| `BUSINESS_TIMEZONE`             | `America/Bogota`. La interfaz utiliza expresamente hora colombiana.                                                                |
| `WHATSAPP_NUMBER`               | Número real del negocio con código de país, solo dígitos. Vacío hasta configurarlo.                                                |
| `UPLOAD_DIR`                    | Directorio local de fotografías. Predeterminado `./uploads`, relativo a la raíz.                                                   |
| `ADMIN_EMAIL`, `ADMIN_PASSWORD` | Datos del primer administrador para el seed; contraseña mínima de 12 caracteres.                                                   |
| `SEED_DEMO`                     | `true` crea ejemplos; `false` crea únicamente el administrador.                                                                    |

El seed es idempotente: no borra datos y no cambia la contraseña de un administrador existente al repetirlo. `SEED_DEMO=false` tampoco elimina ejemplos ya cargados. Para empezar sin demos, configúralo **antes del primer seed** sobre una base nueva, o archiva los diseños de demostración desde el panel.

## Primer uso del negocio

1. Ingresa al administrador con los valores de `.env`.
2. Crea o ajusta categorías. Puedes anidarlas sin ciclos.
3. Agrega un traje: foto, nombre, categoría, talla, color, cantidad y precio COP.
4. En **Gestionar**, agrega tallas, fotografías, ubicaciones, medidas y criterios reales de ajuste. Cada prenda tiene código, estado e historial propios.
5. Para un conjunto, crea su diseño base con **0 unidades**, después usa **Conjuntos → Armar conjunto**. Selecciona piezas específicas o variantes compatibles.
6. Configura `WHATSAPP_NUMBER` y reinicia la API. Una solicitud se guarda aunque WhatsApp no esté configurado.
7. Revisa **Alquileres** para confirmar solicitudes y asignar prendas, preparar, entregar, devolver y registrar pagos.

La entrega debe ocurrir dentro del intervalo reservado. Si cambia la fecha, usa **Ajustar fechas / registrar prórroga**. Una devolución coloca las prendas en limpieza o reparación; termina la revisión marcándolas como disponibles en inventario.

## Comandos de validación

```powershell
pnpm typecheck
pnpm test
pnpm test:integration
pnpm test:e2e
pnpm build
pnpm audit --prod
```

`pnpm test:all` ejecuta las tres suites. Las pruebas de integración y E2E construyen la API, crean la base independiente **vestuario_test** en el mismo servidor PostgreSQL y arrancan una API temporal en 4001. E2E arranca además Next en 3100 y usa Edge en escritorio y móvil emulado. No ejecutarlas simultáneamente entre sí. Se conserva el historial ficticio de pruebas y se utilizan identificadores únicos en cada ejecución.

La base de pruebas requiere permiso `CREATE DATABASE`, disponible en el usuario de desarrollo de Compose. Nunca apuntar estas herramientas al servidor de producción. Ver [estrategia y resultados](docs/testing.md).

## Estructura

```text
apps/
  api/src/             NestJS: autenticación, catálogo, inventario, reservas, XLSX
  web/src/app/         Next App Router: inicio, catálogo, detalle, solicitud y administración
  web/src/components/  Interfaz pública, formularios, panel y componentes reutilizables
  web/public/demo/     Ilustraciones vectoriales marcadas como demostración
packages/shared/src/   Interpretación de búsquedas, algoritmo de talla y formatos
prisma/
  schema.prisma        Modelo relacional
  migrations/          SQL versionado, índices, CHECK y exclusión GiST
  seed.ts              Administrador y demostración idempotente
tests/                 Pruebas unitarias, API/PostgreSQL y navegador
scripts/               Configuración local y generación de ilustraciones
docs/                  Arquitectura, API, negocio y validación
```

## Decisiones técnicas

- Next.js 16 App Router, React, TypeScript, Tailwind 4 y componentes de estilo shadcn con Radix Slot/CVA. Formularios principales con React Hook Form y Zod.
- NestJS 11 con Express, Prisma 6 y PostgreSQL 17. Se fija Prisma 6 para mantener el cliente CommonJS y migraciones SQL estables; las restricciones PostgreSQL específicas están en la migración.
- Cantidades físicas se representan con filas `Unit`, nunca con un contador editable en productos.
- Reservas en transacciones serializables con reintento de conflictos; exclusión GiST sobre intervalos semiabiertos `[inicio, fin)` por unidad, aplicada incluso a escrituras SQL directas.
- Asignación de conjuntos y artículos mediante emparejamiento bipartito de toda la solicitud. Evita usar una pieza dos veces y evita falsos faltantes por decisiones voraces.
- Búsqueda local con normalización, vocabulario, distancia de edición, texto completo PostgreSQL y trigramas. Una interfaz `QueryInterpreter` permite añadir un intérprete externo más adelante.
- Sesiones opacas con hash SHA-256 en base de datos, cookies HttpOnly/SameSite Strict, expiración de ocho horas y contraseñas bcrypt. El servidor protege toda la API administrativa.
- Almacenamiento abstraído mediante `ImageStorage`; implementación local con recodificación WebP y eliminación de metadatos. No necesita una cuenta de almacenamiento externa.

Detalles en [arquitectura](docs/architecture.md), [reglas de negocio](docs/business.md) y [API](docs/api.md).

## Compilar y ejecutar sin observadores

```powershell
pnpm build
pnpm start
```

Para un despliegue, configura `NODE_ENV=production`, HTTPS delante de Next, `WEB_ORIGIN` con el dominio real, credenciales PostgreSQL propias, respaldo de la base y de `uploads/`, y acceso privado a la API. En producción las cookies son `Secure` y requieren HTTPS. `pnpm start` no instala ni configura un servicio del sistema. El monorepositorio no fue publicado en un proveedor externo.

## Alcance y limitaciones

- WhatsApp abre un mensaje preparado; no envía mensajes automáticamente ni confirma reservas. El número real está pendiente de configurar.
- No incluye pasarela de pagos, facturación fiscal, cuentas de clientes ni permisos de personal. Existe una frontera administrativa del servidor para extenderla.
- La talla por edad es orientativa. Los conjuntos necesitan confirmar las medidas de cada componente; no se declara una talla verificada para el conjunto completo sin esa evaluación.
- Los componentes opcionales se documentan y se acuerdan con el negocio. No se asignan automáticamente ni se incluyen en el precio de la solicitud; pueden añadirse como artículo independiente.
- El precio es por alquiler, no por día; los depósitos se registran manualmente. Los pagos son asientos de registro, no movimientos bancarios.
- El catálogo tiene páginas de 24 diseños y ordenación local sobre inventario leído desde PostgreSQL. Para inventarios grandes conviene llevar toda la clasificación y paginación al motor SQL. Las listas de alquileres y clientes muestran los últimos 500 registros; los anteriores permanecen en PostgreSQL.
- La consulta de cantidad de conjuntos flexibles está acotada a 100, igual al máximo de cantidad por artículo.
- El cargador local no borra automáticamente fotografías sin referencias. Falta un proceso de limpieza y un adaptador S3 cuando se necesite.
- Las sesiones y el límite de solicitudes son adecuados para una instancia local. Para varias instancias, incorporar limitación distribuida y configurar cuidadosamente el proxy confiable. El límite actual se aplica a la dirección que ve la API.
- Sin recuperación de contraseña por correo, MFA ni copias de respaldo programadas. La publicación automática incluida cubre el catálogo estático en GitHub Pages; el servidor de reservas necesita alojamiento aparte. El código no depende de servicios pagos ni de IA externa durante el uso.
