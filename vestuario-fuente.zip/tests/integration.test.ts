import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { randomBytes } from "node:crypto";
import ExcelJS from "../apps/api/node_modules/exceljs";
import sharp from "../apps/api/node_modules/sharp";
import {
  base,
  call,
  headers,
  makeCostume,
  request,
  setupTestServer,
  stopTestServer,
  testDb,
  testId,
} from "./helpers";
beforeAll(() => setupTestServer(), 60000);
afterAll(stopTestServer);
describe("Catálogo y seguridad con API real", () => {
  it("separa las colecciones e incluye época y escenario antes de princesas", async () => {
    const key = "z" + randomBytes(8).toString("hex");
    const categories = await testDb.category.findMany();
    const princess = await makeCostume(1, `Princesa ${key}`);
    const profession = await makeCostume(1, `Profesión ${key}`);
    const costume = await makeCostume(1, `Disfraz ${key}`);
    const cultural = await makeCostume(1, `Cultural ${key}`);
    const stage = await makeCostume(1, `Escenario ${key}`);
    const danceCategory = await testDb.category.upsert({ where: { slug: "baile" }, create: { slug: "baile", name: "Baile y escenario" }, update: {} });
    await call(`/admin/costumes/${stage.id}`, "PATCH", { categoryId: danceCategory.id });
    for (const [model, slug] of [[princess, "princesas"], [profession, "profesiones"], [costume, "infantiles"]] as const) {
      await call(`/admin/costumes/${model.id}`, "PATCH", { categoryId: categories.find(c => c.slug === slug)!.id });
    }
    const first = (await call(`/catalog?group=celebraciones&q=${key}`, "GET", undefined, false)).data.items;
    const second = (await call(`/catalog?group=personajes&q=${key}`, "GET", undefined, false)).data.items;
    expect(first.map((i: any) => i.id)).toEqual([cultural.id, stage.id, princess.id]);
    expect(second.map((i: any) => i.id)).toEqual([profession.id, costume.id]);
    const filtered = (await call(`/catalog?group=celebraciones&kind=princess&q=${key}`, "GET", undefined, false)).data.items;
    expect(filtered.map((i: any) => i.id)).toEqual([princess.id]);
    const stageOnly = await call(`/catalog?group=celebraciones&kind=stage&q=${key}`, "GET", undefined, false);
    expect(stageOnly.status).toBe(200);
    expect(stageOnly.data.items.map((i: any) => i.id)).toEqual([stage.id]);
  });
  it("un juego 3S+3M comparte seis unidades entre colores y accesorios incluidos", async () => {
    const physical = await makeCostume(3, "Existencias culturales");
    await call(`/admin/costumes/${physical.id}`, "PATCH", { tags: ["pieza-de-conjunto"] });
    const m = await call(`/admin/costumes/${physical.id}/variants`, "POST", { size: "M", color: "Surtido", price: 0 });
    await call(`/admin/variants/${m.data.id}/units`, "POST", { quantity: 3 });
    const model = await makeCostume(0, "Traje cultural de seis");
    const edited = await call(`/admin/costumes/${model.id}`, "PATCH", { bundleSize: 6, danceStyle: "Tango", bundleImage: "/demo/mapale.svg", includedAccessories: ["Sombrero", "Pañuelo"] });
    expect(edited.status).toBe(200);
    await call(`/admin/variants/${model.variantId}`, "PATCH", { size: "S" });
    const variants = [{ id: model.variantId, pool: physical.variantId }];
    for (const [size, color, pool] of [["M", "Azul", m.data.id], ["S", "Verde", physical.variantId], ["M", "Verde", m.data.id]]) {
      const v = await call(`/admin/costumes/${model.id}/variants`, "POST", { size, color, price: 50000 });
      variants.push({ id: v.data.id, pool });
    }
    for (const v of variants) expect((await call("/admin/outfits", "POST", { variantId: v.id, mode: "FLEXIBLE", components: [{ name: "Traje cultural", required: true, quantity: 1, variantId: v.pool }] })).status).toBe(201);
    const startsAt = new Date(Date.now() + 5 * 86400000).toISOString(), endsAt = new Date(Date.now() + 6 * 86400000).toISOString();
    const items = variants.slice(0, 2).map(v => ({ variantId: v.id, quantity: 3 }));
    expect((await call("/catalog/selection/availability", "POST", { startsAt, endsAt, items }, false)).data.sufficient).toBe(true);
    expect((await call("/catalog/selection/availability", "POST", { startsAt, endsAt, items: [...items, { variantId: variants[2].id, quantity: 1 }] }, false)).data.sufficient).toBe(false);
    const created = await call("/requests", "POST", { name: testId, contact: "cliente-cultural-ficticio", startsAt, endsAt, items }, false);
    expect(created.status).toBe(201);
    const rental = await testDb.rental.findUniqueOrThrow({ where: { reference: created.data.reference } });
    expect((await call(`/admin/rentals/${rental.id}/status`, "PATCH", { status: "CONFIRMED" })).status).toBe(200);
    const allocations = await testDb.allocation.findMany({ where: { item: { rentalId: rental.id } } });
    expect(allocations).toHaveLength(6);
    expect(new Set(allocations.map(a => a.unitId)).size).toBe(6);
    expect((await call(`/catalog/variants/${variants[2].id}/availability?${new URLSearchParams({ startsAt, endsAt })}`, "GET", undefined, false)).data.available).toBe(0);
    const detail = (await call(`/catalog/${model.slug}`, "GET", undefined, false)).data;
    expect(detail.includedAccessories).toEqual(["Sombrero", "Pañuelo"]);
    expect(detail.danceStyle).toBe("Tango");
    expect(detail.bundleSize).toBe(6);
    expect(detail.bundleImage).toBe("/demo/mapale.svg");
    const filtered = await call("/catalog?style=Tango", "GET", undefined, false);
    expect(filtered.data.items.some((i: any) => i.id === model.id)).toBe(true);
    expect(filtered.data.items.every((i: any) => i.danceStyle?.includes("Tango"))).toBe(true);
    expect(filtered.data.styles.find((s: any) => s.name === "Tango").count).toBeGreaterThan(0);
  });
  it("agrupa categorías hijas y conserva solo el color elegido", async () => {
    const parent = await call("/admin/categories", "POST", { name: `Familia ${testId}` });
    const child = await call("/admin/categories", "POST", { name: `Diseño ${testId}`, parentId: parent.data.id });
    const c = await makeCostume(1, "Modelo de varios colores");
    await call(`/admin/costumes/${c.id}`, "PATCH", { categoryId: child.data.id });
    const green = await call(`/admin/costumes/${c.id}/variants`, "POST", { size: "6", color: "Verde", price: 40000 });
    const grouped = await call(`/catalog?category=${parent.data.id}`, "GET", undefined, false);
    expect(grouped.data.items.some((i: any) => i.id === c.id)).toBe(true);
    expect(grouped.data.categories.find((i: any) => i.id === parent.data.id).count).toBe(1);
    expect(grouped.data.navigationCategories.some((i: any) => i.id === child.data.id)).toBe(false);
    const filtered = await call(`/catalog?category=${parent.data.id}&color=Verde`, "GET", undefined, false);
    const model = filtered.data.items.find((i: any) => i.id === c.id);
    expect(model.variants).toHaveLength(1);
    expect(model.variants[0].id).toBe(green.data.id);
  });
  it("lista catálogo sin filtros y encuentra Mapalé", async () => {
    const all = await call("/catalog", "GET", undefined, false);
    expect(all.status).toBe(200);
    expect(all.data.total).toBeGreaterThan(10);
    const r = await call("/catalog?q=mapale", "GET", undefined, false);
    expect(r.data.items.some((i: any) => i.slug === "mapale")).toBe(true);
    const empty = await call("/catalog?q=xyzxyzxyz", "GET", undefined, false);
    expect(empty.data.items).toHaveLength(0);
    const realNames = new Set(
      (await testDb.costume.findMany({ select: { name: true } })).map(
        (c) => c.name,
      ),
    );
    expect(
      empty.data.suggestions.every((name: string) => realNames.has(name)),
    ).toBe(true);
  });
  it("Cenicienta con edad queda orientativa sin medidas", async () => {
    const r = await call(
      "/catalog?q=" +
        encodeURIComponent("Disfraz de Cenicienta para niña de 6 años"),
      "GET",
      undefined,
      false,
    );
    expect(r.data.intent.age).toBe(6);
    const v = r.data.items.find((i: any) => i.slug === "cenicienta")
      .variants[0];
    const fit = await call(
      "/catalog/variants/" + v.id + "/fit",
      "POST",
      {},
      false,
    );
    expect(
      fit.data.results.every(
        (f: any) => f.level === "ORIENTATIVE" && f.compatible === null,
      ),
    ).toBe(true);
  });
  it("rechaza acceso público al inventario y clientes", async () => {
    expect(
      (await call("/admin/inventory", "GET", undefined, false)).status,
    ).toBe(401);
    expect(
      (await call("/admin/customers", "GET", undefined, false)).status,
    ).toBe(401);
  });
  it("rechaza orígenes externos y campos inesperados", async () => {
    const r = await fetch(base + "/auth/logout", {
      method: "POST",
      headers: { Origin: "https://externo.invalid" },
    });
    expect(r.status).toBe(403);
    expect(
      (await call("/admin/categories", "POST", { name: "Prueba", admin: true }))
        .status,
    ).toBe(400);
  });
  it("crea varias unidades físicas únicas", async () => {
    const c = await makeCostume(4);
    const units = await testDb.unit.findMany({
      where: { variantId: c.variantId },
    });
    expect(units).toHaveLength(4);
    expect(new Set(units.map((u) => u.code)).size).toBe(4);
  });
  it("rechaza cargas que solo aparentan ser imágenes", async () => {
    const f = new FormData();
    f.append(
      "file",
      new Blob(["no es una imagen"], { type: "image/png" }),
      "falso.png",
    );
    const r = await fetch(base + "/admin/images", {
      method: "POST",
      headers: headers(),
      body: f,
    });
    expect(r.status).toBe(409);
  });
});
describe("Reservas, conjuntos y operación transaccional", () => {
  it("mantiene pendiente el precio real y permite fijarlo para todas las tallas", async () => {
    const c = await makeCostume();
    await call(`/admin/costumes/${c.id}`, "PATCH", { tags: ["coleccion-real-octubre-2026"] });
    await call(`/admin/variants/${c.variantId}`, "PATCH", { price: 0 });
    const second = await call(`/admin/costumes/${c.id}/variants`, "POST", { size: "M", color: "Azul", price: 0 });
    expect(second.status).toBe(201);
    const pending = await call("/requests", "POST", {
      name: "Prueba de precio pendiente", contact: "contacto-ficticio",
      startsAt: new Date(Date.now() + 86400000).toISOString(),
      endsAt: new Date(Date.now() + 2 * 86400000).toISOString(),
      items: [{ variantId: c.variantId, quantity: 1 }],
    }, false);
    expect(pending.status).toBe(409);
    const price = await call(`/admin/costumes/${c.id}/prices`, "PATCH", { price: 65000 });
    expect(price.status).toBe(200);
    expect(price.data.count).toBe(2);
    const variants = await testDb.variant.findMany({ where: { costumeId: c.id } });
    expect(variants.every(v => v.price === 65000)).toBe(true);
    const rental = await request(c.variantId);
    expect(rental.items[0].unitPrice).toBe(65000);
    await testDb.costume.update({ where: { id: c.id }, data: { active: false } });
  });
  it("mantiene piezas de conjuntos en inventario sin duplicarlas en el catálogo", async () => {
    const c = await makeCostume(1, "Componente oculto");
    await call(`/admin/costumes/${c.id}`, "PATCH", { tags: ["pieza-de-conjunto"] });
    const catalog = await call(`/catalog?q=${encodeURIComponent(c.name)}`, "GET", undefined, false);
    expect(catalog.data.items.some((i: any) => i.id === c.id)).toBe(false);
    const inventory = await call("/admin/inventory");
    expect(inventory.data.some((i: any) => i.id === c.id)).toBe(true);
    expect((await call(`/catalog/${c.slug}`, "GET", undefined, false)).status).toBe(200);
  });
  it("terminar limpieza conserva indisponibilidades futuras", async () => {
    const c = await makeCostume();
    const unit = await testDb.unit.findFirstOrThrow({
      where: { variantId: c.variantId },
    });
    const future = await call(`/admin/units/${unit.id}/blocks`, "POST", {
      startsAt: new Date(Date.now() + 10 * 86400000).toISOString(),
      endsAt: new Date(Date.now() + 11 * 86400000).toISOString(),
      kind: "ADMIN",
      reason: "Indisponibilidad futura de prueba",
    });
    expect(future.status).toBe(201);
    expect(
      (await call(`/admin/units/${unit.id}`, "PATCH", { state: "CLEANING" }))
        .status,
    ).toBe(200);
    expect(
      (await call(`/admin/units/${unit.id}`, "PATCH", { state: "READY" }))
        .status,
    ).toBe(200);
    expect(
      (
        await testDb.inventoryBlock.findUniqueOrThrow({
          where: { id: future.data.id },
        })
      ).active,
    ).toBe(true);
  });
  it("asigna sustituciones considerando todos los artículos de la solicitud", async () => {
    const a = await makeCostume(),
      b = await makeCostume(),
      set = await makeCostume(0, "Conjunto sustitución");
    const created = await call("/admin/outfits", "POST", {
      variantId: set.variantId,
      mode: "FLEXIBLE",
      components: [
        {
          name: "Pieza intercambiable",
          variantId: a.variantId,
          allowSubstitution: true,
          alternativeVariantIds: [b.variantId],
        },
      ],
    });
    expect(created.status).toBe(201);
    const start = new Date(Date.now() + 5 * 86400000).toISOString(),
      end = new Date(Date.now() + 6 * 86400000).toISOString();
    const result = await call(
      "/requests",
      "POST",
      {
        name: testId,
        contact: "contacto-ficticio",
        startsAt: start,
        endsAt: end,
        items: [
          { variantId: set.variantId, quantity: 1 },
          { variantId: a.variantId, quantity: 1 },
        ],
      },
      false,
    );
    const rental = await testDb.rental.findUniqueOrThrow({
      where: { reference: result.data.reference },
    });
    expect(
      (
        await call(`/admin/rentals/${rental.id}/status`, "PATCH", {
          status: "CONFIRMED",
        })
      ).status,
    ).toBe(200);
    const allocations = await testDb.allocation.findMany({
      where: { item: { rentalId: rental.id } },
    });
    expect(allocations).toHaveLength(2);
    expect(new Set(allocations.map((a) => a.unitId)).size).toBe(2);
    expect(
      (
        await call("/admin/outfits/" + created.data.id, "PATCH", {
          variantId: set.variantId,
          mode: "FLEXIBLE",
          components: [{ name: "Pieza actualizada", variantId: b.variantId }],
        })
      ).status,
    ).toBe(200);
    expect(
      await testDb.allocation.count({
        where: { item: { rentalId: rental.id } },
      }),
    ).toBe(2);
  });
  it("registra una devolución tardía aunque la siguiente reserva ya comenzó", async () => {
    const c = await makeCostume();
    const a = await request(
      c.variantId,
      1,
      new Date(Date.now() + 86400000).toISOString(),
      new Date(Date.now() + 2 * 86400000).toISOString(),
    );
    const b = await request(
      c.variantId,
      1,
      new Date(Date.now() + 2 * 86400000 + 1000).toISOString(),
      new Date(Date.now() + 3 * 86400000).toISOString(),
    );
    await call(`/admin/rentals/${a.id}/status`, "PATCH", {
      status: "CONFIRMED",
    });
    await call(`/admin/rentals/${b.id}/status`, "PATCH", {
      status: "CONFIRMED",
    });
    const before = new Date(Date.now() - 2 * 86400000),
      boundary = new Date(Date.now() - 86400000),
      future = new Date(Date.now() + 86400000);
    await testDb.inventoryBlock.updateMany({
      where: { rentalId: a.id },
      data: { startsAt: before, endsAt: boundary },
    });
    await testDb.rental.update({
      where: { id: a.id },
      data: { startsAt: before, endsAt: boundary, status: "DELIVERED" },
    });
    await testDb.inventoryBlock.updateMany({
      where: { rentalId: b.id },
      data: { startsAt: boundary, endsAt: future },
    });
    await testDb.rental.update({
      where: { id: b.id },
      data: { startsAt: boundary, endsAt: future },
    });
    const unit = await testDb.unit.findFirstOrThrow({
      where: { variantId: c.variantId },
    });
    const returned = await call(`/admin/rentals/${a.id}/return`, "POST", {
      units: [{ unitId: unit.id, condition: "CLEANING" }],
    });
    expect(returned.status).toBe(201);
    expect(returned.data.status).toBe("RETURNED");
    expect(
      (await testDb.unit.findUniqueOrThrow({ where: { id: unit.id } })).state,
    ).toBe("CLEANING");
    await call(`/admin/rentals/${b.id}/status`, "PATCH", {
      status: "PREPARING",
    });
    expect(
      (
        await call(`/admin/rentals/${b.id}/status`, "PATCH", {
          status: "DELIVERED",
        })
      ).status,
    ).toBe(409);
  });
  it("las solicitudes no bloquean; confirma una unidad y rechaza solapamiento", async () => {
    const c = await makeCostume();
    const a = await request(c.variantId),
      b = await request(c.variantId);
    expect(
      await testDb.inventoryBlock.count({
        where: { unit: { variantId: c.variantId } },
      }),
    ).toBe(0);
    expect(
      (
        await call(`/admin/rentals/${a.id}/status`, "PATCH", {
          status: "CONFIRMED",
        })
      ).status,
    ).toBe(200);
    expect(
      (
        await call(`/admin/rentals/${b.id}/status`, "PATCH", {
          status: "CONFIRMED",
        })
      ).status,
    ).toBe(409);
  });
  it("dos confirmaciones concurrentes solo asignan la unidad a una", async () => {
    const c = await makeCostume();
    const a = await request(c.variantId),
      b = await request(c.variantId);
    const results = await Promise.all(
      [a, b].map((r) =>
        call(`/admin/rentals/${r.id}/status`, "PATCH", { status: "CONFIRMED" }),
      ),
    );
    expect(results.map((r) => r.status).sort()).toEqual([200, 409]);
    expect(
      await testDb.inventoryBlock.count({
        where: { unit: { variantId: c.variantId }, active: true },
      }),
    ).toBe(1);
  });
  it("PostgreSQL rechaza solapamientos incluso fuera de la API", async () => {
    const c = await makeCostume();
    const unit = await testDb.unit.findFirstOrThrow({
      where: { variantId: c.variantId },
    });
    const interval = {
      unitId: unit.id,
      kind: "ADMIN" as const,
      startsAt: new Date("2032-01-01T09:00:00-05:00"),
      endsAt: new Date("2032-01-02T09:00:00-05:00"),
    };
    await testDb.inventoryBlock.create({ data: interval });
    await expect(
      testDb.inventoryBlock.create({ data: interval }),
    ).rejects.toThrow();
  });
  it("permite intervalos adyacentes y cancelación conserva historial", async () => {
    const c = await makeCostume();
    const a = await request(
        c.variantId,
        1,
        "2032-02-01T09:00:00-05:00",
        "2032-02-02T09:00:00-05:00",
      ),
      b = await request(
        c.variantId,
        1,
        "2032-02-02T09:00:00-05:00",
        "2032-02-03T09:00:00-05:00",
      );
    expect(
      (
        await call(`/admin/rentals/${a.id}/status`, "PATCH", {
          status: "CONFIRMED",
        })
      ).status,
    ).toBe(200);
    expect(
      (
        await call(`/admin/rentals/${b.id}/status`, "PATCH", {
          status: "CONFIRMED",
        })
      ).status,
    ).toBe(200);
    await call(`/admin/rentals/${a.id}/status`, "PATCH", {
      status: "CANCELLED",
    });
    expect(
      await testDb.inventoryBlock.count({
        where: { rentalId: a.id, active: false },
      }),
    ).toBe(1);
    expect(
      await testDb.allocation.count({ where: { itemId: a.items[0].id } }),
    ).toBe(1);
  });
  it("reserva un conjunto completo e impide reutilizar componentes", async () => {
    const a = await makeCostume(),
      b = await makeCostume(),
      s = await makeCostume(0, "Conjunto");
    const o = await call("/admin/outfits", "POST", {
      variantId: s.variantId,
      mode: "FLEXIBLE",
      components: [
        { name: "Falda", variantId: a.variantId },
        { name: "Blusa", variantId: b.variantId },
      ],
    });
    expect(o.status).toBe(201);
    const r = await request(s.variantId);
    const availabilityPath = `/catalog/variants/${s.variantId}/availability?startsAt=${r.startsAt.toISOString()}&endsAt=${r.endsAt.toISOString()}`;
    expect((await call(availabilityPath, "GET", undefined, false)).data.available).toBe(1);
    expect(
      (
        await call(`/admin/rentals/${r.id}/status`, "PATCH", {
          status: "CONFIRMED",
        })
      ).status,
    ).toBe(200);
    expect((await call(availabilityPath, "GET", undefined, false)).data.available).toBe(0);
    expect(
      await testDb.allocation.count({ where: { item: { rentalId: r.id } } }),
    ).toBe(2);
    const other = await request(a.variantId);
    expect(
      (
        await call(`/admin/rentals/${other.id}/status`, "PATCH", {
          status: "CONFIRMED",
        })
      ).status,
    ).toBe(409);
  });
  it("conjunto fijo usa exactamente sus unidades y admite una combinación", async () => {
    const piece = await makeCostume(),
      set = await makeCostume(0, "Conjunto fijo");
    const unit = await testDb.unit.findFirstOrThrow({
      where: { variantId: piece.variantId },
    });
    expect(
      (
        await call("/admin/outfits", "POST", {
          variantId: set.variantId,
          mode: "FIXED",
          components: [{ name: "Pieza fija", fixedUnitId: unit.id }],
        })
      ).status,
    ).toBe(201);
    const rental = await request(set.variantId);
    const availabilityPath = `/catalog/variants/${set.variantId}/availability?startsAt=${rental.startsAt.toISOString()}&endsAt=${rental.endsAt.toISOString()}`;
    expect((await call(availabilityPath, "GET", undefined, false)).data.available).toBe(1);
    expect(
      (
        await call(`/admin/rentals/${rental.id}/status`, "PATCH", {
          status: "CONFIRMED",
        })
      ).status,
    ).toBe(200);
    expect((await call(availabilityPath, "GET", undefined, false)).data.available).toBe(0);
    expect(
      (
        await testDb.allocation.findFirstOrThrow({
          where: { item: { rentalId: rental.id } },
        })
      ).unitId,
    ).toBe(unit.id);
  });
  it("entrega, devolución parcial, limpieza, pagos y cierre", async () => {
    const c = await makeCostume(2);
    const r = await request(c.variantId, 2);
    await call(`/admin/rentals/${r.id}/status`, "PATCH", {
      status: "CONFIRMED",
    });
    expect(
      (
        await call(`/admin/rentals/${r.id}/dates`, "PATCH", {
          startsAt: new Date(Date.now() - 3000).toISOString(),
          endsAt: r.endsAt.toISOString(),
        })
      ).status,
    ).toBe(200);
    await call(`/admin/rentals/${r.id}/status`, "PATCH", {
      status: "PREPARING",
    });
    expect(
      (
        await call(`/admin/rentals/${r.id}/status`, "PATCH", {
          status: "DELIVERED",
        })
      ).status,
    ).toBe(200);
    const allocations = await testDb.allocation.findMany({
      where: { item: { rentalId: r.id } },
    });
    const first = await call(`/admin/rentals/${r.id}/return`, "POST", {
      units: [{ unitId: allocations[0].unitId, condition: "CLEANING" }],
    });
    expect(first.data.status).toBe("DELIVERED");
    expect(
      (
        await testDb.unit.findUniqueOrThrow({
          where: { id: allocations[0].unitId },
        })
      ).state,
    ).toBe("CLEANING");
    const last = await call(`/admin/rentals/${r.id}/return`, "POST", {
      units: [
        {
          unitId: allocations[1].unitId,
          condition: "REPAIR",
          note: "Costura para revisar",
        },
      ],
    });
    expect(last.data.status).toBe("RETURNED");
    expect(
      (
        await call(`/admin/rentals/${r.id}/status`, "PATCH", {
          status: "CLOSED",
        })
      ).status,
    ).toBe(409);
    expect(
      (
        await call(`/admin/rentals/${r.id}/payments`, "POST", {
          kind: "RENT",
          amount: 100000,
          method: "Efectivo de prueba",
        })
      ).status,
    ).toBe(201);
    expect(
      (
        await call(`/admin/rentals/${r.id}/status`, "PATCH", {
          status: "CLOSED",
        })
      ).status,
    ).toBe(200);
    expect(
      (
        await call(`/admin/units/${allocations[0].unitId}`, "PATCH", {
          state: "READY",
        })
      ).status,
    ).toBe(200);
  });
  it("no deja devolver garantías o abonos inexistentes", async () => {
    const c = await makeCostume();
    const r = await request(c.variantId);
    expect(
      (
        await call(`/admin/rentals/${r.id}/payments`, "POST", {
          kind: "DEPOSIT_REFUND",
          amount: 1,
          method: "Prueba",
        })
      ).status,
    ).toBe(409);
  });
});
describe("Importación XLSX atómica", () => {
  it("acepta imágenes reales y las recodifica a WebP", async () => {
    const bytes = await sharp({
      create: { width: 20, height: 20, channels: 3, background: "#183e35" },
    })
      .png()
      .toBuffer();
    const form = new FormData();
    form.append(
      "file",
      new Blob([new Uint8Array(bytes)], { type: "image/png" }),
      "foto-prueba.png",
    );
    const response = await fetch(base + "/admin/images", {
      method: "POST",
      headers: headers(),
      body: form,
    });
    expect(response.status).toBe(201);
    const result = await response.json();
    expect(result.url).toMatch(/\.webp$/);
    const image = await fetch(base.replace("/api", "") + result.url);
    expect(image.headers.get("content-type")).toContain("image/webp");
  });
  it("rechaza archivos XLSX que no son ZIP válidos", async () => {
    const form = new FormData();
    form.append("file", new Blob([new Uint8Array(22)]), "invalido.xlsx");
    expect(
      (
        await fetch(base + "/admin/import/preview", {
          method: "POST",
          headers: headers(),
          body: form,
        })
      ).status,
    ).toBe(400);
  });
  const columns = [
    "Referencia",
    "Nombre",
    "Categoría",
    "Talla",
    "Color",
    "Cantidad",
    "Precio",
    "Ubicación",
  ];
  async function preview(rows: unknown[][]) {
    const book = new ExcelJS.Workbook();
    const sheet = book.addWorksheet("Inventario");
    sheet.addRow(columns);
    rows.forEach((r) => sheet.addRow(r));
    const bytes = await book.xlsx.writeBuffer();
    const form = new FormData();
    form.append(
      "file",
      new Blob([new Uint8Array(bytes as any)]),
      "inventario.xlsx",
    );
    const res = await fetch(base + "/admin/import/preview", {
      method: "POST",
      headers: headers(),
      body: form,
    });
    return res.json();
  }
  it("previsualiza sin modificar y confirma archivo válido", async () => {
    const data = await preview([
      [
        testId + "-EXCEL",
        "Diseño Excel " + testId,
        "Bailes tradicionales",
        "10",
        "Verde",
        3,
        45000,
        "Estante de prueba",
      ],
    ]);
    expect(data.valid).toBe(true);
    expect(
      await testDb.costume.count({ where: { name: "Diseño Excel " + testId } }),
    ).toBe(0);
    const commit = await call("/admin/import/commit", "POST", {
      rows: data.rows,
      confirmed: true,
    });
    expect(commit.status).toBe(201);
    expect(commit.data.units).toBe(3);
    expect(
      (
        await call("/admin/import/commit", "POST", {
          rows: data.rows,
          confirmed: true,
        })
      ).status,
    ).toBe(409);
  });
  it("filas inválidas no corrompen inventario y commit revalida", async () => {
    const count = await testDb.unit.count();
    const data = await preview([
      [
        testId + "-INVALID",
        "Inválido",
        "Bailes tradicionales",
        "6",
        "Azul",
        -2,
        1000,
        "",
      ],
      [
        testId + "-BADCAT",
        "Inválido",
        "Categoría inexistente",
        "6",
        "Azul",
        1,
        1000,
        "",
      ],
    ]);
    expect(data.valid).toBe(false);
    expect(data.errors).toHaveLength(2);
    expect(await testDb.unit.count()).toBe(count);
    const invalid = await call("/admin/import/commit", "POST", {
      rows: [{ quantity: -1 }],
      confirmed: true,
    });
    expect(invalid.status).toBe(400);
    expect(await testDb.unit.count()).toBe(count);
  });
});
