import "dotenv/config";
import { PrismaClient } from "@prisma/client";
import { spawn, spawnSync, type ChildProcess } from "node:child_process";
import path from "node:path";
import { randomBytes } from "node:crypto";
export const testId = "TEST-" + randomBytes(5).toString("hex");
export const testDatabaseUrl = (() => {
  const url = new URL(process.env.DATABASE_URL!);
  url.pathname = "/vestuario_test";
  return url.toString();
})();
export const testDb = new PrismaClient({ datasourceUrl: testDatabaseUrl });
export const base = "http://127.0.0.1:4001/api";
let server: ChildProcess | undefined;
let cookie = "";
export async function setupTestServer(origin = "http://localhost:3000") {
  const main = new PrismaClient();
  try {
    const existing = await main.$queryRaw<
      any[]
    >`SELECT datname FROM pg_database WHERE datname='vestuario_test'`;
    if (!existing.length)
      await main.$executeRawUnsafe("CREATE DATABASE vestuario_test");
  } finally {
    await main.$disconnect();
  }
  const env = {
    ...process.env,
    DATABASE_URL: testDatabaseUrl,
    API_PORT: "4001",
    WEB_ORIGIN: origin,
    SEED_DEMO: "true",
    UPLOAD_DIR: ".runtime/test-uploads",
  };
  const cli = path.resolve("node_modules/prisma/build/index.js");
  const migrate = spawnSync(process.execPath, [cli, "migrate", "deploy"], {
    env,
    encoding: "utf8",
  });
  if (migrate.status !== 0) throw new Error(migrate.stderr);
  const seed = spawnSync(
    process.execPath,
    ["--import", "tsx", "prisma/seed.ts"],
    { env, encoding: "utf8" },
  );
  if (seed.status !== 0) throw new Error(seed.stderr);
  server = spawn(process.execPath, ["apps/api/dist/apps/api/src/main.js"], {
    env,
    stdio: ["ignore", "pipe", "pipe"],
  });
  let output = "";
  server.stdout?.on("data", (b) => {
    output += b;
  });
  server.stderr?.on("data", (b) => {
    output += b;
  });
  for (let n = 0; n < 100; n++) {
    try {
      if ((await fetch(base + "/health")).ok) break;
    } catch {}
    if (n === 99) throw new Error("API de pruebas no inició: " + output);
    await new Promise((r) => setTimeout(r, 200));
  }
  const response = await fetch(base + "/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json", Origin: origin },
    body: JSON.stringify({
      email: process.env.ADMIN_EMAIL,
      password: process.env.ADMIN_PASSWORD,
    }),
  });
  if (!response.ok)
    throw new Error("No se pudo autenticar el administrador de pruebas.");
  cookie = response.headers.get("set-cookie")!.split(";")[0];
}
export async function stopTestServer() {
  server?.kill();
  await testDb.$disconnect();
}
export async function call(
  route: string,
  method = "GET",
  body?: unknown,
  auth = true,
) {
  const response = await fetch(base + route, {
    method,
    headers: {
      "Content-Type": "application/json",
      Origin: "http://localhost:3000",
      ...(auth ? { Cookie: cookie } : {}),
    },
    ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
  });
  const data = await response.json();
  return { status: response.status, data };
}
export function headers() {
  return { Cookie: cookie, Origin: "http://localhost:3000" };
}
export async function makeCostume(quantity = 1, name = "Prenda de prueba") {
  const category = await testDb.category.findFirstOrThrow({
    where: { slug: "bailes" },
  });
  const response = await call("/admin/costumes", "POST", {
    name: `${name} ${testId} ${randomBytes(3).toString("hex")}`,
    categoryId: category.id,
    size: "6",
    color: "Azul",
    price: 50000,
    quantity,
  });
  if (response.status !== 201) throw new Error(JSON.stringify(response));
  return response.data;
}
export async function request(
  variantId: string,
  quantity = 1,
  startsAt = new Date(Date.now() + 86400000).toISOString(),
  endsAt = new Date(Date.now() + 2 * 86400000).toISOString(),
) {
  const r = await call(
    "/requests",
    "POST",
    {
      name: testId,
      contact: "contacto-ficticio",
      startsAt,
      endsAt,
      items: [{ variantId, quantity }],
    },
    false,
  );
  if (r.status !== 201) throw new Error(JSON.stringify(r));
  return testDb.rental.findUniqueOrThrow({
    where: { reference: r.data.reference },
    include: { items: true },
  });
}
