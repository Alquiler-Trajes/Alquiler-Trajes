import { describe, expect, it } from "vitest";
import {
  evaluateFit,
  extractDates,
  LocalQueryInterpreter,
  normalize,
  relevance,
} from "../packages/shared/src";
const parser = new LocalQueryInterpreter();
describe("Interpretación local y relevancia", () => {
  it("Cenicienta con edad no implica talla", () => {
    const i = parser.interpret("Disfraz de Cenicienta para niña de 6 años");
    expect(i.age).toBe(6);
    expect(i.terms).toContain("cenicienta");
    expect(i.explanation[0]).toContain("necesitamos medidas");
  });
  it("normaliza Mapalé y mayúsculas", () =>
    expect(normalize("MAPALÉ")).toBe("mapale"));
  it("encuentra Mapalé sin tilde", () =>
    expect(
      relevance(parser.interpret("Trajes de mapale"), "Mapalé del Caribe"),
    ).toBeGreaterThan(0));
  it("tolera un error de escritura", () =>
    expect(parser.interpret("cenicenta").terms).toContain("cenicienta"));
  it("extrae cantidad sin confundir edad", () => {
    const i = parser.interpret(
      "Necesito 8 trajes de cumbia para una presentación",
    );
    expect(i.quantity).toBe(8);
    expect(i.age).toBeUndefined();
  });
  it("interpreta sinónimos y plurales", () =>
    expect(parser.interpret("Vestidos de princesa azules").color).toBe("azul"));
  it("reconoce profesiones", () =>
    expect(parser.interpret("Disfraces de médica para niñas").terms).toContain(
      "doctora",
    ));
  it("extrae fechas ISO", () =>
    expect(
      parser.interpret("joropo del 2026-11-01 al 2026-11-03").dates,
    ).toEqual(["2026-11-01", "2026-11-03"]));
  it("extrae fechas colombianas y rangos escritos", () => {
    const now = new Date("2026-10-27T14:00:00Z");
    expect(extractDates("cumbia del 5 al 7 de noviembre", now)).toEqual([
      "2026-11-05",
      "2026-11-07",
    ]);
    expect(extractDates("05/11/2026 a 07/11/2026", now)).toEqual([
      "2026-11-05",
      "2026-11-07",
    ]);
  });
  it("rechaza fechas inexistentes", () =>
    expect(extractDates("2026-02-31")).toEqual([]));
  it("una consulta vacía permite todo el catálogo", () =>
    expect(relevance(parser.interpret(""), "Cualquier diseño")).toBe(1));
  it("no inventa coincidencias", () =>
    expect(
      relevance(parser.interpret("astronauta"), "Cumbia tradicional"),
    ).toBe(0));
});
describe("Tallas con criterios registrados", () => {
  const measurements = [
    { metric: "chest", garmentCm: 68, easeCm: 4, bodyMinCm: 58 },
    { metric: "waist", garmentCm: 60, easeCm: 3, bodyMinCm: 49 },
  ];
  it("sin medidas es orientativa y no confirma ajuste", () => {
    const r = evaluateFit({}, measurements, ["chest", "waist"], false);
    expect(r.level).toBe("ORIENTATIVE");
    expect(r.compatible).toBeNull();
  });
  it("una medida da compatibilidad estimada", () => {
    const r = evaluateFit(
      { chest: 61 },
      measurements,
      ["chest", "waist"],
      false,
    );
    expect(r.level).toBe("ESTIMATED");
    expect(r.compatible).toBeNull();
  });
  it("verifica solo cuando existen todos los criterios", () => {
    const r = evaluateFit(
      { chest: 61, waist: 54 },
      measurements,
      ["chest", "waist"],
      false,
    );
    expect(r.level).toBe("VERIFIED");
    expect(r.compatible).toBe(true);
  });
  it("rechaza falta de holgura", () =>
    expect(
      evaluateFit(
        { chest: 66, waist: 54 },
        measurements,
        ["chest", "waist"],
        false,
      ).compatible,
    ).toBe(false));
  it("no inventa holgura faltante", () =>
    expect(
      evaluateFit(
        { chest: 61 },
        [{ metric: "chest", garmentCm: 68 }],
        ["chest"],
        false,
      ).level,
    ).toBe("ORIENTATIVE"));
  it("no inventa rangos de elasticidad", () =>
    expect(
      evaluateFit({ chest: 61 }, measurements, ["chest"], true).compatible,
    ).toBeNull());
  it("verifica un rango elástico real", () =>
    expect(
      evaluateFit(
        { chest: 61 },
        [{ metric: "chest", bodyMinCm: 58, bodyMaxCm: 66 }],
        ["chest"],
        true,
      ).compatible,
    ).toBe(true));
  it("rechaza una medida inferior al rango registrado", () =>
    expect(
      evaluateFit({ chest: 40 }, measurements, ["chest"], false).compatible,
    ).toBe(false));
  it("sin criterios nunca verifica", () =>
    expect(
      evaluateFit({ chest: 61 }, measurements, [], false).compatible,
    ).toBeNull());
  it("cumple exactamente el límite de holgura", () =>
    expect(
      evaluateFit({ chest: 64 }, measurements, ["chest"], false).compatible,
    ).toBe(true));
});
