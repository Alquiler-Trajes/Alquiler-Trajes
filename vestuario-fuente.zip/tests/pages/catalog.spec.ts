import { test, expect } from "@playwright/test";
test("El inicio ofrece dos colecciones y respeta el orden de los trajes", async ({ page }) => {
  await page.goto("./");
  await expect(page.locator(".collection-door")).toHaveCount(2);
  await expect(page.locator(".easy-product-card")).toHaveCount(0);
  await expect(page.getByRole("textbox")).toHaveCount(0);
  await expect(page.getByRole("link", { name: "Mis trajes 0", exact: true })).toBeVisible();
  await page.getByRole("link", { name: "Explorar Danzas y princesas", exact: true }).press("Enter");
  await expect(page.getByRole("heading", { name: "Danzas y princesas", exact: true })).toBeVisible();
  await expect(page.getByText("20 trajes para elegir", { exact: true })).toBeVisible();
  expect(await page.locator(".costume-section").evaluateAll(es => es.map(e => e.getAttribute("data-kind")))).toEqual(["cultural", "princess"]);
  await expect(page.locator(".easy-product-card")).toHaveCount(20);
  expect(await page.locator(".easy-product-grid").first().evaluate(e => getComputedStyle(e).gridTemplateColumns.split(" ").length)).toBe(2);
  await expect(page.getByLabel("Talla", { exact: true })).toBeHidden();
  await page.getByRole("link", { name: "Cambiar colección", exact: true }).click();
  await page.getByRole("link", { name: "Explorar Profesiones y disfraces", exact: true }).click();
  await expect(page.getByText("8 trajes para elegir", { exact: true })).toBeVisible();
  expect(await page.locator(".costume-section").evaluateAll(es => es.map(e => e.getAttribute("data-kind")))).toEqual(["profession", "costume"]);
  await expect(page.locator(".easy-product-card")).toHaveCount(8);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
});

test("El filtro se conserva y un solo selector controla el juego y su foto", async ({ page }) => {
  const failures: string[] = [];
  page.on("pageerror", error => failures.push(error.message));
  page.on("request", request => { if (request.url().includes("/api/")) failures.push("Llamada a API en catálogo estático"); });
  await page.goto("catalogo/?group=celebraciones");
  await expect(page.getByText("20 trajes para elegir", { exact: true })).toBeVisible();
  await page.locator(".easy-filters > summary").click();
  await page.getByLabel("Danza o región", { exact: true }).selectOption("Bambuco");
  await expect(page.getByText("2 trajes para elegir", { exact: true })).toBeVisible();
  await page.getByRole("link", { name: "Ver traje: Bambuco · aguamarina", exact: true }).click();
  await expect(page.getByRole("group", { name: "Formato de alquiler" })).toHaveCount(1);
  await expect(page.getByRole("group", { name: "Vista del vestuario" })).toHaveCount(0);
  await page.getByRole("button", { name: "Juego de 6", exact: true }).click();
  await expect(page.getByLabel("Elige tu talla", { exact: true })).toHaveCount(0);
  await page.getByRole("button", { name: "Ampliar fotografía del juego de 6", exact: true }).click();
  await expect(page.getByRole("dialog")).toBeVisible();
  await page.keyboard.press("Escape");
  await page.getByRole("link", { name: "Volver al catálogo", exact: true }).click();
  await page.locator(".easy-filters > summary").click();
  await expect(page.getByLabel("Danza o región", { exact: true })).toHaveValue("Bambuco");
  await page.getByRole("link", { name: "Ver traje: Bambuco · aguamarina", exact: true }).click();
  await page.getByRole("button", { name: "Elegir este traje", exact: true }).click();
  await expect(page.getByText("Ya está en tus trajes.", { exact: true })).toBeVisible();
  await page.getByRole("button", { name: "Juego de 6", exact: true }).click();
  await page.getByRole("button", { name: "Elegir juego de 6", exact: true }).click();
  await page.getByRole("link", { name: "Ver mis trajes", exact: true }).click();
  await expect(page.getByRole("heading", { name: "Mis trajes.", exact: true })).toBeVisible();
  await expect(page.locator(".cart-item")).toHaveCount(2);
  await expect(page.locator(".cart-bundle")).toHaveCount(1);
  await expect(page.locator(".cart-bundle")).toContainText("3 talla S + 3 talla M");
  await page.getByText("Ver resumen y otras opciones", { exact: true }).click();
  await expect(page.locator("pre")).toContainText("no es una reserva");
  const download = page.waitForEvent("download");
  await page.getByRole("button", { name: "Descargar resumen" }).click();
  expect((await download).suggestedFilename()).toBe("mi-seleccion-vestuario.txt");
  await page.reload();
  await expect(page.locator(".cart-bundle")).toHaveCount(1);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  expect(failures).toEqual([]);
});

test("La vista completa mantiene el orden al cargar más y permite reducir el movimiento", async ({ page }) => {
  await page.emulateMedia({ reducedMotion: "reduce" });
  await page.goto("./");
  expect(await page.locator(".collection-door").first().evaluate(e => getComputedStyle(e).animationName)).toBe("none");
  await page.setViewportSize({ width: 320, height: 800 });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  await page.goto("catalogo/");
  await expect(page.getByText("28 trajes para elegir", { exact: true })).toBeVisible();
  await expect(page.locator(".easy-product-card")).toHaveCount(24);
  await page.getByRole("button", { name: "Ver 4 trajes más", exact: true }).click();
  await expect(page.locator(".easy-product-card")).toHaveCount(28);
  expect(await page.locator(".costume-section").evaluateAll(es => es.map(e => e.getAttribute("data-kind")))).toEqual(["cultural", "princess", "profession", "costume"]);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
});

test("Todos los enlaces y fotos publicados son accesibles y no se piden credenciales", async ({ request, page }) => {
  const data = await (await request.get("data/catalog.json")).json();
  expect(data.items).toHaveLength(28);
  expect(data.items.filter((i: any) => i.bundleImage)).toHaveLength(12);
  expect(JSON.stringify(data)).not.toMatch(/"(calendar|units|password|measurements|contact)"/);
  for (const item of data.items) {
    expect((await request.get(`trajes/${item.slug}/`)).ok()).toBe(true);
    for (const image of [...item.images, item.bundleImage].filter(Boolean)) expect((await request.get(image.replace(/^\//, ""))).ok()).toBe(true);
  }
  await page.goto("admin/login/");
  await expect(page.getByRole("heading", { name: "Catálogo público" })).toBeVisible();
  await expect(page.getByLabel("Contraseña", { exact: true })).toHaveCount(0);
});
