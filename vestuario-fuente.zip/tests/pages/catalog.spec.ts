import { test, expect } from "@playwright/test";
test("El catálogo publicado funciona sin API y conserva el juego completo", async ({ page }) => {
  const failures: string[] = [];
  page.on("pageerror", error => failures.push(error.message));
  page.on("request", request => { if (request.url().includes("/api/")) failures.push("Llamada a API en catálogo estático"); });
  await page.goto("catalogo/");
  await expect(page.getByText("28 diseños para descubrir")).toBeVisible();
  await page.getByRole("group", { name: "Filtrar por danza o región" }).getByRole("button", { name: /^Bambuco/ }).click();
  await expect(page.getByText("2 diseños para descubrir")).toBeVisible();
  await page.getByRole("link", { name: /Bambuco · aguamarina/ }).click();
  await page.getByRole("button", { name: "Ver juego completo x6" }).click();
  await expect(page.getByRole("button", { name: "Una unidad · x1", exact: true })).toHaveAttribute("aria-pressed", "true");
  await page.getByRole("button", { name: "Ampliar fotografía del juego de 6" }).click();
  await expect(page.getByRole("dialog")).toBeVisible();
  await page.keyboard.press("Escape");
  await page.getByRole("button", { name: "Juego completo · x6", exact: true }).click();
  await page.getByRole("button", { name: "Agregar juego de 6", exact: true }).click();
  await page.getByRole("link", { name: "Ver mi selección", exact: true }).click();
  await expect(page.locator(".cart-bundle")).toHaveCount(1);
  await expect(page.locator(".cart-bundle")).toContainText("3 talla S + 3 talla M");
  await expect(page.getByRole("button", { name: "Copiar selección" })).toBeEnabled();
  await page.getByText("Ver resumen para compartir").click();
  await expect(page.locator("pre")).toContainText("no es una reserva");
  const download = page.waitForEvent("download");
  await page.getByRole("button", { name: "Descargar resumen" }).click();
  expect((await download).suggestedFilename()).toBe("mi-seleccion-vestuario.txt");
  await page.reload();
  await expect(page.locator(".cart-bundle")).toHaveCount(1);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  expect(failures).toEqual([]);
});

test("Todos los enlaces de producto y las fotos publicadas son accesibles", async ({ request, page }) => {
  const response = await request.get("data/catalog.json");
  const data = await response.json();
  expect(data.items).toHaveLength(28);
  expect(data.items.filter((i: any) => i.bundleImage)).toHaveLength(12);
  expect(JSON.stringify(data)).not.toMatch(/"(calendar|units|password|measurements|contact)"/);
  for (const item of data.items) {
    expect((await request.get(`trajes/${item.slug}/`)).ok()).toBe(true);
    for (const image of [...item.images, item.bundleImage].filter(Boolean))
      expect((await request.get(image.replace(/^\//, ""))).ok()).toBe(true);
  }
  await page.goto("admin/login/");
  await expect(page.getByRole("heading", { name: "Catálogo público" })).toBeVisible();
  await expect(page.getByLabel("Contraseña", { exact: true })).toHaveCount(0);
});
