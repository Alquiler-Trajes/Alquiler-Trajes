import { spawn } from "node:child_process";
import path from "node:path";
import { setupTestServer, stopTestServer } from "../helpers";
export default async function setup() {
  await setupTestServer("http://127.0.0.1:3100");
  const web = spawn(
    process.execPath,
    [
      path.resolve("apps/web/node_modules/next/dist/bin/next"),
      "dev",
      "--port",
      "3100",
      "--hostname",
      "127.0.0.1",
    ],
    {
      cwd: path.resolve("apps/web"),
      env: {
        ...process.env,
        API_INTERNAL_URL: "http://127.0.0.1:4001",
        NEXT_DIST_DIR: ".next-e2e",
      },
      stdio: "ignore",
    },
  );
  for (let n = 0; n < 100; n++) {
    try {
      if ((await fetch("http://127.0.0.1:3100")).ok) break;
    } catch {}
    if (n === 99) throw new Error("No inició la web de pruebas.");
    await new Promise((r) => setTimeout(r, 200));
  }
  return async () => {
    web.kill();
    await stopTestServer();
  };
}
