import { test, expect } from "@playwright/test";
import { randomBytes } from "node:crypto";
import { localBogota } from "../../apps/web/src/lib/api";
test("alquila x1 o juego x6 y conserva la distribución escolar en la solicitud", async ({ page }) => {
  const origin = { Origin: "http://127.0.0.1:3100" };
  expect((await page.request.post("/api/auth/login", { headers: origin, data: { email: process.env.ADMIN_EMAIL, password: process.env.ADMIN_PASSWORD } })).ok()).toBe(true);
  const categories = await (await page.request.get("/api/admin/categories")).json();
  const name = `Juego cultural E2E ${randomBytes(4).toString("hex")}`;
  const response = await page.request.post("/api/admin/costumes", { headers: origin, data: { name, categoryId: categories[0].id, size: "S", color: "Azul", price: 25000, quantity: 3, bundleSize: 6, danceStyle: "Bambuco", images: ["/demo/mapale.svg"], bundleImage: "/demo/cenicienta.svg", includedAccessories: ["Tocado floral"] } });
  expect(response.ok()).toBe(true);
  const model = await response.json();
  const m = await (await page.request.post(`/api/admin/costumes/${model.id}/variants`, { headers: origin, data: { size: "M", color: "Azul", price: 30000 } })).json();
  await page.request.post(`/api/admin/variants/${m.id}/units`, { headers: origin, data: { quantity: 3 } });
  await page.goto(`/catalogo?style=Bambuco&q=${encodeURIComponent(name)}`);
  await page.locator(".easy-filters > summary").click();
  await expect(page.getByLabel("Danza o región", { exact: true })).toHaveValue("Bambuco");
  await page.locator(`a[href="/trajes/${model.slug}"]`).click();
  await page.getByRole("button", { name: "Juego de 6", exact: true }).click();
  await expect(page.locator(".photo-open img")).toHaveAttribute("src", "/demo/cenicienta.svg");
  await expect(page.getByRole("button", { name: "Juego de 6", exact: true })).toHaveAttribute("aria-pressed", "true");
  await page.getByRole("button", { name: "Ampliar fotografía del juego de 6", exact: true }).click();
  await expect(page.getByRole("dialog", { name: "Fotografía ampliada" })).toBeVisible();
  await page.keyboard.press("Escape");
  await expect(page.getByRole("dialog", { name: "Fotografía ampliada" })).not.toBeVisible();
  await page.getByRole("link", { name: "Volver al catálogo", exact: true }).click();
  await page.locator(".easy-filters > summary").click();
  await expect(page.getByLabel("Danza o región", { exact: true })).toHaveValue("Bambuco");
  await page.locator(`a[href="/trajes/${model.slug}"]`).click();
  await page.getByText("Ver detalles del traje", { exact: true }).click();
  await expect(page.getByText("Tocado floral", { exact: true })).toBeVisible();
  await page.getByRole("button", { name: "Elegir este traje", exact: true }).click();
  await page.getByRole("button", { name: "Juego de 6", exact: true }).click();
  await expect(page.getByLabel("Elige tu talla", { exact: true })).toHaveCount(0);
  await page.getByText("Consultar fechas", { exact: true }).click();
  await page.getByLabel("Entrega · Bogotá", { exact: true }).fill("2030-05-15T09:00");
  await page.getByLabel("Devolución · Bogotá", { exact: true }).fill("2030-05-16T18:00");
  await page.getByRole("button", { name: "Consultar disponibilidad", exact: true }).click();
  await expect(page.getByText("Juego de seis disponible para estas fechas.", { exact: true })).toBeVisible();
  await page.getByRole("button", { name: "Elegir juego de 6", exact: true }).click();
  await page.getByRole("link", { name: "Ver mis trajes" }).click();
  await expect(page.locator(".cart-item")).toHaveCount(2);
  const packRows = page.locator(".cart-item").filter({ hasText: "Juego de 6" });
  await expect(packRows).toHaveCount(1);
  await expect(packRows.first().getByRole("spinbutton")).toHaveValue("6");
  await expect(packRows.first().getByRole("spinbutton")).toHaveAttribute("readonly", "");
  await packRows.first().getByRole("button", { name: `Quitar juego completo de ${name}` }).click();
  await expect(page.locator(".cart-item")).toHaveCount(1);
  await page.goto(`/trajes/${model.slug}`);
  await page.getByRole("button", { name: "Juego de 6", exact: true }).click();
  await page.getByRole("button", { name: "Elegir juego de 6", exact: true }).click();
  await page.getByRole("link", { name: "Ver mis trajes" }).click();
  await page.getByLabel("Tu nombre").fill(name);
  await page.getByLabel("Celular o correo").fill("cliente-juego-ficticio");
  await page.getByLabel("Entrega · hora de Bogotá").fill("2030-05-15T09:00");
  await page.getByLabel("Devolución · hora de Bogotá").fill("2030-05-16T18:00");
  const sent = page.waitForRequest(r => r.url().endsWith("/api/requests") && r.method() === "POST");
  await page.getByRole("button", { name: "Solicitar alquiler", exact: true }).click();
  const body = (await sent).postDataJSON();
  expect(body.items).toHaveLength(2);
  expect(body.items.find((i: any) => i.variantId === model.variantId).quantity).toBe(4);
  expect(body.items.find((i: any) => i.variantId === m.id).quantity).toBe(3);
  await expect(page.getByRole("heading", { name: "Recibimos tu solicitud." })).toBeVisible();
});
test("selección de color conserva la talla y agrega la variante correcta", async ({ page }) => {
  const login = await page.request.post("/api/auth/login", {
    headers: { Origin: "http://127.0.0.1:3100" },
    data: { email: process.env.ADMIN_EMAIL, password: process.env.ADMIN_PASSWORD },
  });
  expect(login.ok()).toBe(true);
  const categories = await (await page.request.get("/api/admin/categories")).json();
  const created = await page.request.post("/api/admin/costumes", {
    headers: { Origin: "http://127.0.0.1:3100" },
    data: { name: `Colores E2E ${randomBytes(4).toString("hex")}`, categoryId: categories[0].id, size: "6", color: "Azul", price: 25000, quantity: 1 },
  });
  const model = await created.json();
  const added = await page.request.post(`/api/admin/costumes/${model.id}/variants`, {
    headers: { Origin: "http://127.0.0.1:3100" }, data: { size: "6", color: "Verde", price: 30000 },
  });
  expect(added.ok()).toBe(true);
  const variant = await added.json();
  await page.request.post(`/api/admin/variants/${variant.id}/units`, { headers: { Origin: "http://127.0.0.1:3100" }, data: { quantity: 1 } });
  await page.goto(`/trajes/${model.slug}`);
  await page.getByLabel("Color", { exact: true }).selectOption("Verde");
  await expect(page.getByLabel("Elige tu talla", { exact: true })).toHaveValue(variant.id);
  await page.getByRole("button", { name: "Elegir este traje" }).click();
  await page.getByRole("link", { name: "Ver mis trajes" }).click();
  await expect(page.locator(".cart-item")).toContainText("Verde");
});
test("flujo de solicitud, confirmación, entrega, pago y devolución", async ({
  page,
}) => {
  await page.goto("/admin/login");
  await page.getByLabel("Correo electrónico").fill(process.env.ADMIN_EMAIL!);
  await page
    .getByLabel("Contraseña", { exact: true })
    .fill(process.env.ADMIN_PASSWORD!);
  await page.getByRole("button", { name: "Ingresar al administrador" }).click();
  await expect(
    page.getByRole("heading", { name: "Todo bajo control." }),
  ).toBeVisible();
  const categories = await (
    await page.request.get("/api/admin/categories")
  ).json();
  const name = "Ciclo E2E " + randomBytes(4).toString("hex");
  const created = await page.request.post("/api/admin/costumes", {
    headers: { Origin: "http://127.0.0.1:3100" },
    data: {
      name,
      categoryId: categories[0].id,
      size: "6",
      color: "Azul",
      price: 25000,
      quantity: 1,
    },
  });
  expect(created.ok()).toBe(true);
  const costume = await created.json();
  await page.goto("/trajes/" + costume.slug);
  await page.getByRole("button", { name: "Elegir este traje" }).click();
  await page.getByRole("link", { name: "Ver mis trajes" }).click();
  await page.getByLabel("Tu nombre").fill(name);
  await page.getByLabel("Celular o correo").fill("contacto-ciclo-ficticio");
  await page
    .getByLabel("Entrega · hora de Bogotá")
    .fill(localBogota(new Date(Date.now() + 300000).toISOString()));
  await page
    .getByLabel("Devolución · hora de Bogotá")
    .fill(localBogota(new Date(Date.now() + 86400000).toISOString()));
  await page
    .getByRole("button", { name: "Solicitar alquiler", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "Recibimos tu solicitud." }),
  ).toBeVisible();
  const reference = await page
    .locator(".confirmation-page > .badge")
    .innerText();
  await page.goto("/admin/alquileres");
  await page
    .getByRole("textbox", { name: "Buscar alquileres" })
    .fill(reference);
  await page.getByRole("button", { name: "Gestionar", exact: true }).click();
  const dialog = page.getByRole("dialog", { name: reference });
  await dialog
    .getByRole("button", { name: "Confirmar y asignar prendas" })
    .click();
  await expect(
    dialog.getByRole("button", { name: "Pasar a preparación" }),
  ).toBeVisible();
  await dialog.getByText("Ajustar fechas / registrar prórroga").click();
  await dialog
    .getByLabel("Entrega · Bogotá")
    .fill(localBogota(new Date(Date.now() - 300000).toISOString()));
  await dialog.getByRole("button", { name: "Guardar fechas" }).click();
  await expect(page.getByRole("status")).toContainText("Fechas actualizadas");
  await dialog.getByRole("button", { name: "Pasar a preparación" }).click();
  await dialog
    .getByRole("button", { name: "Registrar entrega", exact: true })
    .click();
  await expect(
    dialog.getByRole("heading", {
      name: "Registrar devolución total o parcial",
    }),
  ).toBeVisible();
  await dialog.getByLabel("Valor COP", { exact: true }).fill("25000");
  await dialog
    .getByRole("button", { name: "Registrar pago", exact: true })
    .click();
  await expect(page.getByRole("status")).toContainText(
    "Movimiento de pago registrado",
  );
  await dialog.getByRole("checkbox").check();
  await dialog
    .getByRole("button", { name: "Registrar 1 unidades devueltas" })
    .click();
  await expect(
    dialog.getByRole("button", { name: "Cerrar alquiler", exact: true }),
  ).toBeVisible();
  await dialog
    .getByRole("button", { name: "Cerrar alquiler", exact: true })
    .click();
  await expect(dialog.getByText("Cerrado", { exact: true })).toBeVisible();
});
test("búsqueda sin tilde y talla sin medidas", async ({ page }) => {
  await page.goto("/catalogo");
  await page
    .getByRole("textbox", { name: "Buscar en el catálogo" })
    .fill("mapale");
  await page
    .getByRole("button", { name: "Buscar", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "Mapalé del Caribe", exact: true }),
  ).toBeVisible();
  await page
    .getByRole("textbox", { name: "Buscar en el catálogo" })
    .fill("Cenicienta para niña de 6 años");
  await page.getByRole("button", { name: "Buscar" }).click();
  await page.getByText("Sobre esta búsqueda", { exact: true }).click();
  await expect(
    page.getByText(
      "6 años: referencia comercial; necesitamos medidas para confirmar la talla.",
    ),
  ).toBeVisible();
  await page
    .getByRole("heading", { name: "Cenicienta clásica", exact: true })
    .click();
  await page.getByText("Te ayudamos con la talla").click();
  await page.getByRole("button", { name: "Consultar compatibilidad" }).click();
  await expect(
    page.getByText("Todavía no podemos confirmar la talla.").first(),
  ).toBeVisible();
});
test("solicitud pública completa sin registro", async ({ page }) => {
  await page.goto("/trajes/cenicienta");
  await page.getByRole("button", { name: "Elegir este traje" }).click();
  await page.getByRole("link", { name: "Ver mis trajes" }).click();
  await page
    .getByLabel("Tu nombre")
    .fill("Cliente E2E ficticio " + randomBytes(3).toString("hex"));
  await page.getByLabel("Celular o correo").fill("contacto-e2e-ficticio");
  const start = new Date(Date.now() + 6 * 86400000).toISOString().slice(0, 16),
    end = new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 16);
  await page.getByLabel("Entrega · hora de Bogotá").fill(start);
  await page.getByLabel("Devolución · hora de Bogotá").fill(end);
  await page
    .getByRole("button", { name: "Solicitar alquiler", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "Recibimos tu solicitud." }),
  ).toBeVisible();
  await expect(
    page.getByText(/Tu solicitud todavía no es una reserva confirmada/),
  ).toBeVisible();
});
test("administración requiere sesión y crea varias unidades", async ({
  page,
}) => {
  await page.goto("/admin/inventario");
  await expect(page).toHaveURL(/\/admin\/login/);
  await page.getByLabel("Correo electrónico").fill(process.env.ADMIN_EMAIL!);
  await page
    .getByLabel("Contraseña", { exact: true })
    .fill(process.env.ADMIN_PASSWORD!);
  await page.getByRole("button", { name: "Ingresar al administrador" }).click();
  await expect(
    page.getByRole("heading", { name: "Todo bajo control." }),
  ).toBeVisible();
  await page.getByRole("link", { name: "Inventario", exact: true }).click();
  await page
    .getByRole("button", { name: "Agregar traje", exact: true })
    .click();
  const dialog = page.getByRole("dialog", { name: "Agregar un traje" });
  const name = "Prenda E2E " + randomBytes(4).toString("hex");
  await dialog.getByLabel("2. Nombre del traje").fill(name);
  await dialog
    .getByLabel("3. Categoría")
    .selectOption({ label: "Bailes tradicionales" });
  await dialog.getByLabel("4. Talla comercial").fill("12");
  await dialog.getByLabel("Color", { exact: true }).fill("Verde");
  await dialog.getByLabel("5. Unidades físicas").fill("3");
  await dialog.getByLabel("6. Precio de alquiler (COP)").fill("45000");
  await dialog.getByRole("button", { name: "Guardar traje" }).click();
  await expect(dialog).not.toBeVisible();
  await page.getByRole("textbox", { name: "Buscar inventario" }).fill(name);
  await expect(
    page.getByRole("cell", { name: "3 piezas listas", exact: true }),
  ).toBeVisible();
});
test("catálogo responsive sin desbordamiento", async ({ page }) => {
  await page.goto("/catalogo?q=cenicienta");
  await expect(
    page.getByRole("heading", { name: "Todos los trajes", exact: true }),
  ).toBeVisible();
  await expect(
    page.getByRole("heading", { name: "Cenicienta clásica", exact: true }),
  ).toBeVisible();
  const overflow = await page.evaluate(
    () => document.documentElement.scrollWidth > window.innerWidth + 1,
  );
  expect(overflow).toBe(false);
});
