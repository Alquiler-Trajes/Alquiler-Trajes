import { defineConfig, devices } from "@playwright/test";
export default defineConfig({
  testDir: "./tests/pages", workers: 1, timeout: 45000, expect: { timeout: 12000 },
  use: { baseURL: "http://127.0.0.1:8130/Alquiler-Trajes/", screenshot: "only-on-failure" },
  projects: [
    { name: "desktop", use: { ...devices["Desktop Edge"], channel: "msedge" } },
    { name: "mobile", use: { ...devices["iPhone 13"], defaultBrowserType: "chromium", channel: "msedge" } },
  ],
  webServer: { command: "node scripts/preview-pages.mjs", url: "http://127.0.0.1:8130/Alquiler-Trajes/", reuseExistingServer: true },
});
