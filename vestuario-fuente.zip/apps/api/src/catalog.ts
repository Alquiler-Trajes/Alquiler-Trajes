import {
  Body,
  Controller,
  ConflictException,
  Get,
  Injectable,
  NotFoundException,
  Param,
  Post,
  Query,
} from "@nestjs/common";
import { ApiBody, ApiTags } from "@nestjs/swagger";
import { Prisma } from "@prisma/client";
import {
  evaluateFit,
  LocalQueryInterpreter,
  relevance,
} from "@vestuario/shared";
import { z } from "zod";
import { Db } from "./db";
import { Availability, variantInclude } from "./availability";
import { intervalSchema } from "./validation";
@Injectable()
export class Catalog {
  constructor(
    private db: Db,
    private availability: Availability,
  ) {}
  async search(query: Record<string, string>) {
    const q = z
      .object({
        q: z.string().max(300).default(""),
        category: z.string().max(100).optional(),
        size: z.string().max(100).optional(),
        color: z.string().max(100).optional(),
        style: z.string().max(100).optional(),
        startsAt: z.string().optional(),
        endsAt: z.string().optional(),
        onlyAvailable: z.enum(["true", "false"]).optional(),
        sort: z
          .enum(["relevance", "price-asc", "price-desc", "name"])
          .default("relevance"),
        page: z.coerce.number().int().min(1).max(10000).default(1),
        collection: z.enum(["all", "current", "demo"]).default("all"),
      })
      .strict()
      .parse(query);
    const intent = new LocalQueryInterpreter().interpret(q.q);
    const start =
        q.startsAt ||
        (intent.dates[0] ? `${intent.dates[0]}T09:00:00-05:00` : undefined),
      end =
        q.endsAt ||
        (intent.dates[1] ? `${intent.dates[1]}T18:00:00-05:00` : undefined);
    if (q.startsAt || q.endsAt || (start && end))
      intervalSchema.parse({ startsAt: start, endsAt: end });
    const categories = await this.db.category.findMany();
    const categoryIds = new Set(q.category ? [q.category] : []);
    for (let i = 0; i < categories.length; i++)
      for (const c of categories)
        if (c.parentId && categoryIds.has(c.parentId)) categoryIds.add(c.id);
    const hasRealCollection = !!(await this.db.costume.findFirst({
      where: { active: true, demo: false, tags: { has: "coleccion-real-octubre-2026" } },
      select: { id: true },
    }));
    const collectionWhere: Prisma.CostumeWhereInput = {
        active: true,
        NOT: { tags: { has: "pieza-de-conjunto" } },
        ...(q.collection === "demo" ? { demo: true } : q.collection === "current" && hasRealCollection ? { demo: false } : {}),
        variants: { some: { active: true } },
    };
    const categoryCounts = await this.db.costume.groupBy({ by: ["categoryId"], where: collectionWhere, _count: true });
    const labeled = await this.db.costume.findMany({ where: { ...collectionWhere, danceStyle: { not: null } }, select: { danceStyle: true } });
    const styles = [...new Set(labeled.flatMap(m => (m.danceStyle || "").split(" / ").filter(Boolean)))].sort((a, b) => a.localeCompare(b, "es")).map(name => ({ name, count: labeled.filter(m => m.danceStyle?.split(" / ").includes(name)).length }));
    const directCounts = new Map(categoryCounts.map(c => [c.categoryId, c._count]));
    const countedCategories = categories.map(c => {
      const descendants = new Set([c.id]);
      for (let i = 0; i < categories.length; i++)
        for (const child of categories)
          if (child.parentId && descendants.has(child.parentId)) descendants.add(child.id);
      return { ...c, count: [...descendants].reduce((n, id) => n + (directCounts.get(id) || 0), 0) };
    });
    const visibleCategories = countedCategories.filter(c => c.count > 0);
    const technicalParents = new Set(["infantiles", "folclor"]);
    const navigationCategories = visibleCategories.filter(c => !technicalParents.has(c.slug) && (!c.parentId || technicalParents.has(categories.find(p => p.id === c.parentId)?.slug || "")));
    const familyOrder = ["bailes", "fantasia", "princesas", "personajes", "profesiones", "baile", "fiesta", "accesorios"];
    navigationCategories.sort((a, b) => familyOrder.indexOf(a.slug) - familyOrder.indexOf(b.slug));
    const rows = await this.db.costume.findMany({
      where: {
        ...collectionWhere,
        ...(q.category ? { categoryId: { in: [...categoryIds] } } : {}),
        ...(q.style ? { danceStyle: { contains: q.style, mode: "insensitive" as const } } : {}),
      },
      include: {
        category: true,
        variants: {
          where: { active: true },
          include: {
            outfit: true,
            _count: { select: { units: { where: { state: "READY" } } } },
          },
        },
      },
    });
    // SQL ranking complements deterministic vocabulary and typo interpretation.
    const terms = intent.terms.join(" ");
    const ranked = terms
      ? await this.db.$queryRaw<{ id: string; score: number }[]>(
          Prisma.sql`SELECT id, (ts_rank(to_tsvector('spanish', name || ' ' || description || ' ' || "searchTerms"), plainto_tsquery('spanish', ${terms})) + similarity(lower(name || ' ' || "searchTerms"), ${terms}))::float8 AS score FROM "Costume" WHERE active = true`,
        )
      : [];
    const ranks = new Map(ranked.map((r) => [r.id, r.score]));
    const output = [];
    for (const row of rows) {
      const score = relevance(
        intent,
        [
          row.name,
          row.description,
          row.searchTerms,
          ...row.tags,
          row.danceStyle || "",
          ...row.includedAccessories,
          row.category.name,
          ...row.variants.map((v) => v.color),
        ].join(" "),
      );
      if (intent.terms.length && score === 0 && (ranks.get(row.id) || 0) < 0.16)
        continue;
      const variants = [];
      for (const v of row.variants) {
        if (q.size && v.size !== q.size) continue;
        const color = q.color || intent.color;
        if (color && relevance({ ...intent, terms: [color] }, v.color) === 0)
          continue;
        const available =
          start && end
            ? await this.availability.count(
                v.id,
                new Date(start),
                new Date(end),
                intent.quantity,
              )
            : undefined;
        if (q.onlyAvailable === "true" && (!available || !available.sufficient))
          continue;
        variants.push({
          id: v.id,
          size: v.size,
          color: v.color,
          price: v.price,
          commercialAgeMin: v.commercialAgeMin,
          commercialAgeMax: v.commercialAgeMax,
          isOutfit: !!v.outfit,
          physicalUnits: v._count.units,
          ...available,
        });
      }
      if (!variants.length) continue;
      const { variants: _, ...model } = row;
      output.push({
        ...model,
        variants,
        score: score + (ranks.get(row.id) || 0),
        minPrice: Math.min(...variants.map((v) => v.price)),
      });
    }
    output.sort((a, b) =>
      q.sort === "price-asc"
        ? a.minPrice - b.minPrice
        : q.sort === "price-desc"
          ? b.minPrice - a.minPrice
          : q.sort === "name"
            ? a.name.localeCompare(b.name, "es")
            : b.score - a.score ||
              Number(b.featured) - Number(a.featured) ||
              a.name.localeCompare(b.name, "es"),
    );
    return {
      items: output.slice((q.page - 1) * 24, q.page * 24),
      total: output.length,
      page: q.page,
      hasRealCollection,
      intent,
      suggestions: output.length ? [] : rows.slice(0, 4).map((row) => row.name),
      categories: visibleCategories,
      navigationCategories,
      styles,
      filters: {
        sizes: [...new Set(rows.flatMap((r) => r.variants.map((v) => v.size)))].sort((a, b) => {
          const adult = ["XS", "S", "M", "L", "XL", "XXL", "Única"];
          const rank = (s: string) => /^\d+$/.test(s) ? Number(s) : 1000 + (adult.includes(s) ? adult.indexOf(s) : 100);
          return rank(a) - rank(b) || a.localeCompare(b, "es");
        }),
        colors: [
          ...new Set(rows.flatMap((r) => r.variants.map((v) => v.color))),
        ],
      },
      dates: start && end ? { startsAt: start, endsAt: end } : null,
    };
  }
  async detail(slug: string) {
    const row = await this.db.costume.findFirst({
      where: { OR: [{ slug }, { id: slug }], active: true },
      include: {
        category: true,
        variants: { where: { active: true }, include: variantInclude },
      },
    });
    if (!row) throw new NotFoundException("No se encontró el traje.");
    return {
      ...row,
      variants: await Promise.all(
        row.variants.map(async (v) => ({
          id: v.id,
          size: v.size,
          color: v.color,
          price: v.price,
          elastic: v.elastic,
          commercialAgeMin: v.commercialAgeMin,
          commercialAgeMax: v.commercialAgeMax,
          units: v.units.map((u) => ({
            id: u.id,
            code: u.code,
            state: u.state,
            measurements: u.measurements,
            images: u.images,
          })),
          outfit: v.outfit
            ? {
                mode: v.outfit.mode,
                components: v.outfit.components.map((c) => ({
                  name: c.name,
                  image: c.variant?.costume.images[0] || c.fixedUnit?.images[0] || null,
                  slug: c.variant?.costume.slug || null,
                  size: c.variant?.size || null,
                  required: c.required,
                  quantity: c.quantity,
                  allowSubstitution: c.allowSubstitution,
                })),
              }
            : null,
          calendar: await this.db.inventoryBlock.findMany({
            where: {
              unit: v.outfit
                ? {
                    OR: [
                      {
                        id: {
                          in: v.outfit.components.flatMap((c) =>
                            c.fixedUnitId ? [c.fixedUnitId] : [],
                          ),
                        },
                      },
                      {
                        variantId: {
                          in: v.outfit.components.flatMap((c) => [
                            ...(c.variantId ? [c.variantId] : []),
                            ...(c.allowSubstitution
                              ? c.options.map((o) => o.variantId)
                              : []),
                          ]),
                        },
                      },
                    ],
                  }
                : { variantId: v.id },
              active: true,
              OR: [{ endsAt: null }, { endsAt: { gt: new Date() } }],
            },
            select: { startsAt: true, endsAt: true, kind: true },
            take: 100,
          }),
        })),
      ),
    };
  }
  async fit(variantId: string, body: unknown) {
    const data = z
      .object({
        height: z.number().positive().max(250).optional(),
        chest: z.number().positive().max(300).optional(),
        waist: z.number().positive().max(300).optional(),
        hip: z.number().positive().max(300).optional(),
        length: z.number().positive().max(250).optional(),
      })
      .strict()
      .parse(body);
    const v = await this.db.variant.findUnique({
      where: { id: variantId },
      include: variantInclude,
    });
    if (!v || !v.active || !v.costume.active) throw new NotFoundException();
    return {
      variantId,
      results: v.units
        .filter((u) => u.state !== "RETIRED")
        .map((u) => ({
          unitId: u.id,
          code: u.code,
          ...evaluateFit(
            data,
            u.measurements,
            v.costume.requiredMetrics,
            v.elastic,
          ),
        })),
      note: v.outfit
        ? "Las medidas de un conjunto se confirman por cada componente durante la prueba."
        : undefined,
    };
  }
  async selectionAvailability(body: unknown) {
    const data = z.object({
      startsAt: z.string().datetime({ offset: true }),
      endsAt: z.string().datetime({ offset: true }),
      items: z.array(z.object({ variantId: z.string().min(1).max(100), quantity: z.number().int().min(1).max(100) }).strict()).min(1).max(30),
    }).strict().refine(x => new Date(x.startsAt) < new Date(x.endsAt), "Las fechas no son válidas.").parse(body);
    try {
      await this.db.$transaction(tx => this.availability.plan(tx, data.items, new Date(data.startsAt), new Date(data.endsAt)), { isolationLevel: "RepeatableRead", maxWait: 10000, timeout: 15000 });
      return { sufficient: true, quantity: data.items.reduce((n, i) => n + i.quantity, 0) };
    } catch (e) {
      if (e instanceof ConflictException) return { sufficient: false, message: e.message };
      throw e;
    }
  }
}
@ApiTags("Catálogo público")
@Controller("catalog")
export class CatalogController {
  constructor(
    private catalog: Catalog,
    private availability: Availability,
  ) {}
  @Get() search(@Query() query: Record<string, string>) {
    return this.catalog.search(query);
  }
  @Get(":slug") detail(@Param("slug") slug: string) {
    return this.catalog.detail(slug);
  }
  @Post("selection/availability") selectionAvailability(@Body() body: unknown) {
    return this.catalog.selectionAvailability(body);
  }
  @Post("variants/:id/fit")
  @ApiBody({
    schema: {
      type: "object",
      properties: {
        height: { type: "number" },
        chest: { type: "number" },
        waist: { type: "number" },
        hip: { type: "number" },
      },
    },
  })
  fit(@Param("id") id: string, @Body() body: unknown) {
    return this.catalog.fit(id, body);
  }
  @Get("variants/:id/availability")
  available(@Param("id") id: string, @Query() query: Record<string, string>) {
    const interval = intervalSchema.parse(query);
    return this.availability.count(
      id,
      new Date(interval.startsAt),
      new Date(interval.endsAt),
    );
  }
}
