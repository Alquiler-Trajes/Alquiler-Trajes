import {
  Body,
  ConflictException,
  Controller,
  Delete,
  Get,
  Injectable,
  NotFoundException,
  Param,
  Patch,
  Post,
  Req,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from "@nestjs/common";
import { ApiBody, ApiConsumes, ApiCookieAuth, ApiTags } from "@nestjs/swagger";
import { FileInterceptor } from "@nestjs/platform-express";
import { randomBytes, randomUUID } from "node:crypto";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import sharp from "sharp";
import { z } from "zod";
import type { Prisma } from "@prisma/client";
import { normalize } from "@vestuario/shared";
import { AdminGuard, AdminRequest } from "./auth";
import { Db } from "./db";
import {
  costumeSchema,
  id,
  imagePath,
  measurementSchema,
  outfitSchema,
  text,
} from "./validation";
export const slugify = (name: string) =>
  normalize(name).replace(/ /g, "-") + "-" + randomBytes(3).toString("hex");
export async function createCostume(
  tx: any,
  data: z.infer<typeof costumeSchema>,
) {
  const {
    size,
    color,
    price,
    quantity,
    location,
    commercialAgeMin,
    commercialAgeMax,
    elastic,
    ...model
  } = data;
  const costume = await tx.costume.create({
    data: { ...model, slug: slugify(model.name) },
  });
  const variant = await tx.variant.create({
    data: {
      costumeId: costume.id,
      size,
      color,
      price,
      commercialAgeMin,
      commercialAgeMax,
      elastic,
    },
  });
  const prefix = normalize(model.name)
    .replace(/[^a-z]/g, "")
    .slice(0, 4)
    .toUpperCase();
  await tx.unit.createMany({
    data: Array.from({ length: quantity }, () => ({
      variantId: variant.id,
      code: `${prefix}-${randomBytes(5).toString("hex").toUpperCase()}`,
      location,
      images: [],
    })),
  });
  return { ...costume, variantId: variant.id, quantity };
}
export abstract class ImageStorage {
  abstract save(buffer: Buffer): Promise<string>;
}
@Injectable()
export class LocalImages extends ImageStorage {
  async save(buffer: Buffer) {
    const source = sharp(buffer, {
      limitInputPixels: 20000000,
      failOn: "warning",
    });
    const metadata = await source.metadata();
    if (!metadata.format || !["jpeg", "png", "webp"].includes(metadata.format))
      throw new Error("Formato de imagen no permitido.");
    const output = await source
      .rotate()
      .resize(1600, 1600, { fit: "inside", withoutEnlargement: true })
      .webp({ quality: 85 })
      .toBuffer();
    const dir = process.env.UPLOAD_DIR!;
    await mkdir(dir, { recursive: true });
    const name = randomUUID() + ".webp";
    await writeFile(path.join(dir, name), output, { flag: "wx" });
    return "/uploads/" + name;
  }
}
@ApiTags("Inventario administrativo")
@ApiCookieAuth()
@UseGuards(AdminGuard)
@Controller("admin")
export class InventoryController {
  constructor(
    private db: Db,
    private storage: ImageStorage,
  ) {}
  @Get("categories") categories() {
    return this.db.category.findMany({ orderBy: { name: "asc" } });
  }
  @Post("categories")
  async category(@Body() body: unknown) {
    const data = z
      .object({ name: text, parentId: id.nullable().optional() })
      .strict()
      .parse(body);
    return this.db.category.create({
      data: { ...data, slug: slugify(data.name) },
    });
  }
  @Patch("categories/:id")
  async updateCategory(@Param("id") categoryId: string, @Body() body: unknown) {
    const data = z
      .object({ name: text, parentId: id.nullable().optional() })
      .strict()
      .parse(body);
    return this.db.atomic(async (tx) => {
      let ancestor = data.parentId;
      const seen = new Set([categoryId]);
      while (ancestor) {
        if (seen.has(ancestor))
          throw new ConflictException(
            "La categoría no puede contenerse a sí misma.",
          );
        seen.add(ancestor);
        ancestor = (
          await tx.category.findUniqueOrThrow({ where: { id: ancestor } })
        ).parentId;
      }
      return tx.category.update({ where: { id: categoryId }, data });
    });
  }
  @Delete("categories/:id") deleteCategory(@Param("id") id: string) {
    return this.db.category.delete({ where: { id } });
  }
  @Get("inventory") inventory() {
    return this.db.costume.findMany({
      include: {
        category: true,
        variants: {
          include: {
            units: {
              include: {
                measurements: true,
                blocks: {
                  where: { active: true },
                  orderBy: { startsAt: "asc" },
                },
                movements: { orderBy: { createdAt: "desc" }, take: 30 },
              },
            },
            outfit: { include: { components: { include: { options: true } } } },
          },
        },
      },
      orderBy: { createdAt: "desc" },
    });
  }
  @Post("costumes")
  @ApiBody({
    schema: {
      type: "object",
      required: ["name", "categoryId", "size", "color", "price", "quantity"],
      properties: {
        name: { type: "string" },
        categoryId: { type: "string" },
        size: { type: "string" },
        color: { type: "string" },
        price: { type: "integer" },
        quantity: { type: "integer" },
      },
    },
  })
  async create(@Body() body: unknown, @Req() req: AdminRequest) {
    const data = costumeSchema.parse(body);
    return this.db.atomic(async (tx) => {
      const result = await createCostume(tx, data);
      await tx.auditLog.create({
        data: {
          actorId: req.admin.id,
          action: "INVENTORY_CREATE",
          entityId: result.id,
          detail: { quantity: data.quantity },
        },
      });
      return result;
    });
  }
  @Patch("costumes/:id")
  update(@Param("id") id: string, @Body() body: unknown) {
    const data = z
      .object({
        name: text.optional(),
        description: z.string().max(3000).optional(),
        danceStyle: z.string().trim().max(100).nullable().optional(),
        includedAccessories: z.array(text).max(30).optional(),
        bundleSize: z.union([z.literal(1), z.literal(6)]).optional(),
        bundleImage: imagePath.nullable().optional(),
        categoryId: z.string().optional(),
        tags: z.array(text).max(30).optional(),
        searchTerms: z.string().max(1000).optional(),
        requiredMetrics: z
          .array(z.enum(["height", "chest", "waist", "hip", "length"]))
          .max(5)
          .optional(),
        images: z.array(imagePath).max(10).optional(),
        featured: z.boolean().optional(),
        active: z.boolean().optional(),
      })
      .strict()
      .parse(body);
    return this.db.costume.update({ where: { id }, data });
  }
  @Delete("costumes/:id") archive(@Param("id") id: string) {
    return this.db.costume.update({ where: { id }, data: { active: false } });
  }
  @Patch("costumes/:id/prices")
  async priceAllSizes(@Param("id") costumeId: string, @Body() body: unknown, @Req() req: AdminRequest) {
    const { price } = z.object({ price: z.number().int().positive().max(10000000) }).strict().parse(body);
    return this.db.atomic(async tx => {
      const result = await tx.variant.updateMany({ where: { costumeId, active: true }, data: { price } });
      await tx.auditLog.create({ data: { actorId: req.admin.id, action: "VARIANT_PRICES_UPDATE", entityId: costumeId, detail: { price, variants: result.count } } });
      return result;
    });
  }
  @Post("costumes/:id/variants")
  async variant(@Param("id") costumeId: string, @Body() body: unknown) {
    const data = z
      .object({
        size: text,
        color: text,
        price: z.number().int().min(0).max(10000000),
        elastic: z.boolean().default(false),
        commercialAgeMin: z.number().int().min(0).max(120).optional(),
        commercialAgeMax: z.number().int().min(0).max(120).optional(),
      })
      .strict()
      .parse(body);
    return this.db.variant.create({ data: { ...data, costumeId } });
  }
  @Patch("variants/:id")
  updateVariant(@Param("id") id: string, @Body() body: unknown) {
    const data = z
      .object({
        size: text.optional(),
        color: text.optional(),
        price: z.number().int().min(0).max(10000000).optional(),
        elastic: z.boolean().optional(),
        active: z.boolean().optional(),
        commercialAgeMin: z
          .number()
          .int()
          .min(0)
          .max(120)
          .nullable()
          .optional(),
        commercialAgeMax: z
          .number()
          .int()
          .min(0)
          .max(120)
          .nullable()
          .optional(),
      })
      .strict()
      .parse(body);
    return this.db.variant.update({ where: { id }, data });
  }
  @Post("variants/:id/units")
  async addUnits(@Param("id") variantId: string, @Body() body: unknown) {
    const data = z
      .object({
        quantity: z.number().int().min(1).max(100),
        location: z.string().max(200).default(""),
      })
      .strict()
      .parse(body);
    return this.db.atomic(async (tx) => {
      const v = await tx.variant.findUniqueOrThrow({
        where: { id: variantId },
        include: { outfit: true },
      });
      if (v.outfit)
        throw new ConflictException(
          "Agrega unidades a los componentes del conjunto.",
        );
      const codes = Array.from(
        { length: data.quantity },
        () => `UNI-${randomBytes(5).toString("hex").toUpperCase()}`,
      );
      await tx.unit.createMany({
        data: codes.map((code) => ({
          code,
          variantId,
          location: data.location,
          images: [],
        })),
      });
      return { created: data.quantity, codes };
    });
  }
  @Patch("units/:id")
  async unit(
    @Param("id") unitId: string,
    @Body() body: unknown,
    @Req() req: AdminRequest,
  ) {
    const data = z
      .object({
        code: text.optional(),
        state: z.enum(["READY", "CLEANING", "REPAIR", "RETIRED"]).optional(),
        location: z.string().max(200).optional(),
        notes: z.string().max(3000).optional(),
        acquiredAt: z.string().datetime({ offset: true }).nullable().optional(),
        acquisitionCost: z
          .number()
          .int()
          .min(0)
          .max(100000000)
          .nullable()
          .optional(),
        images: z.array(imagePath).max(10).optional(),
        measurements: z.array(measurementSchema).max(5).optional(),
      })
      .strict()
      .parse(body);
    return this.db.atomic(async (tx) => {
      const { measurements, acquiredAt, ...fields } = data;
      const original = await tx.unit.findUniqueOrThrow({
        where: { id: unitId },
      });
      if (measurements) {
        if (
          new Set(measurements.map((m) => m.metric)).size !==
          measurements.length
        )
          throw new ConflictException("Hay medidas repetidas.");
        await tx.measurement.deleteMany({ where: { unitId } });
        await tx.measurement.createMany({
          data: measurements.map((m) => ({ ...m, unitId })),
        });
      }
      if (fields.state && fields.state !== original.state) {
        const assigned = await tx.allocation.count({
          where: {
            unitId,
            returnedAt: null,
            item: {
              rental: {
                status: { in: ["CONFIRMED", "PREPARING", "DELIVERED"] },
              },
            },
          },
        });
        if (fields.state !== "READY" && assigned)
          throw new ConflictException(
            "La unidad tiene reservas activas. Resuélvelas antes de cambiar su estado.",
          );
        const now = new Date();
        await tx.inventoryBlock.updateMany({
          where: {
            unitId,
            active: true,
            rentalId: null,
            startsAt: { lte: now },
          },
          data: { active: false },
        });
        if (fields.state !== "READY") {
          const next = await tx.inventoryBlock.findFirst({
            where: { unitId, active: true, startsAt: { gt: now } },
            orderBy: { startsAt: "asc" },
          });
          await tx.inventoryBlock.create({
            data: {
              unitId,
              kind:
                fields.state === "CLEANING"
                  ? "CLEANING"
                  : fields.state === "REPAIR"
                    ? "REPAIR"
                    : "ADMIN",
              startsAt: now,
              endsAt: next?.startsAt,
              reason: fields.state,
            },
          });
        }
        await tx.movement.create({
          data: {
            unitId,
            type: fields.state,
            detail: data.notes || "Cambio de estado administrativo",
          },
        });
      }
      const result = await tx.unit.update({
        where: { id: unitId },
        data: {
          ...fields,
          ...(acquiredAt !== undefined
            ? { acquiredAt: acquiredAt ? new Date(acquiredAt) : null }
            : {}),
        },
        include: { measurements: true },
      });
      await tx.auditLog.create({
        data: {
          actorId: req.admin.id,
          action: "UNIT_UPDATE",
          entityId: unitId,
        },
      });
      return result;
    });
  }
  @Post("units/:id/blocks")
  async block(@Param("id") unitId: string, @Body() body: unknown) {
    const data = z
      .object({
        startsAt: z.string().datetime({ offset: true }),
        endsAt: z.string().datetime({ offset: true }),
        kind: z.enum(["CLEANING", "REPAIR", "ADMIN"]),
        reason: text,
      })
      .strict()
      .refine((x) => new Date(x.startsAt) < new Date(x.endsAt))
      .parse(body);
    return this.db.atomic((tx) =>
      tx.inventoryBlock.create({ data: { ...data, unitId } }),
    );
  }
  @Delete("blocks/:id")
  async releaseBlock(@Param("id") id: string) {
    const block = await this.db.inventoryBlock.findUniqueOrThrow({
      where: { id },
    });
    if (block.rentalId)
      throw new ConflictException("Libera este bloqueo mediante la reserva.");
    return this.db.inventoryBlock.update({
      where: { id },
      data: { active: false },
    });
  }
  @Post("outfits")
  async outfit(@Body() body: unknown) {
    const data = outfitSchema.parse(body);
    return this.saveOutfit(data);
  }
  @Patch("outfits/:id")
  async updateOutfit(@Param("id") id: string, @Body() body: unknown) {
    return this.saveOutfit(outfitSchema.parse(body), id);
  }
  private async saveOutfit(
    data: z.infer<typeof outfitSchema>,
    outfitId?: string,
  ) {
    return this.db.atomic(async (tx) => {
      if (outfitId) {
        const existing = await tx.outfit.findUniqueOrThrow({
          where: { id: outfitId },
        });
        if (existing.variantId !== data.variantId)
          throw new ConflictException(
            "No puedes cambiar la variante que representa un conjunto existente.",
          );
      }
      const variant = await tx.variant.findUniqueOrThrow({
        where: { id: data.variantId },
        include: { units: true },
      });
      if (variant.units.length)
        throw new ConflictException(
          "Usa una variante sin unidades propias para representar el conjunto.",
        );
      if (
        await tx.outfitComponent.count({
          where: {
            OR: [
              { variantId: data.variantId },
              { options: { some: { variantId: data.variantId } } },
            ],
          },
        })
      )
        throw new ConflictException(
          "Esta variante ya es componente de otro conjunto y debe conservar prendas físicas.",
        );
      const fixedIds = data.components.flatMap((c) =>
        c.fixedUnitId ? [c.fixedUnitId] : [],
      );
      if (new Set(fixedIds).size !== fixedIds.length)
        throw new ConflictException(
          "Una misma unidad no puede ocupar dos piezas del conjunto.",
        );
      for (const c of data.components) {
        const references = [c.variantId, ...c.alternativeVariantIds].filter(
          Boolean,
        ) as string[];
        if (references.includes(data.variantId))
          throw new ConflictException(
            "Un conjunto no puede incluirse a sí mismo.",
          );
        if (await tx.outfit.count({ where: { variantId: { in: references } } }))
          throw new ConflictException(
            "Los componentes deben ser prendas físicas, no otros conjuntos.",
          );
      }
      const definition = {
        variantId: data.variantId,
        mode: data.mode,
        components: {
          create: data.components.map(({ alternativeVariantIds, ...c }) => ({
            ...c,
            options: {
              create: alternativeVariantIds.map((variantId) => ({
                variantId,
              })),
            },
          })),
        },
      } satisfies Prisma.OutfitUncheckedCreateInput;
      if (outfitId) {
        await tx.outfitComponent.deleteMany({ where: { outfitId } });
        return tx.outfit.update({
          where: { id: outfitId },
          data: definition,
          include: { components: true },
        });
      }
      return tx.outfit.create({
        data: definition,
        include: { components: true },
      });
    });
  }
  @Delete("outfits/:id")
  async deleteOutfit(@Param("id") id: string) {
    const outfit = await this.db.outfit.findUnique({ where: { id } });
    if (!outfit) throw new NotFoundException();
    if (
      await this.db.rentalItem.count({ where: { variantId: outfit.variantId } })
    )
      throw new ConflictException(
        "Conserva el conjunto con historial; archiva su diseño.",
      );
    return this.db.outfit.delete({ where: { id } });
  }
  @Post("images")
  @ApiConsumes("multipart/form-data")
  @ApiBody({
    schema: {
      type: "object",
      properties: { file: { type: "string", format: "binary" } },
    },
  })
  @UseInterceptors(
    FileInterceptor("file", {
      limits: { fileSize: 5 * 1024 * 1024, files: 1 },
    }),
  )
  async upload(@UploadedFile() file?: Express.Multer.File) {
    if (
      !file ||
      !["image/jpeg", "image/png", "image/webp"].includes(file.mimetype)
    )
      throw new ConflictException(
        "Sube una imagen JPG, PNG o WebP de hasta 5 MB.",
      );
    try {
      return { url: await this.storage.save(file.buffer) };
    } catch {
      throw new ConflictException(
        "El archivo no es una imagen válida o excede 20 megapíxeles.",
      );
    }
  }
}
