import {
  Body,
  ConflictException,
  Controller,
  Get,
  Injectable,
  Param,
  Patch,
  Post,
  Req,
  UseGuards,
} from "@nestjs/common";
import { ApiBody, ApiCookieAuth, ApiTags } from "@nestjs/swagger";
import { randomBytes } from "node:crypto";
import { Prisma } from "@prisma/client";
import { z } from "zod";
import { money } from "@vestuario/shared";
import { AdminGuard, AdminRequest } from "./auth";
import { Availability } from "./availability";
import { Db } from "./db";
import { id, requestSchema, text } from "./validation";
export const rentalInclude = {
  customer: true,
  items: {
    include: {
      variant: { include: { costume: true } },
      allocations: { include: { unit: true } },
    },
  },
  payments: { orderBy: { createdAt: "desc" } },
} satisfies Prisma.RentalInclude;
export function balances(rental: {
  items: { quantity: number; unitPrice: number }[];
  payments: { kind: string; amount: number }[];
}) {
  const total = rental.items.reduce((s, i) => s + i.quantity * i.unitPrice, 0);
  const paid = rental.payments.reduce(
    (s, p) =>
      s + (p.kind === "RENT" ? p.amount : p.kind === "REFUND" ? -p.amount : 0),
    0,
  );
  const deposit = rental.payments.reduce(
    (s, p) =>
      s +
      (p.kind === "DEPOSIT"
        ? p.amount
        : p.kind === "DEPOSIT_REFUND"
          ? -p.amount
          : 0),
    0,
  );
  return {
    total,
    paid,
    balance: total - paid,
    deposit,
    paymentStatus: paid >= total ? "PAID" : paid > 0 ? "PARTIAL" : "PENDING",
  };
}
@Injectable()
export class Rentals {
  constructor(
    private db: Db,
    private availability: Availability,
  ) {}
  async request(body: unknown) {
    const data = requestSchema.parse(body);
    const start = new Date(data.startsAt),
      end = new Date(data.endsAt);
    if (
      start.getTime() < Date.now() - 60000 ||
      end.getTime() - start.getTime() > 366 * 86400000
    )
      throw new ConflictException(
        "Elige fechas futuras con duración máxima de un año.",
      );
    const rental = await this.db.atomic(async (tx) => {
      const variants = await tx.variant.findMany({
        where: {
          id: { in: data.items.map((i) => i.variantId) },
          active: true,
          costume: { active: true },
        },
        include: { costume: true },
      });
      if (variants.length !== data.items.length)
        throw new ConflictException(
          "Una de las referencias ya no se ofrece en el catálogo.",
        );
      if (variants.some(v => v.price === 0 && v.costume.tags.includes("coleccion-real-octubre-2026")))
        throw new ConflictException("El precio de alquiler de este artículo está pendiente de definir. El negocio debe registrarlo antes de recibir solicitudes.");
      const customer =
        (await tx.customer.findFirst({
          where: {
            name: { equals: data.name, mode: "insensitive" },
            contact: { equals: data.contact, mode: "insensitive" },
          },
        })) ||
        (await tx.customer.create({
          data: { name: data.name, contact: data.contact },
        }));
      return tx.rental.create({
        data: {
          reference: `VES-${randomBytes(5).toString("hex").toUpperCase()}`,
          customerId: customer.id,
          startsAt: start,
          endsAt: end,
          notes: data.notes,
          demo: variants.some((v) => v.costume.demo),
          items: {
            create: data.items.map((item) => ({
              ...item,
              unitPrice: variants.find((v) => v.id === item.variantId)!.price,
            })),
          },
        },
        include: rentalInclude,
      });
    });
    const fmt = (d: Date) =>
      new Intl.DateTimeFormat("es-CO", {
        dateStyle: "medium",
        timeStyle: "short",
        timeZone: process.env.BUSINESS_TIMEZONE || "America/Bogota",
      }).format(d);
    const message = [
      ...(rental.demo
        ? ["SOLICITUD DE DEMOSTRACIÓN: contiene artículos ficticios."]
        : []),
      `Hola, solicité un alquiler en Vestuario. Solicitud ${rental.reference}.`,
      ...rental.items.map(
        (i) =>
          `${i.quantity} × ${i.variant.costume.name} · ${i.variant.size} · ${i.variant.color}`,
      ),
      `Entrega: ${fmt(start)}. Devolución: ${fmt(end)}.`,
      `Total: ${money(balances(rental).total)}.`,
      `La solicitud está pendiente de confirmación.`,
    ].join("\n");
    const phone = (process.env.WHATSAPP_NUMBER || "").replace(/\D/g, "");
    return {
      reference: rental.reference,
      demo: rental.demo,
      status: rental.status,
      total: balances(rental).total,
      message,
      whatsappUrl: phone
        ? `https://wa.me/${phone}?text=${encodeURIComponent(message)}`
        : null,
    };
  }
  async transition(rentalId: string, status: string, actorId: string) {
    return this.db.atomic(async (tx) => {
      const rental = await tx.rental.findUniqueOrThrow({
        where: { id: rentalId },
        include: rentalInclude,
      });
      const allowed: Record<string, string[]> = {
        REQUESTED: ["CONFIRMED", "CANCELLED"],
        CONFIRMED: ["PREPARING", "CANCELLED"],
        PREPARING: ["DELIVERED", "CANCELLED"],
        RETURNED: ["CLOSED"],
      };
      if (!allowed[rental.status]?.includes(status))
        throw new ConflictException("Este cambio de estado no está permitido.");
      if (status === "CONFIRMED") {
        if (rental.endsAt <= new Date())
          throw new ConflictException(
            "Actualiza las fechas antes de confirmar una solicitud vencida.",
          );
        const plan = await this.availability.plan(
          tx,
          rental.items,
          rental.startsAt,
          rental.endsAt,
        );
        for (const [index, item] of rental.items.entries()) {
          for (const unitId of plan[index]) {
            const allocation = await tx.allocation.create({
              data: { itemId: item.id, unitId },
            });
            await tx.inventoryBlock.create({
              data: {
                unitId,
                allocationId: allocation.id,
                rentalId,
                kind: "RENTAL",
                startsAt: rental.startsAt,
                endsAt: rental.endsAt,
              },
            });
            await tx.movement.create({
              data: { unitId, type: "RESERVED", detail: rental.reference },
            });
          }
        }
      }
      if (status === "DELIVERED") {
        const ids = rental.items.flatMap((i) =>
          i.allocations.map((a) => a.unitId),
        );
        if (
          await tx.unit.count({
            where: { id: { in: ids }, state: { not: "READY" } },
          })
        )
          throw new ConflictException(
            "Hay prendas pendientes de limpieza o reparación.",
          );
        if (
          await tx.allocation.count({
            where: {
              unitId: { in: ids },
              returnedAt: null,
              item: { rental: { status: "DELIVERED", id: { not: rentalId } } },
            },
          })
        )
          throw new ConflictException(
            "Una prenda sigue entregada en otro alquiler. Registra su devolución.",
          );
        if (new Date() < rental.startsAt)
          throw new ConflictException(
            "Aún no comienza el intervalo reservado. Ajusta las fechas para una entrega anticipada.",
          );
        if (new Date() >= rental.endsAt)
          throw new ConflictException(
            "El intervalo de entrega ya terminó. Actualiza las fechas.",
          );
        for (const unitId of ids)
          await tx.movement.create({
            data: { unitId, type: "DELIVERED", detail: rental.reference },
          });
      }
      if (status === "CANCELLED")
        await tx.inventoryBlock.updateMany({
          where: { rentalId, active: true },
          data: { active: false },
        });
      if (status === "CLOSED") {
        const b = balances(rental);
        if (b.balance !== 0 || b.deposit !== 0)
          throw new ConflictException(
            "Registra el saldo del alquiler y devuelve la garantía antes de cerrar.",
          );
      }
      const updated = await tx.rental.update({
        where: { id: rentalId },
        data: { status: status as any },
        include: rentalInclude,
      });
      await tx.auditLog.create({
        data: { actorId, action: `RENTAL_${status}`, entityId: rentalId },
      });
      return { ...updated, ...balances(updated) };
    });
  }
  async returnUnits(rentalId: string, body: unknown, actorId: string) {
    const data = z
      .object({
        units: z
          .array(
            z.object({
              unitId: id,
              condition: z.enum(["CLEANING", "REPAIR"]),
              note: z.string().max(2000).default(""),
            }),
          )
          .min(1)
          .max(200),
      })
      .strict()
      .parse(body);
    if (new Set(data.units.map((u) => u.unitId)).size !== data.units.length)
      throw new ConflictException("Hay unidades repetidas.");
    return this.db.atomic(async (tx) => {
      const rental = await tx.rental.findUniqueOrThrow({
        where: { id: rentalId },
        include: rentalInclude,
      });
      if (rental.status !== "DELIVERED")
        throw new ConflictException("Solo puedes devolver prendas entregadas.");
      const allocations = rental.items.flatMap((i) => i.allocations);
      const now = new Date();
      for (const unit of data.units) {
        const allocation = allocations.find(
          (a) => a.unitId === unit.unitId && !a.returnedAt,
        );
        if (!allocation)
          throw new ConflictException(
            "La unidad no está pendiente de devolución en este alquiler.",
          );
        await tx.allocation.update({
          where: { id: allocation.id },
          data: { returnedAt: now, condition: unit.note || unit.condition },
        });
        await tx.inventoryBlock.updateMany({
          where: { allocationId: allocation.id },
          data: { active: false },
        });
        await tx.unit.update({
          where: { id: unit.unitId },
          data: { state: unit.condition },
        });
        const next = await tx.inventoryBlock.findFirst({
          where: {
            unitId: unit.unitId,
            active: true,
            OR: [{ endsAt: null }, { endsAt: { gt: now } }],
          },
          orderBy: { startsAt: "asc" },
        });
        // A late return must still be recorded if the next reservation already
        // started. Physical state prevents delivery until the review is complete.
        const occupiedNow = !!next && next.startsAt <= now;
        await tx.inventoryBlock.create({
          data: {
            unitId: unit.unitId,
            kind: unit.condition,
            startsAt: now,
            endsAt: occupiedNow ? null : next?.startsAt,
            active: !occupiedNow,
            reason:
              (unit.note || "Pendiente de revisión después de devolución") +
              (occupiedNow
                ? " · Requiere resolver la siguiente reserva en curso."
                : ""),
          },
        });
        await tx.movement.create({
          data: {
            unitId: unit.unitId,
            type: "RETURNED",
            detail: `${rental.reference}: ${unit.condition}. ${unit.note}`,
          },
        });
      }
      const remaining = allocations.filter(
        (a) => !a.returnedAt && !data.units.some((u) => u.unitId === a.unitId),
      ).length;
      const result = await tx.rental.update({
        where: { id: rentalId },
        data: { status: remaining ? "DELIVERED" : "RETURNED" },
        include: rentalInclude,
      });
      await tx.auditLog.create({
        data: {
          actorId,
          action: "RENTAL_RETURN",
          entityId: rentalId,
          detail: { units: data.units.map((u) => u.unitId) },
        },
      });
      return { ...result, ...balances(result) };
    });
  }
}
@ApiTags("Solicitudes públicas")
@Controller("requests")
export class RequestsController {
  constructor(private rentals: Rentals) {}
  @Post()
  @ApiBody({
    schema: {
      type: "object",
      required: ["name", "contact", "startsAt", "endsAt", "items"],
      properties: {
        name: { type: "string" },
        contact: { type: "string" },
        startsAt: { type: "string", format: "date-time" },
        endsAt: { type: "string", format: "date-time" },
        notes: { type: "string" },
        items: {
          type: "array",
          items: {
            type: "object",
            properties: {
              variantId: { type: "string" },
              quantity: { type: "integer" },
            },
          },
        },
      },
    },
  })
  create(@Body() body: unknown) {
    return this.rentals.request(body);
  }
}
@ApiTags("Alquileres y operación")
@ApiCookieAuth()
@UseGuards(AdminGuard)
@Controller("admin")
export class RentalsController {
  constructor(
    private db: Db,
    private rentals: Rentals,
  ) {}
  @Get("rentals") async list() {
    const rows = await this.db.rental.findMany({
      include: rentalInclude,
      orderBy: { createdAt: "desc" },
      take: 500,
    });
    return rows.map((r) => ({
      ...r,
      ...balances(r),
      overdue: r.status === "DELIVERED" && r.endsAt < new Date(),
    }));
  }
  @Get("rentals/:id") async get(@Param("id") id: string) {
    const r = await this.db.rental.findUniqueOrThrow({
      where: { id },
      include: rentalInclude,
    });
    return { ...r, ...balances(r) };
  }
  @Patch("rentals/:id/status")
  transition(
    @Param("id") id: string,
    @Body() body: unknown,
    @Req() req: AdminRequest,
  ) {
    const { status } = z
      .object({
        status: z.enum([
          "CONFIRMED",
          "PREPARING",
          "DELIVERED",
          "CLOSED",
          "CANCELLED",
        ]),
      })
      .strict()
      .parse(body);
    return this.rentals.transition(id, status, req.admin.id);
  }
  @Patch("rentals/:id/dates")
  async dates(@Param("id") id: string, @Body() body: unknown) {
    const data = z
      .object({
        startsAt: z.string().datetime({ offset: true }),
        endsAt: z.string().datetime({ offset: true }),
      })
      .strict()
      .refine((d) => new Date(d.startsAt) < new Date(d.endsAt))
      .parse(body);
    return this.db.atomic(async (tx) => {
      const r = await tx.rental.findUniqueOrThrow({
        where: { id },
        include: rentalInclude,
      });
      if (
        !["REQUESTED", "CONFIRMED", "PREPARING", "DELIVERED"].includes(r.status)
      )
        throw new ConflictException("El alquiler ya está finalizado.");
      if (
        r.status === "DELIVERED" &&
        new Date(data.startsAt).getTime() !== r.startsAt.getTime()
      )
        throw new ConflictException(
          "Conserva el inicio de un alquiler entregado.",
        );
      if (new Date(data.endsAt) < new Date())
        throw new ConflictException(
          "La nueva devolución debe estar en el futuro.",
        );
      await tx.inventoryBlock.updateMany({
        where: { rentalId: id, active: true },
        data: {
          startsAt: new Date(data.startsAt),
          endsAt: new Date(data.endsAt),
        },
      });
      return tx.rental.update({ where: { id }, data, include: rentalInclude });
    });
  }
  @Post("rentals/:id/return") returnUnits(
    @Param("id") id: string,
    @Body() body: unknown,
    @Req() req: AdminRequest,
  ) {
    return this.rentals.returnUnits(id, body, req.admin.id);
  }
  @Post("rentals/:id/payments")
  async payment(
    @Param("id") rentalId: string,
    @Body() body: unknown,
    @Req() req: AdminRequest,
  ) {
    const data = z
      .object({
        kind: z.enum(["RENT", "DEPOSIT", "REFUND", "DEPOSIT_REFUND"]),
        amount: z.number().int().positive().max(100000000),
        method: text,
        note: z.string().max(2000).default(""),
      })
      .strict()
      .parse(body);
    return this.db.atomic(async (tx) => {
      const r = await tx.rental.findUniqueOrThrow({
        where: { id: rentalId },
        include: rentalInclude,
      });
      if (r.status === "CLOSED")
        throw new ConflictException("El alquiler está cerrado.");
      const b = balances(r);
      if (
        (data.kind === "RENT" && data.amount > b.balance) ||
        (data.kind === "REFUND" && data.amount > b.paid) ||
        (data.kind === "DEPOSIT_REFUND" && data.amount > b.deposit)
      )
        throw new ConflictException(
          "El valor supera el saldo que puedes registrar o devolver.",
        );
      const payment = await tx.payment.create({ data: { ...data, rentalId } });
      await tx.auditLog.create({
        data: {
          actorId: req.admin.id,
          action: "PAYMENT_CREATE",
          entityId: payment.id,
          detail: { kind: data.kind, amount: data.amount },
        },
      });
      return payment;
    });
  }
  @Get("customers") customers() {
    return this.db.customer.findMany({
      include: { rentals: { include: { payments: true, items: true } } },
      orderBy: { createdAt: "desc" },
      take: 500,
    });
  }
  @Patch("customers/:id") updateCustomer(
    @Param("id") id: string,
    @Body() body: unknown,
  ) {
    const data = z
      .object({ name: text, contact: z.string().min(7).max(100) })
      .strict()
      .parse(body);
    return this.db.customer.update({ where: { id }, data });
  }
  @Get("dashboard")
  async dashboard() {
    const now = new Date();
    const [units, rentals, payments, states, demoRecords] = await Promise.all([
      this.db.unit.count({ where: { state: { not: "RETIRED" } } }),
      this.db.rental.findMany({
        where: { status: { notIn: ["CANCELLED", "CLOSED"] } },
        include: { customer: true },
        orderBy: { startsAt: "asc" },
      }),
      this.db.payment.findMany(),
      this.db.unit.groupBy({ by: ["state"], _count: true }),
      this.db.costume.count({ where: { demo: true } }),
    ]);
    return {
      units,
      demoRecords,
      active: rentals.filter((r) => r.status === "DELIVERED").length,
      upcoming: rentals.filter(
        (r) =>
          ["CONFIRMED", "PREPARING"].includes(r.status) && r.startsAt > now,
      ).length,
      pendingDeliveries: rentals.filter((r) =>
        ["CONFIRMED", "PREPARING"].includes(r.status),
      ).length,
      overdue: rentals.filter((r) => r.status === "DELIVERED" && r.endsAt < now)
        .length,
      requested: rentals.filter((r) => r.status === "REQUESTED").length,
      cleaning: states.find((s) => s.state === "CLEANING")?._count || 0,
      repair: states.find((s) => s.state === "REPAIR")?._count || 0,
      revenue: payments.reduce(
        (s, p) =>
          s +
          (p.kind === "RENT" ? p.amount : p.kind === "REFUND" ? -p.amount : 0),
        0,
      ),
      agenda: rentals.slice(0, 30),
    };
  }
  @Get("audit") audit() {
    return this.db.auditLog.findMany({
      orderBy: { createdAt: "desc" },
      take: 100,
    });
  }
}
