import {
  Body,
  ConflictException,
  Controller,
  Get,
  Post,
  Req,
  Res,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from "@nestjs/common";
import { ApiBody, ApiConsumes, ApiCookieAuth, ApiTags } from "@nestjs/swagger";
import { FileInterceptor } from "@nestjs/platform-express";
import ExcelJS from "exceljs";
import type { Response } from "express";
import { z } from "zod";
import { Db } from "./db";
import { AdminGuard, AdminRequest } from "./auth";
import { costumeSchema } from "./validation";
import { createCostume } from "./inventory";
import { validateWorkbookArchive } from "./xlsx-safety";
const headers = [
  "Referencia",
  "Nombre",
  "Categoría",
  "Talla",
  "Color",
  "Cantidad",
  "Precio",
  "Ubicación",
];
const rowSchema = z
  .object({
    reference: z.string().trim().min(1).max(100),
    name: z.string().trim().min(1).max(200),
    category: z.string().trim().min(1).max(200),
    size: z.string().trim().min(1).max(100),
    color: z.string().trim().min(1).max(100),
    quantity: z.number().int().min(1).max(100),
    price: z.number().int().min(0).max(10000000),
    location: z.string().max(200),
  })
  .strict();
@ApiTags("Importación XLSX")
@ApiCookieAuth()
@UseGuards(AdminGuard)
@Controller("admin/import")
export class ImportsController {
  constructor(private db: Db) {}
  @Get("template")
  async template(@Res() res: Response) {
    const book = new ExcelJS.Workbook();
    const sheet = book.addWorksheet("Inventario");
    sheet.addRow(headers);
    sheet.addRow([
      "EJEMPLO-001",
      "Traje de ejemplo",
      "Bailes tradicionales",
      "6",
      "Azul",
      2,
      45000,
      "Estante A",
    ]);
    sheet.getRow(1).font = { bold: true, color: { argb: "FFFFFFFF" } };
    sheet.getRow(1).fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "FF255C45" },
    };
    sheet.columns.forEach((c) => (c.width = 24));
    res.setHeader(
      "Content-Type",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    );
    res.setHeader(
      "Content-Disposition",
      'attachment; filename="plantilla-vestuario.xlsx"',
    );
    await book.xlsx.write(res);
    res.end();
  }
  @Post("preview")
  @ApiConsumes("multipart/form-data")
  @ApiBody({
    schema: {
      type: "object",
      properties: { file: { type: "string", format: "binary" } },
    },
  })
  @UseInterceptors(
    FileInterceptor("file", {
      limits: { fileSize: 2 * 1024 * 1024, files: 1 },
    }),
  )
  async preview(@UploadedFile() file?: Express.Multer.File) {
    if (!file || !file.originalname.toLowerCase().endsWith(".xlsx"))
      throw new ConflictException("Selecciona un archivo XLSX de hasta 2 MB.");
    validateWorkbookArchive(file.buffer);
    const workbook = new ExcelJS.Workbook();
    try {
      await workbook.xlsx.load(file.buffer as any);
    } catch {
      throw new ConflictException("No se pudo leer el archivo XLSX.");
    }
    const sheet = workbook.worksheets[0];
    if (!sheet || sheet.rowCount > 501 || sheet.columnCount > 8)
      throw new ConflictException(
        "La plantilla admite hasta 500 filas y 8 columnas.",
      );
    const actual = headers.map((_, i) =>
      String(sheet.getCell(1, i + 1).value || ""),
    );
    if (actual.some((v, i) => v !== headers[i]))
      throw new ConflictException(
        "Las columnas no coinciden con la plantilla. Descarga una plantilla nueva.",
      );
    const categories = await this.db.category.findMany();
    const seen = new Set<string>();
    const rows = [];
    const errors = [];
    for (let n = 2; n <= sheet.rowCount; n++) {
      const row = sheet.getRow(n);
      if (!row.hasValues) continue;
      const values = headers.map((_, i) => row.getCell(i + 1).value ?? "");
      if (values.some((v) => typeof v === "object")) {
        errors.push({
          row: n,
          message:
            "Usa valores simples; no se permiten fórmulas, enlaces ni objetos.",
        });
        continue;
      }
      const result = rowSchema.safeParse({
        reference: String(values[0]),
        name: String(values[1]),
        category: String(values[2]),
        size: String(values[3]),
        color: String(values[4]),
        quantity: values[5],
        price: values[6],
        location: String(values[7]),
      });
      if (!result.success) {
        errors.push({
          row: n,
          message: result.error.issues
            .map((i) => `${i.path}: ${i.message}`)
            .join("; "),
        });
        continue;
      }
      const data = result.data;
      const category = categories.find(
        (c) => c.name.toLowerCase() === data.category.toLowerCase(),
      );
      if (!category) {
        errors.push({
          row: n,
          message: `Categoría inexistente: ${data.category}. Créala primero.`,
        });
        continue;
      }
      const key = `${data.name.toLowerCase()}|${data.size.toLowerCase()}|${data.color.toLowerCase()}`;
      if (
        seen.has(key) ||
        seen.has(data.reference) ||
        (await this.db.costume.count({
          where: {
            OR: [
              { searchTerms: { contains: `import:${data.reference};` } },
              {
                name: { equals: data.name, mode: "insensitive" },
                variants: { some: { size: data.size, color: data.color } },
              },
            ],
          },
        }))
      ) {
        errors.push({
          row: n,
          message:
            "Referencia o variante duplicada en el archivo o el inventario.",
        });
        continue;
      }
      seen.add(key);
      seen.add(data.reference);
      rows.push({ ...data, categoryId: category.id, row: n });
    }
    return {
      rows,
      errors,
      valid: errors.length === 0 && rows.length > 0,
      total: rows.length,
      notice:
        "No se ha modificado el inventario. Confirma para importar todas las filas válidas juntas.",
    };
  }
  @Post("commit")
  async commit(@Body() body: unknown, @Req() req: AdminRequest) {
    const data = z
      .object({
        rows: z
          .array(
            rowSchema.extend({
              categoryId: z.string().min(1),
              row: z.number().int().min(2),
            }),
          )
          .min(1)
          .max(500),
        confirmed: z.literal(true),
      })
      .strict()
      .parse(body);
    return this.db.atomic(async (tx) => {
      const results = [];
      for (const row of data.rows) {
        const category = await tx.category.findUnique({
          where: { id: row.categoryId },
        });
        if (
          !category ||
          category.name.toLowerCase() !== row.category.toLowerCase()
        )
          throw new ConflictException(`Categoría inválida en fila ${row.row}.`);
        if (
          await tx.costume.count({
            where: {
              OR: [
                { searchTerms: { contains: `import:${row.reference};` } },
                {
                  name: { equals: row.name, mode: "insensitive" },
                  variants: { some: { size: row.size, color: row.color } },
                },
              ],
            },
          })
        )
          throw new ConflictException(
            `Fila ${row.row}: referencia o variante ya importada. Nada fue importado.`,
          );
        const values = costumeSchema.parse({
          name: row.name,
          categoryId: row.categoryId,
          size: row.size,
          color: row.color,
          quantity: row.quantity,
          price: row.price,
          location: row.location,
          searchTerms: `import:${row.reference};`,
        });
        results.push(await createCostume(tx, values));
      }
      await tx.auditLog.create({
        data: {
          actorId: req.admin.id,
          action: "XLSX_IMPORT",
          entityId: "inventory",
          detail: {
            models: results.length,
            units: results.reduce((s, r) => s + r.quantity, 0),
          },
        },
      });
      return {
        imported: results.length,
        units: results.reduce((s, r) => s + r.quantity, 0),
      };
    }, 60000);
  }
}
