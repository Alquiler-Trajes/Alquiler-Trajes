import "reflect-metadata";
import dotenv from "dotenv";
import path from "node:path";
import { existsSync } from "node:fs";
import { Module, Controller, Get } from "@nestjs/common";
import { NestFactory } from "@nestjs/core";
import { NestExpressApplication } from "@nestjs/platform-express";
import { DocumentBuilder, SwaggerModule } from "@nestjs/swagger";
import cookieParser from "cookie-parser";
import helmet from "helmet";
import { rateLimit } from "express-rate-limit";
import { Db } from "./db";
import { Errors } from "./errors";
import { AuthController, AdminGuard } from "./auth";
import { Catalog, CatalogController } from "./catalog";
import { Availability } from "./availability";
import { InventoryController, ImageStorage, LocalImages } from "./inventory";
import { Rentals, RentalsController, RequestsController } from "./rentals";
import { ImportsController } from "./imports";
const root = existsSync(path.resolve(process.cwd(), "prisma/schema.prisma"))
  ? process.cwd()
  : path.resolve(process.cwd(), "../..");
dotenv.config({ path: path.join(root, ".env"), quiet: true });
process.env.UPLOAD_DIR = path.resolve(
  root,
  process.env.UPLOAD_DIR || "uploads",
);
@Controller()
class HealthController {
  constructor(private db: Db) {}
  @Get("health") async health() {
    await this.db.$queryRaw`SELECT 1`;
    return {
      ok: true,
      service: "Vestuario",
      timezone: process.env.BUSINESS_TIMEZONE || "America/Bogota",
    };
  }
  @Get("config") config() {
    const phone = (process.env.WHATSAPP_NUMBER || "").replace(/\D/g, "");
    return {
      whatsappUrl: phone ? `https://wa.me/${phone}` : null,
      timezone: process.env.BUSINESS_TIMEZONE || "America/Bogota",
    };
  }
}
@Module({
  controllers: [
    HealthController,
    AuthController,
    CatalogController,
    InventoryController,
    RequestsController,
    RentalsController,
    ImportsController,
  ],
  providers: [
    Db,
    AdminGuard,
    Catalog,
    Availability,
    Rentals,
    { provide: ImageStorage, useClass: LocalImages },
  ],
})
class AppModule {}
async function main() {
  const app = await NestFactory.create<NestExpressApplication>(AppModule, {
    bodyParser: true,
  });
  app.setGlobalPrefix("api");
  app.useBodyParser("json", { limit: "1mb" });
  app.use(helmet());
  app.use(cookieParser());
  app.use((req: any, res: any, next: any) => {
    if (!["GET", "HEAD", "OPTIONS"].includes(req.method)) {
      const origin = req.headers.origin;
      const allowed = process.env.WEB_ORIGIN || "http://localhost:3000";
      if (
        origin &&
        origin !== allowed &&
        !(
          process.env.NODE_ENV !== "production" &&
          origin === "http://127.0.0.1:3000"
        )
      )
        return res.status(403).json({ message: "Origen no autorizado." });
      if (!origin && req.cookies?.vestuario_session)
        return res.status(403).json({
          message: "Incluye el origen autorizado para usar la sesión.",
        });
    }
    next();
  });
  app.use(
    "/api/auth/login",
    rateLimit({
      windowMs: 15 * 60000,
      limit: 20,
      standardHeaders: "draft-8",
      legacyHeaders: false,
      message: { message: "Demasiados intentos. Intenta más tarde." },
    }),
  );
  app.use(
    "/api/requests",
    rateLimit({
      windowMs: 15 * 60000,
      limit: 40,
      standardHeaders: "draft-8",
      legacyHeaders: false,
      message: {
        message: "Se alcanzó el límite de solicitudes. Intenta más tarde.",
      },
    }),
  );
  app.use(
    "/api",
    rateLimit({
      windowMs: 60000,
      limit: 600,
      standardHeaders: "draft-8",
      legacyHeaders: false,
      message: { message: "Demasiadas consultas. Intenta en un minuto." },
    }),
  );
  app.useGlobalFilters(new Errors());
  const auditDb = app.get(Db);
  app.use((req: any, res: any, next: any) => {
    res.once("finish", () => {
      if (
        req.admin &&
        res.statusCode < 400 &&
        ["POST", "PATCH", "DELETE"].includes(req.method)
      )
        void auditDb.auditLog
          .create({
            data: {
              actorId: req.admin.id,
              action: req.method + " " + req.path,
              entityId: req.params?.id || req.path,
            },
          })
          .catch(() =>
            console.error("No se pudo registrar auditoría de la operación."),
          );
    });
    next();
  });
  app.useStaticAssets(process.env.UPLOAD_DIR!, {
    prefix: "/uploads/",
    index: false,
    setHeaders(res) {
      res.setHeader("X-Content-Type-Options", "nosniff");
      res.setHeader("Cache-Control", "public,max-age=86400");
    },
  });
  const config = new DocumentBuilder()
    .setTitle("Vestuario API")
    .setDescription(
      "Precios enteros en COP. Instantes ISO 8601 con zona. Intervalos [inicio, fin). Las solicitudes públicas no bloquean inventario. Operaciones /admin requieren sesión. Enviar Origin en mutaciones autenticadas.",
    )
    .setVersion("1.0.0")
    .addCookieAuth("vestuario_session")
    .build();
  SwaggerModule.setup(
    "api/docs",
    app,
    SwaggerModule.createDocument(app, config),
  );
  app.enableShutdownHooks();
  await app.listen(
    Number(process.env.API_PORT || 4000),
    process.env.API_HOST || "127.0.0.1",
  );
}
main().catch((e) => {
  console.error(e);
  process.exitCode = 1;
});
