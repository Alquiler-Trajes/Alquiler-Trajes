import { BadRequestException } from "@nestjs/common";
import { inflateRawSync } from "node:zlib";
// Read ZIP central-directory metadata before ExcelJS inflates the workbook.
// Reject ZIP64/encrypted archives and bound decompressed size independently
// of the HTTP compressed-size limit. XLSX templates need neither feature.
export function validateWorkbookArchive(buffer: Buffer) {
  const fail = () => {
    throw new BadRequestException(
      "XLSX inválido o demasiado grande al descomprimir (máximo 20 MB).",
    );
  };
  if (buffer.length < 22) fail();
  let end = -1;
  for (let p = buffer.length - 22; p >= Math.max(0, buffer.length - 65557); p--)
    if (buffer.readUInt32LE(p) === 0x06054b50) {
      end = p;
      break;
    }
  if (end < 0) fail();
  const count = buffer.readUInt16LE(end + 10),
    offset = buffer.readUInt32LE(end + 16);
  if (count > 1000 || !count || offset === 0xffffffff) fail();
  let position = offset,
    total = 0;
  for (let n = 0; n < count; n++) {
    if (
      position + 46 > buffer.length ||
      buffer.readUInt32LE(position) !== 0x02014b50
    )
      fail();
    const flags = buffer.readUInt16LE(position + 8),
      size = buffer.readUInt32LE(position + 24);
    if (flags & 1 || size === 0xffffffff) fail();
    total += size;
    if (total > 20 * 1024 * 1024) fail();
    const method = buffer.readUInt16LE(position + 10),
      compressedSize = buffer.readUInt32LE(position + 20),
      localOffset = buffer.readUInt32LE(position + 42);
    if (
      localOffset + 30 > offset ||
      buffer.readUInt32LE(localOffset) !== 0x04034b50
    )
      fail();
    const dataOffset =
      localOffset +
      30 +
      buffer.readUInt16LE(localOffset + 26) +
      buffer.readUInt16LE(localOffset + 28);
    if (dataOffset + compressedSize > offset || ![0, 8].includes(method))
      fail();
    const compressed = buffer.subarray(dataOffset, dataOffset + compressedSize);
    try {
      const inflated =
        method === 0
          ? compressed
          : inflateRawSync(compressed, { maxOutputLength: Math.max(size, 1) });
      if (inflated.length !== size) fail();
    } catch {
      fail();
    }
    position +=
      46 +
      buffer.readUInt16LE(position + 28) +
      buffer.readUInt16LE(position + 30) +
      buffer.readUInt16LE(position + 32);
  }
  if (position > end) fail();
}
