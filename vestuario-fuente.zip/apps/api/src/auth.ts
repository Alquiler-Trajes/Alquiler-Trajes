import {
  Body,
  CanActivate,
  Controller,
  ExecutionContext,
  Get,
  Injectable,
  Post,
  Req,
  Res,
  UnauthorizedException,
  UseGuards,
} from "@nestjs/common";
import { ApiBody, ApiCookieAuth, ApiTags } from "@nestjs/swagger";
import { compare } from "bcryptjs";
import { createHash, randomBytes } from "node:crypto";
import type { Request, Response } from "express";
import { z } from "zod";
import { Db } from "./db";
export const hashToken = (s: string) =>
  createHash("sha256").update(s).digest("hex");
export type AdminRequest = Request & {
  admin: { id: string; name: string; email: string };
};
@Injectable()
export class AdminGuard implements CanActivate {
  constructor(private db: Db) {}
  async canActivate(ctx: ExecutionContext) {
    const req = ctx.switchToHttp().getRequest<AdminRequest>();
    const token = req.cookies?.vestuario_session;
    if (!token)
      throw new UnauthorizedException("Inicia sesión para continuar.");
    const session = await this.db.session.findUnique({
      where: { tokenHash: hashToken(token) },
      include: { admin: true },
    });
    if (!session || session.expiresAt < new Date() || !session.admin.active)
      throw new UnauthorizedException(
        "La sesión venció. Inicia sesión nuevamente.",
      );
    req.admin = {
      id: session.admin.id,
      name: session.admin.name,
      email: session.admin.email,
    };
    return true;
  }
}
@ApiTags("Autenticación")
@Controller("auth")
export class AuthController {
  constructor(private db: Db) {}
  @Post("login")
  @ApiBody({
    schema: {
      type: "object",
      required: ["email", "password"],
      properties: { email: { type: "string" }, password: { type: "string" } },
    },
  })
  async login(
    @Body() body: unknown,
    @Res({ passthrough: true }) res: Response,
  ) {
    const data = z
      .object({
        email: z.string().email().max(254),
        password: z.string().min(1).max(128),
      })
      .strict()
      .parse(body);
    const admin = await this.db.admin.findUnique({
      where: { email: data.email.toLowerCase() },
    });
    const fallback =
      "$2b$12$Y/zn1c/NwmPgJqwB6VY7ieoxQd.Z3lHgpwZ37viZ6.ihRUm33gHGa";
    const valid = await compare(data.password, admin?.passwordHash || fallback);
    if (!admin?.active || !valid)
      throw new UnauthorizedException("Correo o contraseña incorrectos.");
    const token = randomBytes(32).toString("hex");
    await this.db.session.create({
      data: {
        adminId: admin.id,
        tokenHash: hashToken(token),
        expiresAt: new Date(Date.now() + 8 * 3600000),
      },
    });
    res.cookie("vestuario_session", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      maxAge: 8 * 3600000,
      path: "/api",
    });
    return { name: admin.name, email: admin.email };
  }
  @Get("me")
  @ApiCookieAuth()
  @UseGuards(AdminGuard)
  me(@Req() req: AdminRequest) {
    return req.admin;
  }
  @Post("logout")
  async logout(@Req() req: Request, @Res({ passthrough: true }) res: Response) {
    if (req.cookies?.vestuario_session)
      await this.db.session.deleteMany({
        where: { tokenHash: hashToken(req.cookies.vestuario_session) },
      });
    res.clearCookie("vestuario_session", { path: "/api" });
    return { ok: true };
  }
}
