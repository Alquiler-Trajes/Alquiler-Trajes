import {
  ConflictException,
  Injectable,
  NotFoundException,
} from "@nestjs/common";
import { Prisma } from "@prisma/client";
import { Db } from "./db";
export type Tx = Prisma.TransactionClient;
export const variantInclude = {
  costume: true,
  units: { include: { measurements: true } },
  outfit: {
    include: { components: { include: { options: true, fixedUnit: true, variant: { include: { costume: true } } } } },
  },
} satisfies Prisma.VariantInclude;
@Injectable()
export class Availability {
  constructor(private db: Db) {}
  async candidates(
    tx: Tx,
    variantIds: string[],
    start: Date,
    end: Date,
    used: Set<string>,
    fixedUnitId?: string,
  ) {
    const units = await tx.unit.findMany({
      where: {
        ...(fixedUnitId
          ? { id: fixedUnitId }
          : { variantId: { in: variantIds } }),
        state: "READY",
        variant: { active: true, costume: { active: true } },
        blocks: {
          none: {
            active: true,
            startsAt: { lt: end },
            OR: [{ endsAt: null }, { endsAt: { gt: start } }],
          },
        },
        allocations: {
          none: {
            returnedAt: null,
            item: {
              rental: { status: "DELIVERED", endsAt: { lt: new Date() } },
            },
          },
        },
      },
      orderBy: { code: "asc" },
    });
    return units.filter((u) => !used.has(u.id));
  }
  async plan(
    tx: Tx,
    items: { variantId: string; quantity: number }[],
    start: Date,
    end: Date,
    used = new Set<string>(),
  ): Promise<string[][]> {
    const slots: { item: number; label: string; candidates: string[] }[] = [];
    for (const [index, item] of items.entries()) {
      const v = await tx.variant.findUnique({
        where: { id: item.variantId },
        include: variantInclude,
      });
      if (!v || !v.active || !v.costume.active)
        throw new NotFoundException("La variante no está disponible.");
      if (!v.outfit) {
        const candidates = (
          await this.candidates(tx, [v.id], start, end, used)
        ).map((u) => u.id);
        for (let n = 0; n < item.quantity; n++)
          slots.push({ item: index, label: v.costume.name, candidates });
        continue;
      }
      if (v.outfit.mode === "FIXED" && item.quantity > 1)
        throw new ConflictException(
          "Un conjunto fijo tiene una sola combinación física.",
        );
      for (const c of v.outfit.components.filter((c) => c.required)) {
        const variants = [
          ...(c.variantId ? [c.variantId] : []),
          ...(c.allowSubstitution ? c.options.map((o) => o.variantId) : []),
        ];
        const candidates = (
          await this.candidates(
            tx,
            variants,
            start,
            end,
            used,
            c.fixedUnitId || undefined,
          )
        ).map((u) => u.id);
        for (let n = 0; n < c.quantity * item.quantity; n++)
          slots.push({
            item: index,
            label: `${c.name} de ${v.costume.name}`,
            candidates,
          });
      }
    }
    // Bipartite matching across the whole request avoids greedy false shortages
    // when a flexible component and an individual item share compatible units.
    const owner = new Map<string, number>();
    const assigned = new Map<number, string>();
    const match = (slot: number, seen: Set<string>): boolean => {
      for (const unitId of slots[slot].candidates) {
        if (seen.has(unitId)) continue;
        seen.add(unitId);
        const previous = owner.get(unitId);
        if (previous === undefined || match(previous, seen)) {
          owner.set(unitId, slot);
          assigned.set(slot, unitId);
          return true;
        }
      }
      return false;
    };
    const order = slots
      .map((_, i) => i)
      .sort((a, b) => slots[a].candidates.length - slots[b].candidates.length);
    for (const index of order)
      if (!match(index, new Set()))
        throw new ConflictException(
          `No hay suficientes unidades de ${slots[index].label} para estas fechas.`,
        );
    const result = items.map(() => [] as string[]);
    for (const [index, unitId] of assigned) {
      result[slots[index].item].push(unitId);
      used.add(unitId);
    }
    return result;
  }
  async count(variantId: string, start: Date, end: Date, requested = 1) {
    let count = 0;
    await this.db.$transaction(
      async (tx) => {
        const v = await tx.variant.findUnique({
          where: { id: variantId },
          include: { outfit: { include: { components: { include: { options: true, fixedUnit: true } } } } },
        });
        if (!v) throw new NotFoundException();
        if (!v.outfit) {
          count = (
            await this.candidates(tx, [variantId], start, end, new Set())
          ).length;
          return;
        }
        const required = v.outfit.components.filter(c => c.required);
        const pools = required.map(c => [...new Set([
          ...(c.variantId ? [c.variantId] : []),
          ...(c.allowSubstitution ? c.options.map(o => o.variantId) : []),
        ])]);
        const counts = await tx.unit.groupBy({
          by: ["variantId"], where: { state: "READY", variantId: { in: pools.flat() } }, _count: true,
        });
        const byVariant = new Map(counts.map(c => [c.variantId, c._count]));
        // The physical stock bounds the search. Full planning below still checks
        // dates, overdue returns and competition for shared components.
        let low = 0,
          high = Math.min(v.outfit.mode === "FIXED" ? 1 : 100, ...required.map((c, i) =>
            Math.floor((c.fixedUnitId ? Number(c.fixedUnit?.state === "READY") : pools[i].reduce((n, id) => n + (byVariant.get(id) || 0), 0)) / c.quantity),
          ));
        while (low < high) {
          const middle = Math.ceil((low + high) / 2);
          try {
            await this.plan(tx, [{ variantId, quantity: middle }], start, end);
            low = middle;
          } catch (e) {
            if (e instanceof ConflictException) high = middle - 1;
            else throw e;
          }
        }
        count = low;
      },
      { isolationLevel: "RepeatableRead", maxWait: 10000, timeout: 15000 },
    );
    return { available: count, sufficient: count >= requested };
  }
}
