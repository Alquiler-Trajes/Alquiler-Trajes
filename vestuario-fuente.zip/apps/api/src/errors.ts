import {
  ArgumentsHost,
  Catch,
  ExceptionFilter,
  HttpException,
  Logger,
} from "@nestjs/common";
import { ZodError } from "zod";
@Catch()
export class Errors implements ExceptionFilter {
  private logger = new Logger("Errors");
  catch(error: any, host: ArgumentsHost) {
    const res = host.switchToHttp().getResponse();
    let status = 500,
      message = "No pudimos completar la operación. Intenta de nuevo.";
    let details: unknown;
    if (error instanceof ZodError) {
      status = 400;
      message = "Revisa los datos enviados.";
      details = error.issues.map((i) => ({
        field: i.path.join("."),
        message: i.message,
      }));
    } else if (error instanceof HttpException) {
      status = error.getStatus();
      const body = error.getResponse();
      message = typeof body === "string" ? body : (body as any).message;
    } else if (
      ["P2002", "P2003", "P2004", "P2034"].includes(error.code) ||
      error.meta?.code === "23P01" ||
      String(error.message).includes("no_unit_overlap")
    ) {
      status = 409;
      message =
        "Conflicto de inventario o referencia duplicada. Actualiza los datos y vuelve a intentarlo.";
    } else if (error.code === "P2025") {
      status = 404;
      message = "No se encontró el registro.";
    }
    if (status === 500) this.logger.error(error.stack || error);
    res.status(status).json({ statusCode: status, message, details });
  }
}
