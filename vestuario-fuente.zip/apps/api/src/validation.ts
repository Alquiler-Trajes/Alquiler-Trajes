import { z } from "zod";
export const id = z.string().min(1).max(100);
export const text = z.string().trim().min(1).max(200);
export const metric = z.enum(["height", "chest", "waist", "hip", "length"]);
export const measurementSchema = z
  .object({
    metric,
    garmentCm: z.number().positive().max(500).nullable().optional(),
    bodyMinCm: z.number().positive().max(500).nullable().optional(),
    bodyMaxCm: z.number().positive().max(500).nullable().optional(),
    easeCm: z.number().min(0).max(100).nullable().optional(),
  })
  .strict()
  .refine(
    (x) =>
      x.bodyMinCm == null || x.bodyMaxCm == null || x.bodyMinCm <= x.bodyMaxCm,
    "El rango corporal no es válido.",
  );
export const imagePath = z
  .string()
  .regex(/^\/(?:uploads\/[a-f0-9-]+\.webp|demo\/[a-z0-9-]+\.svg)$/);
export const costumeSchema = z
  .object({
    name: text,
    description: z.string().trim().max(3000).default(""),
    danceStyle: z.string().trim().max(100).nullable().default(null),
    includedAccessories: z.array(text).max(30).default([]),
    bundleSize: z.union([z.literal(1), z.literal(6)]).default(1),
    bundleImage: imagePath.nullable().default(null),
    categoryId: id,
    tags: z.array(text).max(30).default([]),
    searchTerms: z.string().max(1000).default(""),
    requiredMetrics: z.array(metric).max(5).default([]),
    featured: z.boolean().default(false),
    images: z.array(imagePath).max(10).default([]),
    size: text,
    color: text,
    price: z.number().int().nonnegative().max(10000000),
    quantity: z.number().int().min(0).max(100),
    location: z.string().max(200).default(""),
    commercialAgeMin: z.number().int().min(0).max(120).optional(),
    commercialAgeMax: z.number().int().min(0).max(120).optional(),
    elastic: z.boolean().default(false),
  })
  .strict();
export const intervalSchema = z
  .object({
    startsAt: z.string().datetime({ offset: true }),
    endsAt: z.string().datetime({ offset: true }),
  })
  .refine(
    (x) => new Date(x.startsAt) < new Date(x.endsAt),
    "La devolución debe ser posterior a la entrega.",
  );
export const requestSchema = z
  .object({
    name: text,
    contact: z.string().trim().min(7).max(100),
    startsAt: z.string().datetime({ offset: true }),
    endsAt: z.string().datetime({ offset: true }),
    notes: z.string().max(2000).default(""),
    items: z
      .array(
        z
          .object({ variantId: id, quantity: z.number().int().min(1).max(100) })
          .strict(),
      )
      .min(1)
      .max(30),
  })
  .strict()
  .refine(
    (x) => new Date(x.startsAt) < new Date(x.endsAt),
    "Las fechas no son válidas.",
  )
  .refine(
    (x) => new Set(x.items.map((i) => i.variantId)).size === x.items.length,
    "Combina cantidades de la misma variante.",
  );
export const outfitSchema = z
  .object({
    variantId: id,
    mode: z.enum(["FIXED", "FLEXIBLE"]),
    components: z
      .array(
        z
          .object({
            name: text,
            required: z.boolean().default(true),
            quantity: z.number().int().min(1).max(20).default(1),
            variantId: id.optional(),
            fixedUnitId: id.optional(),
            allowSubstitution: z.boolean().default(false),
            alternativeVariantIds: z.array(id).max(20).default([]),
          })
          .strict(),
      )
      .min(1)
      .max(20),
  })
  .strict()
  .superRefine((x, ctx) => {
    if (!x.components.some((c) => c.required))
      ctx.addIssue({
        code: "custom",
        message: "Incluye al menos un componente obligatorio.",
      });
    for (const c of x.components) {
      if (x.mode === "FIXED" && c.allowSubstitution)
        ctx.addIssue({
          code: "custom",
          message:
            "Usa un conjunto flexible para registrar variantes sustitutas.",
        });
      if (x.mode === "FIXED" && (!c.fixedUnitId || c.quantity !== 1))
        ctx.addIssue({
          code: "custom",
          message:
            "Un conjunto fijo requiere una unidad específica por componente.",
        });
      if (x.mode === "FLEXIBLE" && !c.variantId)
        ctx.addIssue({
          code: "custom",
          message: "Un conjunto flexible requiere una variante por componente.",
        });
    }
  });
