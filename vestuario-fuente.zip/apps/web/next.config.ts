import type { NextConfig } from "next";
import path from "node:path";
import dotenv from "dotenv";
dotenv.config({ path: path.resolve(process.cwd(), "../../.env"), quiet: true });
const pages = process.env.NEXT_PUBLIC_STATIC_CATALOG === "true";
const config: NextConfig = {
  distDir: process.env.NEXT_DIST_DIR || ".next",
  poweredByHeader: false,
  ...(pages ? {
    output: "export",
    trailingSlash: true,
    basePath: process.env.NEXT_PUBLIC_BASE_PATH || "/Alquiler-Trajes",
    images: { unoptimized: true },
  } : {}),
  ...(!pages ? { async rewrites() {
    return [
      {
        source: "/api/:path*",
        destination: `${process.env.API_INTERNAL_URL || "http://localhost:4000"}/api/:path*`,
      },
      {
        source: "/uploads/:path*",
        destination: `${process.env.API_INTERNAL_URL || "http://localhost:4000"}/uploads/:path*`,
      },
    ];
  } } : {}),
};
export default config;
