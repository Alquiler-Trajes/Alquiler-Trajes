import { staticCatalog } from "./public-mode";
export async function api<T = any>(
  path: string,
  options: RequestInit = {},
): Promise<T> {
  if (staticCatalog) {
    const { publicCatalogApi } = await import("./static-catalog");
    return publicCatalogApi(path, options) as Promise<T>;
  }
  const res = await fetch("/api" + path, {
    credentials: "same-origin",
    ...options,
    headers: {
      ...(options.body instanceof FormData
        ? {}
        : { "Content-Type": "application/json" }),
      ...options.headers,
    },
  });
  const data = await res
    .json()
    .catch(() => ({ message: "El servidor no está disponible." }));
  if (!res.ok)
    throw new Error(
      data.details?.length
        ? data.message +
          " " +
          data.details.map((i: any) => `${i.field}: ${i.message}`).join(" ")
        : data.message || "No pudimos completar la operación.",
    );
  return data;
}
export const mutation = (method: string, body: unknown): RequestInit => ({
  method,
  body: JSON.stringify(body),
});
export const hasPendingPrice = (price: number, tags: string[] = []) =>
  price === 0 && tags.includes("coleccion-real-octubre-2026");
export const compareSizes = (a: string, b: string) => {
  const labels = ["XS", "S", "M", "L", "XL", "XXL", "Niño", "Única"];
  const rank = (s: string) => /^\d+$/.test(s) ? Number(s) : 1000 + (labels.includes(s) ? labels.indexOf(s) : labels.length);
  return rank(a) - rank(b) || a.localeCompare(b, "es");
};
export const colombianDate = (iso: string) =>
  new Intl.DateTimeFormat("es-CO", {
    dateStyle: "medium",
    timeStyle: "short",
    timeZone: "America/Bogota",
  }).format(new Date(iso));
// Browser timezone is irrelevant: these wall times always belong to Bogotá.
export const bogotaISO = (local: string) =>
  local ? new Date(local + "-05:00").toISOString() : "";
export const localBogota = (iso: string) => {
  const d = new Date(new Date(iso).getTime() - 5 * 3600000);
  return d.toISOString().slice(0, 16);
};
export interface CatalogItem {
  id: string;
  slug: string;
  name: string;
  description: string;
  danceStyle?: string | null;
  includedAccessories?: string[];
  bundleSize?: number;
  bundleImage?: string | null;
  category: { id: string; name: string };
  images: string[];
  demo: boolean;
  featured: boolean;
  minPrice: number;
  tags: string[];
  requiredMetrics: string[];
  variants: any[];
}
