export const instagramHandle = "alquileresbga";
export const instagramProfileUrl = `https://www.instagram.com/${instagramHandle}/`;
export const instagramMessageUrl = `https://ig.me/m/${instagramHandle}`;
