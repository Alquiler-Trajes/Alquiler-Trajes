export const staticCatalog = process.env.NEXT_PUBLIC_STATIC_CATALOG === "true";
export const basePath = process.env.NEXT_PUBLIC_BASE_PATH || "";
export const asset = (url: string) => url.startsWith("/") && !url.startsWith("//") ? basePath + url : url;
