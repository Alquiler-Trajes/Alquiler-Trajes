import { LocalQueryInterpreter, normalize, relevance, costumeKind, costumeOrder, inCollection } from "@vestuario/shared";
import { asset } from "./public-mode";
import type { CatalogItem } from "./api";

export interface PublicSnapshot {
  publishedAt: string;
  items: CatalogItem[];
  categories: any[];
  navigationCategories: any[];
  styles: { name: string; count: number }[];
  config: { whatsappUrl: string | null; timezone: string };
}
let snapshot: Promise<PublicSnapshot> | undefined;
async function loadSnapshot() {
  if (!snapshot) snapshot = fetch(asset("/data/catalog.json")).then(async response => {
    if (!response.ok) throw new Error("No pudimos cargar el catálogo. Intenta recargar la página.");
    const data: PublicSnapshot = await response.json();
    data.items.forEach(item => {
      item.images = item.images.map(asset);
      if (item.bundleImage) item.bundleImage = asset(item.bundleImage);
    });
    return data;
  }).catch(error => { snapshot = undefined; throw error; });
  return snapshot;
}

// The public export reads only this allowlisted snapshot. It never simulates a
// successful reservation, availability lookup, login or inventory write.
export async function publicCatalogApi(path: string, options: RequestInit = {}) {
  if (options.method && options.method.toUpperCase() !== "GET")
    throw new Error("Confirma la disponibilidad y la reserva directamente con el negocio.");
  const data = await loadSnapshot();
  if (path === "/config") return data.config;
  const url = new URL(path, "https://catalog.invalid");
  if (url.pathname === "/catalog") return searchSnapshot(data, url.searchParams);
  const detail = url.pathname.match(/^\/catalog\/([^/]+)$/);
  if (detail) {
    const item = data.items.find(item => item.slug === decodeURIComponent(detail[1]));
    if (!item) throw new Error("No se encontró el traje.");
    return structuredClone(item);
  }
  throw new Error("Esta función requiere la aplicación de administración del negocio.");
}

export function searchSnapshot(data: PublicSnapshot, params: URLSearchParams) {
  const intent = new LocalQueryInterpreter().interpret(params.get("q") || "");
  const category = params.get("category"), style = params.get("style"), size = params.get("size");
  const color = params.get("color") || intent.color;
  const descendants = new Set(category ? [category] : []);
  for (let i = 0; i < data.categories.length; i++)
    for (const child of data.categories)
      if (descendants.has(child.parentId)) descendants.add(child.id);
  const rows = data.items.filter(item =>
    inCollection(item, data.categories, params.get("group")) &&
    (!params.get("kind") || costumeKind(item, data.categories) === params.get("kind")) &&
    (!category || descendants.has(item.category.id)) &&
    (!style || normalize(item.danceStyle || "").includes(normalize(style))));
  const items = rows.flatMap(item => {
    const score = relevance(intent, [item.name, item.description, item.danceStyle, ...item.tags, ...item.variants.map(v => v.color)].join(" "));
    if (!score) return [];
    const variants = item.variants.filter(v => (!size || v.size === size) && (!color || normalize(v.color).includes(normalize(color))));
    return variants.length ? [{ ...item, variants, score }] : [];
  });
  const sort = params.get("sort");
  items.sort((a, b) => (!sort || sort === "relevance" ? costumeOrder(a, data.categories) - costumeOrder(b, data.categories) : 0) || (sort === "price-asc" ? a.minPrice - b.minPrice : sort === "price-desc" ? b.minPrice - a.minPrice : sort === "name" ? a.name.localeCompare(b.name, "es") : b.score - a.score || Number(b.featured) - Number(a.featured) || a.name.localeCompare(b.name, "es")));
  const page = Math.max(1, Number(params.get("page")) || 1);
  return { ...data, config: undefined, items: items.slice((page - 1) * 24, page * 24), total: items.length, page,
    hasRealCollection: true, intent, suggestions: [], dates: null,
    filters: { sizes: [...new Set(rows.flatMap(item => item.variants.map(v => v.size)))], colors: [...new Set(rows.flatMap(item => item.variants.map(v => v.color)))] } };
}
