import Link from "next/link";
export default function NotFound() {
  return (
    <main id="main" className="container page-space">
      <h1>No encontramos esta página.</h1>
      <p>
        Vuelve al <Link href="/catalogo">catálogo de Vestuario</Link>.
      </p>
    </main>
  );
}
