"use client";
import { Button } from "@/components/ui";
export default function ErrorPage({ reset }: { reset: () => void }) {
  return (
    <main id="main" className="container page-space">
      <h1>Algo no salió como esperábamos.</h1>
      <p>Vuelve a intentarlo en un momento.</p>
      <Button onClick={reset}>Intentar de nuevo</Button>
    </main>
  );
}
