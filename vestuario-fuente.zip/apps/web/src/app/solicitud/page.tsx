import { Checkout } from "@/components/checkout";
export const metadata = { title: "Mi selección" };
export default Checkout;
