import { CollectionHome, type CollectionPhoto } from "@/components/collection-home";
import { readFile } from "node:fs/promises";
export default async function Home() {
  const snapshot = JSON.parse(await readFile("public/data/catalog.json", "utf8"));
  const photo = (slug: string): CollectionPhoto => {
    const item = snapshot.items.find((item: { slug: string }) => item.slug === slug);
    if (!item?.images[0]) throw new Error(`Falta la foto destacada de ${slug}`);
    return { name: item.name, image: item.images[0] };
  };
  return <CollectionHome photos={{
    culture: photo("real-folclor-aguamarina"),
    characters: photo("real-bella"),
    accessories: photo("real-princesa-joyeria-azul"),
  }} />;
}
