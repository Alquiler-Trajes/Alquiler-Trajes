import { CollectionHome, type CollectionSlide } from "@/components/collection-home";
import { readFile } from "node:fs/promises";
export default async function Home() {
  const snapshot = JSON.parse(await readFile("public/data/catalog.json", "utf8"));
  const slides = (slugs: string[]): CollectionSlide[] => slugs.map(slug => {
    const item = snapshot.items.find((item: { slug: string }) => item.slug === slug);
    if (!item?.images[0]) throw new Error(`Falta la foto destacada de ${slug}`);
    return { slug, name: item.name, image: item.images[0] };
  });
  return <CollectionHome photos={{
    culture: slides(["real-folclor-aguamarina", "real-elsa", "real-bella", "real-michael-jackson-completo", "real-oficial-epoca", "real-caballero-anos-20-completo", "real-folclor-multicolor", "real-rapunzel"]),
    characters: slides(["real-piloto", "real-hada-violeta", "real-pirata-aventurera", "real-astronauta", "real-vampiro-completo", "real-hada-verde"]),
    accessories: slides(["real-princesa-joyeria-azul", "real-pieza-diadema-charleston", "real-pieza-diadema-rosas-velo", "real-pirata-corsario", "real-hawaiano", "real-charleston"]),
  }} />;
}
