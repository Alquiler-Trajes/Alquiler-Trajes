import { CollectionHome } from "@/components/collection-home";
import { readFile } from "node:fs/promises";
export default async function Home() {
  const snapshot = JSON.parse(await readFile("public/data/catalog.json", "utf8"));
  const image = (slug: string) => snapshot.items.find((item: { slug: string }) => item.slug === slug)?.images[0] || "/placeholder.svg";
  return <CollectionHome images={{ cultural: image("real-folclor-aguamarina"), princess: image("real-elsa"), profession: image("real-medico"), costume: image("real-pirata-aventurera") }} />;
}
