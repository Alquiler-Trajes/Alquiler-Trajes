import { CatalogPage } from "@/components/catalog";
export default function Home() {
  return <CatalogPage home />;
}
