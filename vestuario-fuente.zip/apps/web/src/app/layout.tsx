import type { Metadata } from "next";
import { Providers } from "@/components/providers";
import "./globals.css";
import "./easy-public.css";
export const metadata: Metadata = {
  title: {
    default: "Vestuario · Tu próxima historia empieza aquí",
    template: "%s · Vestuario",
  },
  description:
    "Encuentra trajes culturales, disfraces y conjuntos. Consulta tallas y disponibilidad, y solicita tu alquiler sin crear una cuenta.",
};
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="es-CO" data-scroll-behavior="smooth">
      <body>
        <a className="skip-link" href="#main">
          Saltar al contenido
        </a>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
