"use client";
import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowRight, Flower2, LockKeyhole } from "lucide-react";
import { api, mutation } from "@/lib/api";
import { Button, ErrorBox, Field, Input } from "@/components/ui";
import { staticCatalog } from "@/lib/public-mode";
import { PublicAdminNotice } from "@/components/public-admin-notice";
export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  if (staticCatalog) return <PublicAdminNotice />;
  return (
    <main id="main" className="auth-page">
      <aside className="auth-art">
        <Link href="/" className="logo">
          <Flower2 size={30} />
          vestuario
        </Link>
        <div>
          <p className="eyebrow">DETRÁS DE CADA GRAN MOMENTO</p>
          <h1>
            Todo listo.
            <br />
            Para la próxima
            <br />
            <i>historia.</i>
          </h1>
          <p>
            Un espacio sencillo para cuidar cada prenda, organizar tus
            alquileres y hacer crecer tu negocio.
          </p>
        </div>
        <small>Administración de Vestuario</small>
        <span className="auth-decoration">✳</span>
      </aside>
      <div className="auth-form-wrap">
        <form
          className="auth-form"
          onSubmit={async (e) => {
            e.preventDefault();
            setBusy(true);
            setError("");
            try {
              await api("/auth/login", mutation("POST", { email, password }));
              router.replace("/admin");
            } catch (e: any) {
              setError(e.message);
            } finally {
              setBusy(false);
            }
          }}
        >
          <LockKeyhole
            size={25}
            style={{ marginBottom: 22, color: "#839777" }}
          />
          <h2>Qué bueno verte.</h2>
          <p>Ingresa para administrar tu vestuario.</p>
          <Field label="Correo electrónico">
            <Input
              type="email"
              autoComplete="username"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </Field>
          <Field label="Contraseña">
            <Input
              type="password"
              autoComplete="current-password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </Field>
          <ErrorBox message={error} />
          <Button disabled={busy}>
            {busy ? "Ingresando…" : "Ingresar al administrador"}
            <ArrowRight size={16} />
          </Button>
          <Link href="/">Volver al catálogo público</Link>
        </form>
      </div>
    </main>
  );
}
