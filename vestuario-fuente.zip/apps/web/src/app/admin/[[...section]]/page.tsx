import { AdminApp } from "@/components/admin/app";
import { PublicAdminNotice } from "@/components/public-admin-notice";
export function generateStaticParams() {
  return [{ section: [] }, ...["dashboard", "inventario", "alquileres", "calendario", "clientes", "categorias", "conjuntos", "importar"].map(section => ({ section: [section] }))];
}
export const metadata = {
  title: "Administración",
  robots: { index: false, follow: false },
};
export default async function Admin({
  params,
}: {
  params: Promise<{ section?: string[] }>;
}) {
  const { section } = await params;
  if (process.env.NEXT_PUBLIC_STATIC_CATALOG === "true") return <PublicAdminNotice />;
  return <AdminApp section={section?.[0] || "dashboard"} />;
}
