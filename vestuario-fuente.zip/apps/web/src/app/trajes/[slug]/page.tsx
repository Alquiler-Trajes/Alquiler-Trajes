import { ProductDetail } from "@/components/product-detail";
export async function generateStaticParams() {
  if (process.env.NEXT_PUBLIC_STATIC_CATALOG !== "true") return [];
  const { readFile } = await import("node:fs/promises");
  const data = JSON.parse(await readFile("public/data/catalog.json", "utf8"));
  return data.items.map((item: { slug: string }) => ({ slug: item.slug }));
}
export default async function Product({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  return <ProductDetail slug={slug} />;
}
