import { CatalogPage } from "@/components/catalog";
export const metadata = { title: "Catálogo" };
export default function Catalog() {
  return <CatalogPage />;
}
