"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { ArrowRight, Check, ChevronLeft, ChevronRight, Flower2, Gem, Pause, Play } from "lucide-react";
import { asset } from "@/lib/public-mode";

export type CollectionSlide = { slug: string; name: string; image: string };
type HomePhotos = Record<"culture" | "characters" | "accessories", CollectionSlide[]>;
const collections = [
  { key: "culture", group: "celebraciones", title: "Danzas y cultura", kicker: "Tradición y escenario", description: "Trajes de danza, de época y vestidos de princesa.", action: "Ver trajes", theme: "celebration-door" },
  { key: "characters", group: "personajes", title: "Profesiones y disfraces", kicker: "Imagina tu personaje", description: "Uniformes y personajes para una ocasión especial.", action: "Ver trajes", theme: "character-door" },
  { key: "accessories", group: "accesorios", title: "Accesorios", kicker: "El detalle que lo cambia todo", description: "Sombreros, coronas y kits. Alquílalos por separado.", action: "Ver accesorios", theme: "accessory-door" },
] as const;

function CollectionCarousel({ collection, slides, playing, stop }: {
  collection: typeof collections[number]; slides: CollectionSlide[]; playing: boolean; stop: () => void;
}) {
  const [index, setIndex] = useState(0);
  const [hovered, setHovered] = useState(false);
  const rotating = playing && !hovered && slides.length > 1;
  useEffect(() => {
    if (!rotating) return;
    const timer = window.setInterval(() => setIndex(value => (value + 1) % slides.length), 7000);
    return () => window.clearInterval(timer);
  }, [rotating, slides.length]);
  const move = (direction: number) => {
    stop();
    setIndex(value => (value + direction + slides.length) % slides.length);
  };
  const href = `/catalogo?group=${collection.group}`;
  return <article className={`collection-door ${collection.theme}`} onMouseEnter={() => setHovered(true)} onMouseLeave={() => setHovered(false)}>
    <div className="door-heading"><p>{collection.kicker}</p><h2>{collection.title}</h2></div>
    <div className="collection-carousel" role="group" aria-roledescription="carrusel" aria-label={`Fotos de ${collection.title}`} data-rotating={rotating}>
      <Link href={href} className="carousel-gallery" aria-label={`Ver colección ${collection.title}`} tabIndex={-1}>
        <span className="carousel-halo" aria-hidden="true" />
        <img className="carousel-peek carousel-peek-left" src={asset(slides[(index + slides.length - 1) % slides.length].image)} alt="" aria-hidden="true" loading="lazy" />
        <img className="carousel-peek carousel-peek-right" src={asset(slides[(index + 1) % slides.length].image)} alt="" aria-hidden="true" loading="lazy" />
        <div className="carousel-photo-frame">
          {slides.map((slide, position) => <img key={slide.slug} className={`carousel-photo${position === index ? " is-current" : ""}`} src={asset(slide.image)} alt="" aria-hidden="true" loading={position === 0 ? "eager" : "lazy"} fetchPriority={position === 0 && collection.key === "culture" ? "high" : "auto"} />)}
        </div>
        {collection.key === "accessories" && <span className="carousel-rental-badge"><Gem size={16} aria-hidden="true" /> También en alquiler</span>}
      </Link>
      <div className="carousel-controls">
        <button type="button" onClick={() => move(-1)} aria-label={`Foto anterior de ${collection.title}`}><ChevronLeft size={21} /></button>
        <div><p aria-live={playing ? "off" : "polite"} aria-atomic="true">{slides[index].name}</p><span aria-label={`Foto ${index + 1} de ${slides.length}`}>{index + 1} / {slides.length}</span></div>
        <button type="button" onClick={() => move(1)} aria-label={`Foto siguiente de ${collection.title}`}><ChevronRight size={21} /></button>
      </div>
    </div>
    <div className="door-copy"><span>{collection.description}</span><Link href={href} className="door-action" aria-label={`Explorar ${collection.title}`}>{collection.action} <ArrowRight size={22} aria-hidden="true" /></Link></div>
  </article>;
}

export function CollectionHome({ photos }: { photos: HomePhotos }) {
  const [playing, setPlaying] = useState(false);
  const [visible, setVisible] = useState(true);
  useEffect(() => {
    const preference = window.matchMedia("(prefers-reduced-motion: reduce)");
    setPlaying(!preference.matches);
    const motionChange = () => { if (preference.matches) setPlaying(false); };
    const visibilityChange = () => setVisible(!document.hidden);
    visibilityChange();
    preference.addEventListener("change", motionChange);
    document.addEventListener("visibilitychange", visibilityChange);
    return () => {
      preference.removeEventListener("change", motionChange);
      document.removeEventListener("visibilitychange", visibilityChange);
    };
  }, []);
  return <main id="main" className="collection-home container">
    <div className="welcome-copy">
      <p className="welcome-kicker"><Flower2 size={20} /> Un traje para cada ocasión</p>
      <h1>¿Qué te gustaría<br /><em>vestir hoy?</em></h1>
      <p>Elige una colección y encuentra tu favorito.</p>
    </div>
    <div className="carousel-playback"><button type="button" onClick={() => setPlaying(value => !value)}>{playing ? <Pause size={18} /> : <Play size={18} />}{playing ? "Pausar fotos" : "Reproducir fotos"}</button></div>
    <div className="collection-doors" onFocusCapture={() => setPlaying(false)}>
      {collections.map(collection => <CollectionCarousel key={collection.key} collection={collection} slides={photos[collection.key]} playing={playing && visible} stop={() => setPlaying(false)} />)}
    </div>
    <section className="simple-how" aria-label="Cómo elegir tu vestuario"><h2>Así de sencillo.</h2><ol><li><span>1</span><div><strong>Explora una colección</strong><p>Encuentra tu traje o accesorio.</p></div></li><li><span>2</span><div><strong>Elige cómo alquilarlo</strong><p>Consulta tallas, colores y juegos de seis.</p></div></li><li><span>3</span><div><strong>Revisa «Mi selección»</strong><p>Comparte tu selección y acordamos el alquiler.</p></div></li></ol><p className="home-reassurance"><Check size={19} /> Puedes explorar sin registrarte.</p></section>
  </main>;
}
