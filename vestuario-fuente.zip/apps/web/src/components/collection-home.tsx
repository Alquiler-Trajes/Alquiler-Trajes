import Link from "next/link";
import { Check, Flower2 } from "lucide-react";
import { asset } from "@/lib/public-mode";

export type CollectionPhoto = { name: string; image: string };
type HomePhotos = Record<"culture" | "characters" | "accessories", CollectionPhoto>;
const collections = [
  { key: "culture", group: "celebraciones", title: "Danzas y cultura", theme: "culture-highlight" },
  { key: "characters", group: "personajes", title: "Disfraces", theme: "character-highlight" },
  { key: "accessories", group: "accesorios", title: "Accesorios", theme: "accessory-highlight" },
] as const;

export function CollectionHome({ photos }: { photos: HomePhotos }) {
  return <main id="main" className="collection-home container">
    <div className="welcome-copy">
      <p className="welcome-kicker"><Flower2 size={20} aria-hidden="true" /> Un traje para cada ocasión</p>
      <h1>¿Qué te gustaría<br /><em>vestir hoy?</em></h1>
      <p>Toca una colección para descubrirla.</p>
    </div>
    <nav className="collection-highlights" aria-label="Colecciones">
      {collections.map(collection => <Link key={collection.key} href={`/catalogo?group=${collection.group}`} className={`collection-highlight ${collection.theme}`} aria-label={`Explorar ${collection.title}`}>
        <span className="highlight-ring"><span className="highlight-photo"><img src={asset(photos[collection.key].image)} alt="" width={220} height={220} fetchPriority={collection.key === "culture" ? "high" : "auto"} /></span></span>
        <span className="highlight-label">{collection.title}</span>
      </Link>)}
    </nav>
    <section className="simple-how" aria-label="Cómo elegir tu vestuario"><h2>Así de sencillo.</h2><ol><li><span>1</span><div><strong>Explora una colección</strong><p>Encuentra tu traje o accesorio.</p></div></li><li><span>2</span><div><strong>Elige cómo alquilarlo</strong><p>Consulta tallas, colores y juegos de seis.</p></div></li><li><span>3</span><div><strong>Escríbenos por Instagram</strong><p>Comparte tu selección y acordamos el alquiler.</p></div></li></ol><p className="home-reassurance"><Check size={19} aria-hidden="true" /> Puedes explorar sin registrarte.</p></section>
  </main>;
}
