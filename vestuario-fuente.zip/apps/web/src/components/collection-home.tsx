import Link from "next/link";
import { ArrowRight, Check, Flower2 } from "lucide-react";
import { asset } from "@/lib/public-mode";
export function CollectionHome({ images }: { images: Record<string, string> }) {
  return <main id="main" className="collection-home container">
    <div className="welcome-copy">
      <p className="welcome-kicker"><Flower2 size={20} /> Un traje para cada ocasión</p>
      <h1>¿Qué te gustaría<br /><em>vestir hoy?</em></h1>
      <p>Elige una colección para empezar.</p>
    </div>
    <div className="collection-doors">
      <Link href="/catalogo?group=celebraciones" className="collection-door celebration-door" aria-label="Explorar Danzas y princesas">
        <div className="door-art" aria-hidden="true"><span className="door-orbit" /><div className="door-frame door-frame-back"><img src={asset(images.cultural)} alt="" fetchPriority="high" /></div><div className="door-frame door-frame-front"><img src={asset(images.princess)} alt="" fetchPriority="high" /></div><span className="door-star">✳</span></div>
        <div className="door-copy"><p>Tradición e ilusión</p><h2>Danzas y princesas</h2><span>Trajes culturales, bailes y vestidos de princesa.</span><strong>Ver colección <ArrowRight size={23} /></strong></div>
      </Link>
      <Link href="/catalogo?group=personajes" className="collection-door character-door" aria-label="Explorar Profesiones y disfraces">
        <div className="door-art" aria-hidden="true"><span className="door-orbit" /><div className="door-frame door-frame-back"><img src={asset(images.profession)} alt="" /></div><div className="door-frame door-frame-front"><img src={asset(images.costume)} alt="" /></div><span className="door-star">✧</span></div>
        <div className="door-copy"><p>Imagina tu personaje</p><h2>Profesiones y disfraces</h2><span>De médico o astronauta a tu personaje favorito.</span><strong>Ver colección <ArrowRight size={23} /></strong></div>
      </Link>
    </div>
    <div className="accessory-entry"><Link href="/catalogo?group=accesorios" className="text-link">También puedes alquilar accesorios <ArrowRight size={22} /></Link><p>Sombreros, complementos y kits para tu personaje.</p></div>
    <section className="simple-how" aria-label="Cómo elegir tu vestuario"><h2>Así de sencillo.</h2><ol><li><span>1</span><div><strong>Explora una colección</strong><p>Mira las fotos y encuentra tu traje.</p></div></li><li><span>2</span><div><strong>Elige talla y cantidad</strong><p>Una unidad o el juego completo de seis.</p></div></li><li><span>3</span><div><strong>Revisa «Mi selección»</strong><p>Comparte tu selección y acordamos el alquiler.</p></div></li></ol><p className="home-reassurance"><Check size={19} /> Puedes explorar sin registrarte.</p></section>
  </main>;
}
