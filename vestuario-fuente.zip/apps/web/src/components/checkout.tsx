"use client";
import Link from "next/link";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  Copy,
  Instagram,
  MessageCircle,
  ShoppingBag,
  Trash2,
} from "lucide-react";
import { money } from "@vestuario/shared";
import { api, bogotaISO, mutation } from "@/lib/api";
import { useStore, cartKey } from "./providers";
import { Badge, Button, Empty, ErrorBox, Field, Input } from "./ui";
import { staticCatalog } from "@/lib/public-mode";
import { PublicSelection } from "./public-selection";
import { instagramMessageUrl } from "@/lib/contact";
const schema = z
  .object({
    name: z.string().trim().min(2, "Escribe tu nombre."),
    contact: z
      .string()
      .trim()
      .min(7, "Escribe un teléfono o correo de contacto."),
    startsAt: z.string().min(1, "Elige la entrega."),
    endsAt: z.string().min(1, "Elige la devolución."),
    notes: z.string().max(2000),
  })
  .refine((d) => new Date(d.startsAt) < new Date(d.endsAt), {
    path: ["endsAt"],
    message: "La devolución debe ser posterior a la entrega.",
  });
type Values = z.infer<typeof schema>;
export function Checkout() {
  const { cart, setQuantity, clear, notify } = useStore();
  const [error, setError] = useState("");
  const [result, setResult] = useState<any>(null);
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<Values>({
    resolver: zodResolver(schema),
    defaultValues: { notes: "" },
  });
  const total = cart.reduce((s, i) => s + i.price * i.quantity, 0);
  const selections = [...new Map(cart.map(i => [i.bundleId || cartKey(i), i])).keys()].map(key => {
    const items = cart.filter(i => (i.bundleId || cartKey(i)) === key);
    return { key, first: items[0], items, quantity: items.reduce((n, i) => n + i.quantity, 0), total: items.reduce((n, i) => n + i.quantity * i.price, 0) };
  });
  const submit = async (values: Values) => {
    setError("");
    try {
      const result = await api(
        "/requests",
        mutation("POST", {
          ...values,
          startsAt: bogotaISO(values.startsAt),
          endsAt: bogotaISO(values.endsAt),
          items: [...new Set(cart.map(i => i.variantId))].map(variantId => ({
            variantId, quantity: cart.filter(i => i.variantId === variantId).reduce((n, i) => n + i.quantity, 0),
          })),
        }),
      );
      setResult(result);
      clear();
    } catch (e: any) {
      setError(e.message);
    }
  };
  if (staticCatalog) return <PublicSelection />;
  if (result)
    return (
      <main id="main" className="container confirmation-page">
        <span className="confirmation-icon">
          <Check size={38} />
        </span>
        <p className="eyebrow">TU PRÓXIMO MOMENTO ESTÁ MÁS CERCA</p>
        <h1>Recibimos tu solicitud.</h1>
        <p>
          El negocio revisará la disponibilidad y se pondrá en contacto contigo.
          <br />
          Tu solicitud todavía no es una reserva confirmada.
        </p>
        <Badge>{result.reference}</Badge>
        {result.demo && (
          <p className="info-box">
            Esta solicitud contiene artículos de demostración y no corresponde a
            inventario real del negocio.
          </p>
        )}
        <div className="confirmation-summary">
          <strong>Total solicitado: {money(result.total)}</strong>
          <pre>{result.message}</pre>
        </div>
        {result.whatsappUrl ? (
          <Button asChild>
            <a href={result.whatsappUrl} target="_blank" rel="noreferrer">
              <MessageCircle size={18} /> Enviar solicitud por WhatsApp
            </a>
          </Button>
        ) : (
          <Button asChild><a href={instagramMessageUrl} target="_blank" rel="noreferrer"><Instagram size={20} /> Consultar por Instagram</a></Button>
        )}
        <Button
          variant="outline"
          onClick={async () => {
            try {
              await navigator.clipboard.writeText(result.message);
              notify("Mensaje copiado.");
            } catch {
              notify("Selecciona y copia el texto del resumen.");
            }
          }}
        >
          <Copy size={16} /> Copiar resumen
        </Button>
        <Link className="text-link" href="/catalogo">
          Seguir explorando <ArrowRight size={16} />
        </Link>
      </main>
    );
  return (
    <main id="main" className="container checkout-page">
      <Link href="/catalogo" className="text-link">
        <ArrowLeft size={16} /> Seguir explorando
      </Link>
      <p className="eyebrow">UN PASO MÁS CERCA DE TU HISTORIA</p>
      <h1>Tu selección.</h1>
      <p className="page-description">
        Completa tus fechas y datos de contacto. Nosotros nos encargamos del
        siguiente paso.
      </p>
      {!cart.length ? (
        <Empty title="Tu próxima historia está por elegir.">
          <p>Agrega uno o varios trajes desde el catálogo.</p>
          <Button asChild>
            <Link href="/catalogo">
              Explorar el vestuario <ArrowRight size={17} />
            </Link>
          </Button>
        </Empty>
      ) : (
        <form onSubmit={handleSubmit(submit)} className="checkout-grid">
          <div>
            <div className="cart-items">
              {selections.map(({ key, first: i, items, quantity, total: lineTotal }) => (
                <div className={`cart-item ${i.bundleId ? "cart-bundle" : ""}`} key={key}>
                  <img src={i.image || "/placeholder.svg"} alt={i.name} />
                  <div>
                    <Link href={`/trajes/${i.slug}`}>
                      <h3>{i.name}</h3>
                    </Link>
                    <p>
                      {i.bundleId ? items.map(x => `${x.quantity} talla ${x.size}`).join(" + ") : `Talla ${i.size}`} · {i.color}
                    </p>
                    {i.bundleLabel && <Badge>{i.bundleLabel} · accesorios incluidos</Badge>}
                    {i.demo && (
                      <Badge tone="warning">Artículo ficticio · Demo</Badge>
                    )}
                    <strong>{money(lineTotal)}</strong>
                  </div>
                  <div className="cart-quantity">
                    <label className="sr-only" htmlFor={cartKey(i)}>
                      Cantidad de {i.name}
                    </label>
                    <Input
                      id={cartKey(i)}
                      type="number"
                      min="1"
                      max="100"
                      value={quantity}
                      readOnly={!!i.bundleId}
                      onChange={(e) =>
                        setQuantity(
                          cartKey(i),
                          Math.max(1, Number(e.target.value) || 1),
                        )
                      }
                    />
                    {i.bundleId && <small>trajes · 1 juego</small>}
                    <button
                      type="button"
                      className="icon-button"
                      aria-label={`Quitar ${i.bundleId ? "juego completo de " : ""}${i.name}`}
                      onClick={() => setQuantity(cartKey(i), 0)}
                    >
                      <Trash2 size={17} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
            <div className="form-card">
              <h2>¿Para cuándo?</h2>
              <div className="form-grid">
                <Field label="Entrega · hora de Bogotá">
                  <Input type="datetime-local" {...register("startsAt")} />
                  {errors.startsAt && (
                    <small className="field-error">
                      {errors.startsAt.message}
                    </small>
                  )}
                </Field>
                <Field label="Devolución · hora de Bogotá">
                  <Input type="datetime-local" {...register("endsAt")} />
                  {errors.endsAt && (
                    <small className="field-error">
                      {errors.endsAt.message}
                    </small>
                  )}
                </Field>
              </div>
              <h2>¿Cómo te contactamos?</h2>
              <div className="form-grid">
                <Field label="Tu nombre">
                  <Input autoComplete="name" {...register("name")} />
                  {errors.name && (
                    <small className="field-error">{errors.name.message}</small>
                  )}
                </Field>
                <Field label="Celular o correo">
                  <Input autoComplete="tel" {...register("contact")} />
                  {errors.contact && (
                    <small className="field-error">
                      {errors.contact.message}
                    </small>
                  )}
                </Field>
              </div>
              <Field label="¿Algo que debamos saber? (opcional)">
                <textarea
                  rows={3}
                  placeholder="Cuéntanos sobre tu evento o tus dudas de talla…"
                  {...register("notes")}
                />
              </Field>
            </div>
          </div>
          <aside className="order-summary">
            <ShoppingBag size={24} />
            <h2>Tu próximo momento</h2>
            <p>
              {cart.reduce((s, i) => s + i.quantity, 0)} prendas o conjuntos
              seleccionados
            </p>
            <div className="summary-total">
              <span>Total de alquiler</span>
              <strong>{money(total)}</strong>
            </div>
            <p className="fine-print">
              Los precios se actualizan con el inventario al enviar. El
              depósito, si aplica, se acuerda con el negocio.
            </p>
            <ErrorBox message={error} />
            <Button disabled={isSubmitting} type="submit">
              {isSubmitting ? "Enviando solicitud…" : "Solicitar alquiler"}
              <ArrowRight size={17} />
            </Button>
            <p className="fine-print">
              <Check size={14} /> Sin crear una cuenta
            </p>
            <div className="summary-note">
              Enviar esta solicitud no bloquea prendas. Recibirás la
              confirmación después de que el negocio revise disponibilidad y
              tallas.
            </div>
          </aside>
        </form>
      )}
    </main>
  );
}
