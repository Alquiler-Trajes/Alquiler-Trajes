"use client";
import { useEffect, useState } from "react";
import {
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  Plus,
  RefreshCw,
} from "lucide-react";
import { money, statusLabels } from "@vestuario/shared";
import {
  api,
  bogotaISO,
  colombianDate,
  localBogota,
  mutation,
} from "@/lib/api";
import { Badge, Button, Dialog, ErrorBox, Field, Input, Loading } from "../ui";
import { useStore } from "../providers";
function useRentals() {
  const [items, setItems] = useState<any[]>([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const load = async () => {
    try {
      setItems(await api("/admin/rentals"));
      setError("");
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    void load();
  }, []);
  return { items, error, loading, load };
}
export function RentalsView() {
  const { items, error, loading, load } = useRentals();
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");
  const [selected, setSelected] = useState<any>(null);
  const rows = items.filter(
    (r) =>
      (!status || r.status === status) &&
      `${r.reference} ${r.customer.name} ${r.customer.contact}`
        .toLowerCase()
        .includes(search.toLowerCase()),
  );
  return (
    <>
      <div className="admin-title">
        <div>
          <h1>Cada momento, organizado.</h1>
          <p>De la primera solicitud a la última devolución.</p>
        </div>
        <Button variant="outline" onClick={load}>
          <RefreshCw size={15} /> Actualizar
        </Button>
      </div>
      <ErrorBox message={error} />
      <section className="admin-section">
        <div className="admin-filter-row">
          <Input
            aria-label="Buscar alquileres"
            placeholder="Buscar referencia, cliente o contacto…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <select
            aria-label="Filtrar estado"
            value={status}
            onChange={(e) => setStatus(e.target.value)}
          >
            <option value="">Todos los estados</option>
            {[
              "REQUESTED",
              "CONFIRMED",
              "PREPARING",
              "DELIVERED",
              "RETURNED",
              "CLOSED",
              "CANCELLED",
            ].map((s) => (
              <option key={s} value={s}>
                {statusLabels[s]}
              </option>
            ))}
          </select>
        </div>
        {loading ? (
          <Loading />
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Referencia / cliente</th>
                  <th>Entrega</th>
                  <th>Devolución</th>
                  <th>Estado</th>
                  <th>Saldo</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id}>
                    <td>
                      <div className="table-name">
                        <div>
                          <strong>
                            {r.reference} {r.demo && <Badge>Demo</Badge>}
                          </strong>
                          <small>{r.customer.name}</small>
                        </div>
                      </div>
                    </td>
                    <td>{colombianDate(r.startsAt)}</td>
                    <td>
                      {colombianDate(r.endsAt)}{" "}
                      {r.overdue && <Badge tone="danger">Vencida</Badge>}
                    </td>
                    <td>
                      <Badge
                        tone={r.status === "REQUESTED" ? "warning" : "default"}
                      >
                        {statusLabels[r.status]}
                      </Badge>
                    </td>
                    <td>{money(r.balance)}</td>
                    <td>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setSelected(r)}
                      >
                        Gestionar
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {!rows.length && (
              <p className="admin-empty">
                No hay alquileres con estos filtros.
              </p>
            )}
          </div>
        )}
      </section>
      <Dialog
        title={selected?.reference || "Alquiler"}
        open={!!selected}
        onClose={() => setSelected(null)}
        wide
      >
        {selected && (
          <RentalDetail
            rental={items.find((i) => i.id === selected.id) || selected}
            onSaved={load}
          />
        )}
      </Dialog>
    </>
  );
}
export function RentalDetail({
  rental: r,
  onSaved,
}: {
  rental: any;
  onSaved: () => Promise<void>;
}) {
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [returns, setReturns] = useState<
    Record<string, { condition: string; note: string }>
  >({});
  const { notify } = useStore();
  const run = async (fn: () => Promise<any>, message: string) => {
    setBusy(true);
    setError("");
    try {
      await fn();
      await onSaved();
      notify(message);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };
  const action = (status: string) => {
    if (
      status === "CANCELLED" &&
      !window.confirm(
        "¿Cancelar esta reserva y liberar sus prendas? Se conservará el historial y los pagos.",
      )
    )
      return;
    void run(
      () =>
        api(
          "/admin/rentals/" + r.id + "/status",
          mutation("PATCH", { status }),
        ),
      "Estado actualizado.",
    );
  };
  const pending = r.items.flatMap((i: any) =>
    i.allocations.filter((a: any) => !a.returnedAt),
  );
  return (
    <>
      <div className="rental-info">
        <div>
          <strong>{r.customer.name}</strong>
          <p>{r.customer.contact}</p>
          <p>{r.notes || "Sin observaciones"}</p>
        </div>
        <div>
          <Badge tone={r.overdue ? "danger" : "default"}>
            {statusLabels[r.status]}
            {r.overdue ? " · Devolución vencida" : ""}
          </Badge>
          <p>Entrega: {colombianDate(r.startsAt)}</p>
          <p>Devolución: {colombianDate(r.endsAt)}</p>
          {r.demo && <p>Datos ficticios de demostración</p>}
        </div>
      </div>
      <div className="rental-items">
        {r.items.map((i: any) => (
          <div className="rental-item" key={i.id}>
            <strong>
              {i.quantity} × {i.variant.costume.name}
            </strong>
            <p>
              Talla {i.variant.size} · {i.variant.color} · {money(i.unitPrice)}{" "}
              cada uno
            </p>
            {i.allocations.length > 0 && (
              <p>
                Unidades:{" "}
                {i.allocations
                  .map(
                    (a: any) =>
                      a.unit.code + (a.returnedAt ? " (devuelta)" : ""),
                  )
                  .join(", ")}
              </p>
            )}
          </div>
        ))}
      </div>
      <ErrorBox message={error} />
      <div className="rental-controls">
        {r.status === "REQUESTED" && (
          <Button disabled={busy} onClick={() => action("CONFIRMED")}>
            Confirmar y asignar prendas
          </Button>
        )}
        {r.status === "CONFIRMED" && (
          <Button disabled={busy} onClick={() => action("PREPARING")}>
            Pasar a preparación
          </Button>
        )}
        {r.status === "PREPARING" && (
          <Button disabled={busy} onClick={() => action("DELIVERED")}>
            Registrar entrega
          </Button>
        )}
        {r.status === "RETURNED" && (
          <Button disabled={busy} onClick={() => action("CLOSED")}>
            Cerrar alquiler
          </Button>
        )}
        {["REQUESTED", "CONFIRMED", "PREPARING"].includes(r.status) && (
          <Button
            variant="outline"
            disabled={busy}
            onClick={() => action("CANCELLED")}
          >
            Cancelar solicitud
          </Button>
        )}
      </div>
      {r.status === "REQUESTED" && (
        <p className="fine-print">
          La confirmación vuelve a validar disponibilidad y asigna unidades
          físicas en una transacción.
        </p>
      )}
      {r.status === "DELIVERED" && (
        <section className="unit-card">
          <h3>Registrar devolución total o parcial</h3>
          <p className="fine-print">
            Selecciona las unidades recibidas. Quedarán pendientes de limpieza o
            reparación hasta que actualices su estado en inventario.
          </p>
          {pending.map((a: any) => (
            <div className="unit-card" key={a.id}>
              <label className="checkbox">
                <input
                  type="checkbox"
                  checked={!!returns[a.unitId]}
                  onChange={(e) => {
                    const next = { ...returns };
                    if (e.target.checked)
                      next[a.unitId] = { condition: "CLEANING", note: "" };
                    else delete next[a.unitId];
                    setReturns(next);
                  }}
                />
                {a.unit.code}
              </label>
              {returns[a.unitId] && (
                <div className="form-grid" style={{ marginTop: 12 }}>
                  <Field label="Revisión requerida">
                    <select
                      value={returns[a.unitId].condition}
                      onChange={(e) =>
                        setReturns({
                          ...returns,
                          [a.unitId]: {
                            ...returns[a.unitId],
                            condition: e.target.value,
                          },
                        })
                      }
                    >
                      <option value="CLEANING">Limpieza</option>
                      <option value="REPAIR">Reparación o daño</option>
                    </select>
                  </Field>
                  <Field label="Observaciones">
                    <Input
                      value={returns[a.unitId].note}
                      onChange={(e) =>
                        setReturns({
                          ...returns,
                          [a.unitId]: {
                            ...returns[a.unitId],
                            note: e.target.value,
                          },
                        })
                      }
                    />
                  </Field>
                </div>
              )}
            </div>
          ))}
          <Button
            disabled={busy || !Object.keys(returns).length}
            onClick={() =>
              void run(async () => {
                await api(
                  "/admin/rentals/" + r.id + "/return",
                  mutation("POST", {
                    units: Object.entries(returns).map(([unitId, values]) => ({
                      unitId,
                      ...values,
                    })),
                  }),
                );
                setReturns({});
              }, "Devolución registrada. Las prendas requieren revisión.")
            }
          >
            Registrar {Object.keys(returns).length} unidades devueltas
          </Button>
        </section>
      )}
      {["REQUESTED", "CONFIRMED", "PREPARING", "DELIVERED"].includes(
        r.status,
      ) && (
        <details style={{ margin: "20px 0" }}>
          <summary style={{ fontSize: 12, cursor: "pointer" }}>
            Ajustar fechas / registrar prórroga
          </summary>
          <form
            className="inline-form"
            onSubmit={(e) => {
              e.preventDefault();
              const f = new FormData(e.currentTarget);
              void run(
                () =>
                  api(
                    "/admin/rentals/" + r.id + "/dates",
                    mutation("PATCH", {
                      startsAt: bogotaISO(String(f.get("start"))),
                      endsAt: bogotaISO(String(f.get("end"))),
                    }),
                  ),
                "Fechas actualizadas y disponibilidad revalidada.",
              );
            }}
          >
            <Field label="Entrega · Bogotá">
              <Input
                key={r.startsAt}
                name="start"
                type="datetime-local"
                defaultValue={localBogota(r.startsAt)}
                required
                readOnly={r.status === "DELIVERED"}
              />
            </Field>
            <Field label="Devolución · Bogotá">
              <Input
                key={r.endsAt}
                name="end"
                type="datetime-local"
                defaultValue={localBogota(r.endsAt)}
                required
              />
            </Field>
            <Button size="sm" variant="outline" disabled={busy}>
              Guardar fechas
            </Button>
          </form>
        </details>
      )}
      <h3 style={{ marginTop: 25 }}>Pagos y garantía</h3>
      <div className="payment-grid">
        {[
          ["Total alquiler", r.total],
          ["Abonado neto", r.paid],
          ["Saldo alquiler", r.balance],
          ["Garantía por devolver", r.deposit],
        ].map(([label, value]: any) => (
          <div className="payment-card" key={label}>
            <p>{label}</p>
            <strong>{money(value)}</strong>
          </div>
        ))}
      </div>
      {r.status !== "CLOSED" && (
        <form
          className="inline-form"
          onSubmit={(e) => {
            e.preventDefault();
            const f = new FormData(e.currentTarget);
            void run(
              () =>
                api(
                  "/admin/rentals/" + r.id + "/payments",
                  mutation("POST", {
                    kind: f.get("kind"),
                    amount: Number(f.get("amount")),
                    method: f.get("method"),
                    note: f.get("note"),
                  }),
                ),
              "Movimiento de pago registrado.",
            );
          }}
        >
          <Field label="Tipo de movimiento">
            <select name="kind">
              <option value="RENT">Abono de alquiler</option>
              <option value="DEPOSIT">Recibir garantía</option>
              <option value="REFUND">Devolver abono</option>
              <option value="DEPOSIT_REFUND">Devolver garantía</option>
            </select>
          </Field>
          <Field label="Valor COP">
            <Input
              name="amount"
              type="number"
              min="1"
              max="100000000"
              required
            />
          </Field>
          <Field label="Medio">
            <select name="method">
              <option>Efectivo</option>
              <option>Transferencia</option>
              <option>Otro</option>
            </select>
          </Field>
          <Field label="Nota">
            <Input name="note" />
          </Field>
          <Button disabled={busy} size="sm">
            <Plus size={14} /> Registrar pago
          </Button>
        </form>
      )}
      {r.payments.length > 0 && (
        <div className="table-wrap" style={{ marginTop: 20 }}>
          <table>
            <thead>
              <tr>
                <th>Fecha</th>
                <th>Movimiento</th>
                <th>Valor</th>
                <th>Medio</th>
                <th>Nota</th>
              </tr>
            </thead>
            <tbody>
              {r.payments.map((p: any) => (
                <tr key={p.id}>
                  <td>{colombianDate(p.createdAt)}</td>
                  <td>
                    {
                      {
                        RENT: "Abono",
                        DEPOSIT: "Garantía",
                        REFUND: "Devolución de abono",
                        DEPOSIT_REFUND: "Devolución de garantía",
                      }[p.kind as string]
                    }
                  </td>
                  <td>{money(p.amount)}</td>
                  <td>{p.method}</td>
                  <td>{p.note}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}
export function CustomersView() {
  const [items, setItems] = useState<any[]>([]);
  const [search, setSearch] = useState("");
  const [error, setError] = useState("");
  const [selected, setSelected] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const { notify } = useStore();
  const load = async () => {
    try {
      setItems(await api("/admin/customers"));
    } catch (e: any) {
      setError(e.message);
    }
  };
  useEffect(() => {
    void load();
  }, []);
  return (
    <>
      <div className="admin-title">
        <div>
          <h1>Personas detrás de las historias.</h1>
          <p>Datos de contacto e historial de solicitudes y pagos.</p>
        </div>
      </div>
      <ErrorBox message={error} />
      <section className="admin-section">
        <div className="admin-section-head">
          <h2>Clientes</h2>
          <Input
            aria-label="Buscar clientes"
            placeholder="Buscar nombre o contacto…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Nombre</th>
                <th>Contacto</th>
                <th>Solicitudes</th>
                <th>Abonos netos</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {items
                .filter((c) =>
                  `${c.name} ${c.contact}`
                    .toLowerCase()
                    .includes(search.toLowerCase()),
                )
                .map((c) => (
                  <tr key={c.id}>
                    <td>{c.name}</td>
                    <td>{c.contact}</td>
                    <td>{c.rentals.length}</td>
                    <td>
                      {money(
                        c.rentals.reduce(
                          (s: number, r: any) =>
                            s +
                            r.payments.reduce(
                              (p: number, v: any) =>
                                p +
                                (v.kind === "RENT"
                                  ? v.amount
                                  : v.kind === "REFUND"
                                    ? -v.amount
                                    : 0),
                              0,
                            ),
                          0,
                        ),
                      )}
                    </td>
                    <td>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setSelected(c)}
                      >
                        Ver historial
                      </Button>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </section>
      <Dialog
        title="Contacto e historial"
        open={!!selected}
        onClose={() => setSelected(null)}
        wide
      >
        {selected && (
          <>
            <form
              className="form-stack"
              onSubmit={async (e) => {
                e.preventDefault();
                setBusy(true);
                const f = new FormData(e.currentTarget);
                try {
                  await api(
                    "/admin/customers/" + selected.id,
                    mutation("PATCH", {
                      name: f.get("name"),
                      contact: f.get("contact"),
                    }),
                  );
                  await load();
                  setSelected(null);
                  notify("Contacto actualizado.");
                } catch (e: any) {
                  setError(e.message);
                } finally {
                  setBusy(false);
                }
              }}
            >
              <div className="form-grid">
                <Field label="Nombre">
                  <Input name="name" defaultValue={selected.name} required />
                </Field>
                <Field label="Contacto">
                  <Input
                    name="contact"
                    defaultValue={selected.contact}
                    minLength={7}
                    required
                  />
                </Field>
              </div>
              <ErrorBox message={error} />
              <Button disabled={busy} style={{ alignSelf: "start" }}>
                Guardar contacto
              </Button>
            </form>
            <h3 style={{ marginTop: 25 }}>Solicitudes e historial de pagos</h3>
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Referencia</th>
                    <th>Estado</th>
                    <th>Fecha</th>
                    <th>Movimientos de pago</th>
                  </tr>
                </thead>
                <tbody>
                  {selected.rentals.map((r: any) => (
                    <tr key={r.id}>
                      <td>{r.reference}</td>
                      <td>{statusLabels[r.status]}</td>
                      <td>{colombianDate(r.startsAt)}</td>
                      <td>
                        {r.payments
                          .map((p: any) => `${p.kind}: ${money(p.amount)}`)
                          .join(" · ") || "Sin pagos"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </Dialog>
    </>
  );
}
export function CalendarView() {
  const { items, error, loading, load } = useRentals();
  const [month, setMonth] = useState(
    () =>
      new Date(
        new Intl.DateTimeFormat("en-CA", {
          timeZone: "America/Bogota",
          year: "numeric",
          month: "2-digit",
          day: "2-digit",
        }).format(new Date()) + "T12:00:00",
      ),
  );
  const [selected, setSelected] = useState<any>(null);
  const year = month.getFullYear(),
    m = month.getMonth();
  const first = new Date(year, m, 1),
    offset = (first.getDay() + 6) % 7;
  const days = new Date(year, m + 1, 0).getDate();
  const today = localBogota(new Date().toISOString()).slice(0, 10);
  return (
    <>
      <div className="admin-title">
        <div>
          <h1>El mes por delante.</h1>
          <p>
            Reservas y alquileres por día, en hora de Bogotá. Las solicitudes no
            bloquean inventario.
          </p>
        </div>
      </div>
      <ErrorBox message={error} />
      <section className="form-card">
        <div className="calendar-toolbar">
          <Button
            size="icon"
            variant="outline"
            aria-label="Mes anterior"
            onClick={() => setMonth(new Date(year, m - 1, 1))}
          >
            <ChevronLeft size={18} />
          </Button>
          <h2>
            {month.toLocaleDateString("es-CO", {
              month: "long",
              year: "numeric",
            })}
          </h2>
          <Button
            size="icon"
            variant="outline"
            aria-label="Mes siguiente"
            onClick={() => setMonth(new Date(year, m + 1, 1))}
          >
            <ChevronRight size={18} />
          </Button>
        </div>
        <div className="calendar-labels">
          {["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"].map((d) => (
            <span key={d}>{d}</span>
          ))}
        </div>
        {loading ? (
          <Loading />
        ) : (
          <div className="calendar-month">
            {Array.from(
              { length: Math.ceil((offset + days) / 7) * 7 },
              (_, i) => {
                const n = i - offset + 1;
                const date = `${year}-${String(m + 1).padStart(2, "0")}-${String(n).padStart(2, "0")}`;
                const rows =
                  n > 0 && n <= days
                    ? items.filter(
                        (r) =>
                          !["CANCELLED", "CLOSED"].includes(r.status) &&
                          localBogota(r.startsAt).slice(0, 10) <= date &&
                          localBogota(r.endsAt).slice(0, 10) >= date,
                      )
                    : [];
                return (
                  <div
                    className={
                      "calendar-day " + (date === today ? "today" : "")
                    }
                    key={i}
                  >
                    <strong>{n > 0 && n <= days ? n : ""}</strong>
                    {rows.map((r) => (
                      <button
                        key={r.id}
                        onClick={() => setSelected(r)}
                        title={`${r.reference}: ${r.customer.name} (${statusLabels[r.status]})`}
                      >
                        {r.status === "REQUESTED" ? "◌" : "●"} {r.customer.name}
                      </button>
                    ))}
                  </div>
                );
              },
            )}
          </div>
        )}
      </section>
      <Dialog
        title={selected?.reference || "Reserva"}
        open={!!selected}
        onClose={() => setSelected(null)}
        wide
      >
        {selected && (
          <RentalDetail
            rental={items.find((r) => r.id === selected.id) || selected}
            onSaved={load}
          />
        )}
      </Dialog>
    </>
  );
}
