"use client";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Archive,
  Check,
  ImagePlus,
  Plus,
  Ruler,
  Save,
  Search,
  Settings2,
  Trash2,
  X,
} from "lucide-react";
import { money, normalize, statusLabels } from "@vestuario/shared";
import { api, bogotaISO, colombianDate, hasPendingPrice, mutation } from "@/lib/api";
import {
  Badge,
  Button,
  Dialog,
  Empty,
  ErrorBox,
  Field,
  Input,
  Loading,
} from "../ui";
import { useStore } from "../providers";
export function useInventory() {
  const [items, setItems] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const load = async () => {
    try {
      const [a, b] = await Promise.all([
        api("/admin/inventory"),
        api("/admin/categories"),
      ]);
      setItems(a);
      setCategories(b);
      setError("");
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    void load();
  }, []);
  return { items, categories, loading, error, load };
}
export function InventoryView() {
  const { items, categories, loading, error, load } = useInventory();
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");
  const [showArchived, setShowArchived] = useState(false);
  const [showPieces, setShowPieces] = useState(false);
  const [showDemo, setShowDemo] = useState(false);
  const [create, setCreate] = useState(false);
  const [edit, setEdit] = useState<any>(null);
  const [actionError, setActionError] = useState("");
  const { notify } = useStore();
  const hasReal = items.some(i => i.tags.includes("coleccion-real-octubre-2026"));
  const variantMap = new Map<string, any>(items.flatMap(i => i.variants.map((v: any) => [v.id, { ...v, model: i }])));
  const unitMap = new Map<string, any>(items.flatMap(i => i.variants.flatMap((v: any) => v.units.map((u: any) => [u.id, u]))));
  const unitsFor = (item: any) => [...new Map<string, any>(item.variants.filter((v: any) => v.active).flatMap((v: any) => [
    ...v.units,
    ...(v.outfit?.components || []).flatMap((c: any) => [
      ...(variantMap.get(c.variantId)?.units || []),
      ...(c.options || []).flatMap((o: any) => variantMap.get(o.variantId)?.units || []),
      ...(c.fixedUnitId && unitMap.has(c.fixedUnitId) ? [unitMap.get(c.fixedUnitId)] : []),
    ]),
  ]).map((u: any) => [u.id, u])).values()];
  const categoryIds = new Set(category ? [category] : []);
  for (let n = 0; n < categories.length; n++) for (const c of categories)
    if (c.parentId && categoryIds.has(c.parentId)) categoryIds.add(c.id);
  const filtered = items.filter(
    (i) =>
      (showArchived || i.active) &&
      (showPieces || !i.tags.includes("pieza-de-conjunto")) &&
      (showDemo || !hasReal || !i.demo) &&
      (!category || categoryIds.has(i.categoryId)) &&
      normalize(`${i.name} ${i.category.name} ${i.variants.map((v: any) => v.color).join(" ")} ${unitsFor(i).map(u => u.code).join(" ")} ${i.variants.flatMap((v: any) => (v.outfit?.components || []).map((c: any) => c.name)).join(" ")}`)
        .includes(normalize(search)),
  ).sort((a, b) => a.category.name.localeCompare(b.category.name, "es") || a.name.localeCompare(b.name, "es"));
  return (
    <>
      <div className="admin-title">
        <div>
          <h1>Un lugar para cada traje.</h1>
          <p>Diseños, tallas y prendas físicas, siempre conectados.</p>
          {hasReal && <p className="inventory-group-count">{items.filter(i => i.active && !i.demo && !i.tags.includes("pieza-de-conjunto")).length} modelos · {items.filter(i => i.active && !i.demo).flatMap(i => i.variants.filter((v: any) => v.active).flatMap((v: any) => v.units)).filter((u: any) => u.state === "READY").length} unidades listas</p>}
        </div>
        <Button onClick={() => setCreate(true)}>
          <Plus size={16} /> Agregar traje
        </Button>
      </div>
      <ErrorBox message={error || actionError} />
      <section className="admin-section">
        <div className="admin-filter-row">
          <Input
            aria-label="Buscar inventario"
            placeholder="Buscar nombre o código de unidad…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <select
            aria-label="Filtrar categoría"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            <option value="">Todas las categorías</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
          <label className="checkbox">
            <input type="checkbox" checked={showPieces} onChange={e => setShowPieces(e.target.checked)} /> Ver piezas y accesorios
          </label>
          {hasReal && <label className="checkbox">
            <input type="checkbox" checked={showDemo} onChange={e => setShowDemo(e.target.checked)} /> Incluir demostración
          </label>}
          <label className="checkbox">
            <input
              type="checkbox"
              checked={showArchived}
              onChange={(e) => setShowArchived(e.target.checked)}
            />{" "}
            Incluir archivados
          </label>
        </div>
        {loading ? (
          <Loading />
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Diseño</th>
                  <th>Categoría</th>
                  <th>Tallas</th>
                  <th>Unidades</th>
                  <th>Desde</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((i) => (
                  <tr key={i.id}>
                    <td>
                      <div className="table-name">
                        <img src={i.images[0] || "/placeholder.svg"} alt="" />
                        <div>
                          <strong>{i.name}</strong>
                          <small>
                            {i.demo ? "Datos ficticios · Demo" : i.variants.some((v: any) => v.outfit) ? `${i.variants.find((v: any) => v.outfit).outfit.components.length} piezas vinculadas por talla` : i.slug}
                            {!i.active ? " · Archivado" : ""}
                          </small>
                        </div>
                      </div>
                    </td>
                    <td>{i.category.name}</td>
                    <td>{[...new Set(i.variants.filter((v: any) => v.active).map((v: any) => v.size))].join(" · ")}<small className="inventory-group-count">{new Set(i.variants.filter((v: any) => v.active).map((v: any) => v.color)).size} colores</small></td>
                    <td>
                      {unitsFor(i).filter((u: any) => u.state === "READY").length} piezas listas{" "}
                      {i.variants.some((v: any) => v.outfit) && (
                        <Badge>Conjunto</Badge>
                      )}
                    </td>
                    <td>
                      {hasPendingPrice(Math.min(...i.variants.map((v: any) => v.price)), i.tags) ? "Precio por definir" : money(Math.min(...i.variants.map((v: any) => v.price)))}
                    </td>
                    <td>
                      <div className="table-actions">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setEdit(i)}
                        >
                          <Settings2 size={12} /> Gestionar
                        </Button>
                        {i.active && (
                          <Button
                            variant="ghost"
                            size="sm"
                            aria-label={`Archivar ${i.name}`}
                            onClick={async () => {
                              if (
                                !window.confirm(
                                  `¿Archivar ${i.name}? Se conservará todo su historial.`,
                                )
                              )
                                return;
                              try {
                                await api("/admin/costumes/" + i.id, {
                                  method: "DELETE",
                                });
                                notify("Diseño archivado.");
                                await load();
                              } catch (e: any) {
                                setActionError(e.message);
                              }
                            }}
                          >
                            <Archive size={14} />
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {!filtered.length && (
              <p className="admin-empty">
                No hay prendas que coincidan con estos filtros.
              </p>
            )}
          </div>
        )}
      </section>
      <Dialog
        title="Agregar un traje"
        open={create}
        onClose={() => setCreate(false)}
      >
        <CreateCostume
          categories={categories}
          onSaved={async () => {
            setCreate(false);
            await load();
            notify("Diseño y unidades físicas registrados.");
          }}
        />
      </Dialog>
      <Dialog
        title={edit?.name || "Gestionar diseño"}
        open={!!edit}
        onClose={() => setEdit(null)}
        wide
      >
        {edit && (
          <EditCostume
            key={edit.id}
            item={items.find((i) => i.id === edit.id) || edit}
            categories={categories}
            inventory={items}
            onSaved={load}
          />
        )}
      </Dialog>
    </>
  );
}
const newSchema = z.object({
  name: z.string().trim().min(2, "Escribe un nombre."),
  categoryId: z.string().min(1, "Selecciona una categoría."),
  size: z.string().min(1),
  color: z.string().min(1),
  quantity: z.coerce.number().int().min(0).max(100),
  price: z.coerce.number().int().min(0).max(10000000),
  location: z.string().max(200),
  description: z.string().max(3000),
});
function CreateCostume({
  categories,
  onSaved,
  initialQuantity = 1,
}: {
  categories: any[];
  onSaved: () => void;
  initialQuantity?: number;
}) {
  const [image, setImage] = useState("");
  const [error, setError] = useState("");
  const [uploading, setUploading] = useState(false);
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<z.input<typeof newSchema>, unknown, z.output<typeof newSchema>>({
    resolver: zodResolver(newSchema),
    defaultValues: {
      name: "",
      categoryId: "",
      size: "",
      color: "",
      quantity: initialQuantity,
      price: 0,
      location: "",
      description: "",
    },
  });
  return (
    <form
      onSubmit={handleSubmit(async (data) => {
        setError("");
        try {
          await api(
            "/admin/costumes",
            mutation("POST", { ...data, images: image ? [image] : [] }),
          );
          onSaved();
        } catch (e: any) {
          setError(e.message);
        }
      })}
    >
      <label className="upload-control">
        {image ? (
          <img src={image} alt="Fotografía seleccionada" />
        ) : (
          <ImagePlus size={28} style={{ margin: "0 auto 9px" }} />
        )}
        1. Sube una fotografía · JPG, PNG o WebP · máximo 5 MB
        <input
          type="file"
          accept="image/jpeg,image/png,image/webp"
          disabled={uploading}
          onChange={async (e) => {
            const file = e.target.files?.[0];
            if (!file) return;
            setUploading(true);
            setError("");
            try {
              const form = new FormData();
              form.append("file", file);
              const r = await api("/admin/images", {
                method: "POST",
                body: form,
              });
              setImage(r.url);
            } catch (e: any) {
              setError(e.message);
            } finally {
              setUploading(false);
            }
          }}
        />
      </label>
      <div className="form-stack" style={{ marginTop: 20 }}>
        <Field label="2. Nombre del traje">
          <Input {...register("name")} />
          {errors.name && (
            <small className="field-error">{errors.name.message}</small>
          )}
        </Field>
        <Field label="3. Categoría">
          <select {...register("categoryId")}>
            <option value="">Elige una categoría</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
          {errors.categoryId && (
            <small className="field-error">{errors.categoryId.message}</small>
          )}
        </Field>
        <div className="form-grid">
          <Field label="4. Talla comercial">
            <Input {...register("size")} />
          </Field>
          <Field label="Color">
            <Input {...register("color")} />
          </Field>
        </div>
        <div className="form-grid">
          <Field
            label="5. Unidades físicas"
            hint="Cada unidad tendrá un código único. Usa 0 para un diseño que se convertirá en conjunto."
          >
            <Input type="number" min="0" max="100" {...register("quantity")} />
          </Field>
          <Field label="6. Precio de alquiler (COP)">
            <Input type="number" min="0" {...register("price")} />
          </Field>
        </div>
        <details>
          <summary style={{ fontSize: 12, cursor: "pointer" }}>
            Opciones adicionales
          </summary>
          <div className="form-stack" style={{ marginTop: 15 }}>
            <Field label="Ubicación">
              <Input {...register("location")} />
            </Field>
            <Field label="Descripción">
              <textarea rows={3} {...register("description")} />
            </Field>
          </div>
        </details>
      </div>
      <ErrorBox message={error} />
      {Object.entries(errors)
        .filter(([k]) => !["name", "categoryId"].includes(k))
        .map(([k, e]) => (
          <p className="field-error" key={k}>
            {k}: {e?.message as string}
          </p>
        ))}
      <Button
        type="submit"
        disabled={isSubmitting || uploading}
        style={{ width: "100%", marginTop: 22 }}
      >
        <Save size={16} />
        {isSubmitting
          ? "Guardando…"
          : uploading
            ? "Subiendo fotografía…"
            : "Guardar traje"}
      </Button>
    </form>
  );
}
function EditCostume({
  item,
  categories,
  inventory,
  onSaved,
}: {
  item: any;
  categories: any[];
  inventory: any[];
  onSaved: () => Promise<void>;
}) {
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [unit, setUnit] = useState<any>(null);
  const [variantSize, setVariantSize] = useState(item.variants.filter((v: any) => v.active).length > 8 ? item.variants.find((v: any) => v.active)?.size || "" : "");
  const [variantColor, setVariantColor] = useState("");
  const [showInactiveVariants, setShowInactiveVariants] = useState(false);
  const visibleVariants = item.variants.filter((v: any) => showInactiveVariants || v.active);
  const { notify } = useStore();
  const run = async (
    fn: () => Promise<any>,
    message = "Cambios guardados.",
  ) => {
    setBusy(true);
    setError("");
    try {
      await fn();
      await onSaved();
      notify(message);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <>
      <ErrorBox message={error} />
      <form
        className="form-stack"
        onSubmit={(e) => {
          e.preventDefault();
          const d = new FormData(e.currentTarget);
          void run(() =>
            api(
              "/admin/costumes/" + item.id,
              mutation("PATCH", {
                name: d.get("name"),
                description: d.get("description"),
                danceStyle: String(d.get("danceStyle") || "").trim() || null,
                bundleSize: Number(d.get("bundleSize")),
                includedAccessories: String(d.get("includedAccessories") || "").split("\n").map(t => t.trim()).filter(Boolean),
                categoryId: d.get("categoryId"),
                searchTerms: d.get("searchTerms"),
                tags: String(d.get("tags") || "")
                  .split(",")
                  .map((t) => t.trim())
                  .filter(Boolean),
                requiredMetrics: [
                  "height",
                  "chest",
                  "waist",
                  "hip",
                  "length",
                ].filter((m) => d.get(m) === "on"),
                featured: d.get("featured") === "on",
                active: d.get("active") === "on",
              }),
            ),
          );
        }}
      >
        <div className="form-grid">
          <Field label="Nombre">
            <Input name="name" defaultValue={item.name} required />
          </Field>
          <Field label="Categoría">
            <select name="categoryId" defaultValue={item.categoryId}>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </Field>
        </div>
        <Field label="Descripción">
          <textarea
            name="description"
            defaultValue={item.description}
            rows={3}
          />
        </Field>
        <Field label="Danza o estilo (opcional)">
          <Input name="danceStyle" defaultValue={item.danceStyle || ""} placeholder="Por ejemplo: joropo, tango…" maxLength={100} />
        </Field>
        <Field label="Formatos de alquiler">
          <select name="bundleSize" defaultValue={item.bundleSize || 1}><option value={1}>Por unidades</option><option value={6}>Por unidades o juego de 6 (3 S + 3 M, o 6 Niño)</option></select>
        </Field>
        <Field label="Accesorios incluidos en el alquiler (uno por línea)">
          <textarea name="includedAccessories" defaultValue={(item.includedAccessories || []).join("\n")} rows={3} />
        </Field>
        <div className="form-grid">
          <Field label="Etiquetas (separadas por comas)">
            <Input name="tags" defaultValue={item.tags.join(", ")} />
          </Field>
          <Field label="Términos de búsqueda">
            <Input name="searchTerms" defaultValue={item.searchTerms} />
          </Field>
        </div>
        <div>
          <p style={{ fontSize: 11, marginBottom: 8 }}>
            Medidas necesarias para verificar este diseño
          </p>
          <div style={{ display: "flex", gap: 18, flexWrap: "wrap" }}>
            {[
              ["height", "Estatura"],
              ["chest", "Pecho"],
              ["waist", "Cintura"],
              ["hip", "Cadera"],
              ["length", "Largo"],
            ].map(([key, label]) => (
              <label className="checkbox" key={key}>
                <input
                  type="checkbox"
                  name={key}
                  defaultChecked={item.requiredMetrics.includes(key)}
                />
                {label}
              </label>
            ))}
          </div>
        </div>
        <div style={{ display: "flex", gap: 20 }}>
          <label className="checkbox">
            <input
              type="checkbox"
              name="featured"
              defaultChecked={item.featured}
            />{" "}
            Destacado
          </label>
          <label className="checkbox">
            <input type="checkbox" name="active" defaultChecked={item.active} />{" "}
            Visible en catálogo
          </label>
        </div>
        <Button disabled={busy} style={{ alignSelf: "start" }}>
          <Save size={15} /> Guardar diseño
        </Button>
      </form>
      <details style={{ marginTop: 20 }}>
        <summary style={{ fontSize: 12, cursor: "pointer" }}>
          Fotografías del diseño ({item.images.length})
        </summary>
        <div className="thumbnails">
          {item.images.map((src: string) => (
            <div key={src}>
              <img
                style={{ height: 90, width: 80, objectFit: "cover" }}
                src={src}
                alt="Fotografía del diseño"
              />
              <Button
                variant="ghost"
                size="sm"
                disabled={busy}
                onClick={() => {
                  if (window.confirm("¿Quitar esta foto del diseño?"))
                    void run(() =>
                      api(
                        "/admin/costumes/" + item.id,
                        mutation("PATCH", {
                          images: item.images.filter((s: string) => s !== src),
                        }),
                      ),
                    );
                }}
              >
                Quitar
              </Button>
            </div>
          ))}
        </div>
        <input
          type="file"
          accept="image/jpeg,image/png,image/webp"
          disabled={busy || item.images.length >= 10}
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (!f) return;
            void run(async () => {
              const form = new FormData();
              form.append("file", f);
              const r = await api("/admin/images", {
                method: "POST",
                body: form,
              });
              return api(
                "/admin/costumes/" + item.id,
                mutation("PATCH", { images: [...item.images, r.url] }),
              );
            });
          }}
        />
      </details>
      {item.bundleSize === 6 && <section className="admin-bundle-photo">
        <h3>Fotografía del juego completo x6</h3>
        <p>Esta vista se muestra al elegir el juego y también puede ampliarse desde la ficha.</p>
        {item.bundleImage && <><img src={item.bundleImage} alt="Vista del juego de seis trajes" /><Button variant="ghost" disabled={busy} onClick={() => void run(() => api(`/admin/costumes/${item.id}`, mutation("PATCH", { bundleImage: null })))}>Quitar vista del juego</Button></>}
        <input aria-label="Subir fotografía del juego x6" type="file" accept="image/jpeg,image/png,image/webp" disabled={busy} onChange={e => {
          const file = e.target.files?.[0]; if (!file) return;
          void run(async () => { const form = new FormData(); form.append("file", file); const image = await api("/admin/images", { method: "POST", body: form }); return api(`/admin/costumes/${item.id}`, mutation("PATCH", { bundleImage: image.url })); });
        }} />
      </section>}
      <h3 style={{ marginTop: 30 }}>Tallas, colores y unidades</h3>
      <div className="inline-form" style={{ marginTop: 16 }}>
        <Field label="Ver talla"><select value={variantSize} onChange={e => setVariantSize(e.target.value)}><option value="">Todas las tallas</option>{[...new Set<string>(visibleVariants.map((v: any) => v.size))].map(size => <option key={size}>{size}</option>)}</select></Field>
        <Field label="Ver color"><select value={variantColor} onChange={e => setVariantColor(e.target.value)}><option value="">Todos los colores</option>{[...new Set<string>(visibleVariants.map((v: any) => v.color))].map(color => <option key={color}>{color}</option>)}</select></Field>
        <label className="checkbox"><input type="checkbox" checked={showInactiveVariants} onChange={e => setShowInactiveVariants(e.target.checked)} /> Incluir variantes archivadas</label>
      </div>
      {item.variants.length > 1 && <form className="inline-form" onSubmit={e => {
        e.preventDefault();
        const f = new FormData(e.currentTarget);
        void run(() => api(`/admin/costumes/${item.id}/prices`, mutation("PATCH", { price: Number(f.get("allPrice")) })), "Precio aplicado a todas las tallas activas.");
      }}>
        <Field label="Precio de alquiler para todas las tallas · COP"><Input name="allPrice" type="number" min="1" max="10000000" required placeholder="Por definir" /></Field>
        <Button variant="outline" disabled={busy}>Aplicar a todas las tallas</Button>
      </form>}
      {visibleVariants.filter((v: any) => (!variantSize || v.size === variantSize) && (!variantColor || v.color === variantColor)).map((v: any) => (
        <div className="unit-card" key={v.id}>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              const f = new FormData(e.currentTarget);
              void run(() =>
                api(
                  "/admin/variants/" + v.id,
                  mutation("PATCH", {
                    size: f.get("size"),
                    color: f.get("color"),
                    price: Number(f.get("price")),
                    elastic: f.get("elastic") === "on",
                    active: f.get("active") === "on",
                    commercialAgeMin: f.get("ageMin")
                      ? Number(f.get("ageMin"))
                      : null,
                    commercialAgeMax: f.get("ageMax")
                      ? Number(f.get("ageMax"))
                      : null,
                  }),
                ),
              );
            }}
          >
            <div className="form-grid">
              <Field label="Talla">
                <Input name="size" defaultValue={v.size} required />
              </Field>
              <Field label="Color">
                <Input name="color" defaultValue={v.color} required />
              </Field>
              <Field label="Precio COP" hint={hasPendingPrice(v.price, item.tags) ? "Pendiente: registra el precio de alquiler para habilitar solicitudes." : undefined}>
                <Input
                  name="price"
                  type="number"
                  min="0"
                  defaultValue={v.price}
                  required
                />
              </Field>
              <div className="form-grid">
                <Field label="Edad comercial mín.">
                  <Input
                    name="ageMin"
                    type="number"
                    min="0"
                    defaultValue={v.commercialAgeMin ?? ""}
                  />
                </Field>
                <Field label="Edad comercial máx.">
                  <Input
                    name="ageMax"
                    type="number"
                    min="0"
                    defaultValue={v.commercialAgeMax ?? ""}
                  />
                </Field>
              </div>
            </div>
            <div className="inline-form">
              <label className="checkbox">
                <input
                  type="checkbox"
                  name="elastic"
                  defaultChecked={v.elastic}
                />{" "}
                Ajustable o elástica (usa rangos corporales medidos)
              </label>
              <label className="checkbox">
                <input
                  type="checkbox"
                  name="active"
                  defaultChecked={v.active}
                />{" "}
                Variante activa
              </label>
              <Button variant="outline" size="sm" disabled={busy}>
                Guardar variante
              </Button>
            </div>
          </form>
          <div className="unit-list" style={{ marginTop: 18 }}>
            {v.units.map((u: any) => (
              <div
                className="unit-card-head"
                style={{ padding: "8px 0", borderTop: "1px solid #eef0e8" }}
                key={u.id}
              >
                <div>
                  <strong>{u.code}</strong>
                  <p>
                    {u.location || "Sin ubicación"} · {u.measurements.length}{" "}
                    medidas
                  </p>
                </div>
                <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                  <Badge tone={u.state === "READY" ? "default" : "warning"}>
                    {statusLabels[u.state]}
                  </Badge>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setUnit(u)}
                  >
                    Gestionar unidad
                  </Button>
                </div>
              </div>
            ))}
          </div>
          {v.outfit ? (
            <details className="info-box">
              <summary>Ver {v.outfit.components.length} piezas del conjunto · talla {v.size}</summary>
              {v.outfit.components.map((c: any) => {
                const model = inventory.find(i => i.variants.some((x: any) => x.id === c.variantId));
                const component = model?.variants.find((x: any) => x.id === c.variantId);
                const units = component?.units || inventory.flatMap(i => i.variants.flatMap((x: any) => x.units.filter((u: any) => u.id === c.fixedUnitId)));
                return <div className="included-piece" key={c.id}>
                  {model?.images[0] && <img src={model.images[0]} alt={c.name} loading="lazy" />}
                  <div><strong>{c.quantity} × {c.name}</strong><p>{c.required ? "Incluido" : "Opcional"}{component ? ` · Talla ${component.size}` : ""}{c.allowSubstitution ? " · con alternativas compatibles" : ""}</p>
                    {units.map((u: any) => <div key={u.id} className="inline-form"><small>{u.code} · {statusLabels[u.state]}</small><Button type="button" variant="ghost" size="sm" onClick={() => setUnit(u)}>Gestionar pieza</Button></div>)}
                  </div>
                </div>;
              })}
            </details>
          ) : (
            <form
              className="inline-form"
              onSubmit={(e) => {
                e.preventDefault();
                const f = new FormData(e.currentTarget);
                void run(
                  () =>
                    api(
                      `/admin/variants/${v.id}/units`,
                      mutation("POST", {
                        quantity: Number(f.get("quantity")),
                        location: String(f.get("location") || ""),
                      }),
                    ),
                  "Unidades físicas creadas.",
                );
              }}
            >
              <Field label="Nuevas unidades">
                <Input
                  name="quantity"
                  type="number"
                  min="1"
                  max="100"
                  defaultValue="1"
                  required
                />
              </Field>
              <Field label="Ubicación">
                <Input name="location" />
              </Field>
              <Button variant="outline" size="sm" disabled={busy}>
                <Plus size={14} /> Registrar unidades
              </Button>
            </form>
          )}
        </div>
      ))}
      <details style={{ marginTop: 20 }}>
        <summary style={{ cursor: "pointer", fontSize: 12 }}>
          Agregar otra talla o color
        </summary>
        <form
          className="inline-form"
          onSubmit={(e) => {
            e.preventDefault();
            const f = new FormData(e.currentTarget);
            void run(() =>
              api(
                `/admin/costumes/${item.id}/variants`,
                mutation("POST", {
                  size: f.get("size"),
                  color: f.get("color"),
                  price: Number(f.get("price")),
                }),
              ),
            );
          }}
        >
          <Field label="Talla">
            <Input name="size" required />
          </Field>
          <Field label="Color">
            <Input name="color" required />
          </Field>
          <Field label="Precio COP">
            <Input name="price" type="number" min="0" required />
          </Field>
          <Button disabled={busy} size="sm">
            <Plus size={14} /> Crear variante
          </Button>
        </form>
      </details>
      <Dialog
        title={unit?.code || "Unidad física"}
        open={!!unit}
        onClose={() => setUnit(null)}
        wide
      >
        {unit && (
          <UnitEditor
            unit={unit}
            onSaved={async () => {
              setUnit(null);
              await onSaved();
            }}
          />
        )}
      </Dialog>
    </>
  );
}
function UnitEditor({
  unit,
  onSaved,
}: {
  unit: any;
  onSaved: () => Promise<void>;
}) {
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const { notify } = useStore();
  const [images, setImages] = useState<string[]>(unit.images);
  const [uploading, setUploading] = useState(false);
  return (
    <form
      onSubmit={async (e) => {
        e.preventDefault();
        const f = new FormData(e.currentTarget);
        setBusy(true);
        setError("");
        const measurements = ["height", "chest", "waist", "hip", "length"]
          .map((metric) => ({
            metric,
            garmentCm: f.get(metric + "-garment")
              ? Number(f.get(metric + "-garment"))
              : null,
            bodyMinCm: f.get(metric + "-min")
              ? Number(f.get(metric + "-min"))
              : null,
            bodyMaxCm: f.get(metric + "-max")
              ? Number(f.get(metric + "-max"))
              : null,
            easeCm:
              f.get(metric + "-ease") !== ""
                ? Number(f.get(metric + "-ease"))
                : null,
          }))
          .filter(
            (m) =>
              m.garmentCm !== null ||
              m.bodyMinCm !== null ||
              m.bodyMaxCm !== null ||
              m.easeCm !== null,
          );
        try {
          await api(
            "/admin/units/" + unit.id,
            mutation("PATCH", {
              code: f.get("code"),
              state: f.get("state"),
              location: f.get("location"),
              notes: f.get("notes"),
              acquiredAt: f.get("acquiredAt")
                ? `${f.get("acquiredAt")}T12:00:00-05:00`
                : null,
              acquisitionCost: f.get("acquisitionCost")
                ? Number(f.get("acquisitionCost"))
                : null,
              images,
              measurements,
            }),
          );
          await onSaved();
          notify("Unidad actualizada.");
        } catch (e: any) {
          setError(e.message);
        } finally {
          setBusy(false);
        }
      }}
    >
      <div className="form-grid">
        <Field label="Código único">
          <Input name="code" defaultValue={unit.code} required />
        </Field>
        <Field label="Estado físico">
          <select name="state" defaultValue={unit.state}>
            {["READY", "CLEANING", "REPAIR", "RETIRED"].map((s) => (
              <option key={s} value={s}>
                {statusLabels[s]}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Ubicación">
          <Input name="location" defaultValue={unit.location} />
        </Field>
        <Field label="Costo de adquisición COP (opcional)">
          <Input
            name="acquisitionCost"
            type="number"
            min="0"
            defaultValue={unit.acquisitionCost ?? ""}
          />
        </Field>
        <Field label="Fecha de adquisición (opcional)">
          <Input
            name="acquiredAt"
            type="date"
            defaultValue={unit.acquiredAt?.slice(0, 10) || ""}
          />
        </Field>
      </div>
      <Field label="Observaciones">
        <textarea name="notes" rows={2} defaultValue={unit.notes} />
      </Field>
      <h3>Medidas reales en centímetros</h3>
      <p className="fine-print">
        Dimensiones de la prenda y rangos corporales son datos distintos. La
        holgura la define el negocio para este diseño; no se calcula
        automáticamente.
      </p>
      <div className="measure-row measure-labels">
        <span>Medida</span>
        <span>Prenda</span>
        <span>Cuerpo mín.</span>
        <span>Cuerpo máx.</span>
        <span>Holgura mín.</span>
      </div>
      {[
        ["height", "Estatura"],
        ["chest", "Pecho"],
        ["waist", "Cintura"],
        ["hip", "Cadera"],
        ["length", "Largo"],
      ].map(([key, label]) => {
        const m = unit.measurements.find((m: any) => m.metric === key) || {};
        return (
          <div className="measure-row" key={key}>
            <span>{label}</span>
            {[
              ["garment", "garmentCm"],
              ["min", "bodyMinCm"],
              ["max", "bodyMaxCm"],
              ["ease", "easeCm"],
            ].map(([suffix, prop]) => (
              <Input
                key={suffix}
                name={key + "-" + suffix}
                aria-label={`${label}: ${suffix}`}
                type="number"
                min={suffix === "ease" ? 0 : 0.1}
                step="0.1"
                max="500"
                defaultValue={m[prop] ?? ""}
              />
            ))}
          </div>
        );
      })}
      <details style={{ marginTop: 20 }}>
        <summary style={{ cursor: "pointer", fontSize: 12 }}>
          Fotografías de esta unidad
        </summary>
        <div className="thumbnails">
          {images.map((src) => (
            <div key={src}>
              <img
                style={{ height: 70, width: 60, objectFit: "cover" }}
                src={src}
                alt="Fotografía de la unidad"
              />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => setImages(images.filter((i) => i !== src))}
              >
                Quitar
              </Button>
            </div>
          ))}
        </div>
        <input
          type="file"
          accept="image/jpeg,image/png,image/webp"
          disabled={uploading || images.length >= 10}
          onChange={async (e) => {
            const file = e.target.files?.[0];
            if (!file) return;
            setUploading(true);
            try {
              const f = new FormData();
              f.append("file", file);
              const r = await api("/admin/images", { method: "POST", body: f });
              setImages([...images, r.url]);
            } catch (e: any) {
              setError(e.message);
            } finally {
              setUploading(false);
            }
          }}
        />
      </details>
      <details style={{ marginTop: 18 }}>
        <summary style={{ cursor: "pointer", fontSize: 12 }}>
          Historial de movimientos
        </summary>
        {unit.movements.map((m: any) => (
          <p style={{ fontSize: 11, marginTop: 7 }} key={m.id}>
            {colombianDate(m.createdAt)} · {m.type} · {m.detail}
          </p>
        ))}
      </details>
      <Maintenance unit={unit} onSaved={onSaved} />
      <ErrorBox message={error} />
      <Button disabled={busy || uploading} style={{ marginTop: 22 }}>
        <Save size={15} /> Guardar unidad y medidas
      </Button>
    </form>
  );
}
function Maintenance({
  unit,
  onSaved,
}: {
  unit: any;
  onSaved: () => Promise<void>;
}) {
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const [kind, setKind] = useState("ADMIN");
  const [reason, setReason] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const { notify } = useStore();
  return (
    <details style={{ marginTop: 20 }}>
      <summary style={{ cursor: "pointer", fontSize: 12 }}>
        Indisponibilidades y reservas de esta unidad
      </summary>
      {unit.blocks?.map((block: any) => (
        <div className="unit-card" key={block.id}>
          <p>
            {block.kind} · {colombianDate(block.startsAt)} →{" "}
            {block.endsAt ? colombianDate(block.endsAt) : "Sin fecha de cierre"}
          </p>
          <p>{block.reason}</p>
          {!block.rentalId && (
            <Button
              type="button"
              variant="outline"
              size="sm"
              disabled={busy}
              onClick={async () => {
                if (!window.confirm("¿Liberar esta indisponibilidad temporal?"))
                  return;
                setBusy(true);
                try {
                  await api("/admin/blocks/" + block.id, { method: "DELETE" });
                  await onSaved();
                  notify(
                    "Indisponibilidad liberada. Revisa también el estado físico de la unidad.",
                  );
                } catch (e: any) {
                  setError(e.message);
                } finally {
                  setBusy(false);
                }
              }}
            >
              Liberar bloqueo
            </Button>
          )}
        </div>
      ))}
      <div className="form-grid" style={{ marginTop: 15 }}>
        <Field label="Inicio · Bogotá">
          <Input
            type="datetime-local"
            value={start}
            onChange={(e) => setStart(e.target.value)}
          />
        </Field>
        <Field label="Fin · Bogotá">
          <Input
            type="datetime-local"
            value={end}
            onChange={(e) => setEnd(e.target.value)}
          />
        </Field>
        <Field label="Motivo">
          <select value={kind} onChange={(e) => setKind(e.target.value)}>
            <option value="ADMIN">Administrativo</option>
            <option value="CLEANING">Limpieza programada</option>
            <option value="REPAIR">Reparación programada</option>
          </select>
        </Field>
        <Field label="Detalle">
          <Input value={reason} onChange={(e) => setReason(e.target.value)} />
        </Field>
      </div>
      <ErrorBox message={error} />
      <Button
        type="button"
        variant="outline"
        size="sm"
        disabled={busy || !start || !end || !reason}
        style={{ marginTop: 15 }}
        onClick={async () => {
          setBusy(true);
          setError("");
          try {
            await api(
              "/admin/units/" + unit.id + "/blocks",
              mutation("POST", {
                startsAt: bogotaISO(start),
                endsAt: bogotaISO(end),
                kind,
                reason,
              }),
            );
            await onSaved();
            notify("Indisponibilidad registrada.");
          } catch (e: any) {
            setError(e.message);
          } finally {
            setBusy(false);
          }
        }}
      >
        Registrar indisponibilidad temporal
      </Button>
      <p className="fine-print" style={{ marginTop: 10 }}>
        Esta acción guarda el bloqueo y cierra la edición. Para una limpieza sin
        fecha de fin, usa el estado físico de la unidad.
      </p>
    </details>
  );
}
export function CategoriesView() {
  const { categories, loading, error, load } = useInventory();
  const [edit, setEdit] = useState<any>(null);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const { notify } = useStore();
  return (
    <>
      <div className="admin-title">
        <div>
          <h1>Cada historia en su lugar.</h1>
          <p>Organiza el catálogo con categorías y subcategorías.</p>
        </div>
        <Button onClick={() => setEdit({ name: "", parentId: "" })}>
          <Plus size={16} /> Crear categoría
        </Button>
      </div>
      <ErrorBox message={error || err} />
      <section className="admin-section">
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Nombre</th>
                <th>Categoría superior</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {categories.map((c) => (
                <tr key={c.id}>
                  <td>{c.name}</td>
                  <td>
                    {categories.find((p) => p.id === c.parentId)?.name ||
                      "Principal"}
                  </td>
                  <td>
                    <div className="table-actions">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setEdit(c)}
                      >
                        Editar
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={async () => {
                          if (
                            !window.confirm(
                              "¿Eliminar la categoría? Solo es posible si no contiene diseños ni subcategorías.",
                            )
                          )
                            return;
                          try {
                            await api("/admin/categories/" + c.id, {
                              method: "DELETE",
                            });
                            await load();
                            notify("Categoría eliminada.");
                          } catch (e: any) {
                            setErr(e.message);
                          }
                        }}
                      >
                        <Trash2 size={14} />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {loading && <Loading />}
        </div>
      </section>
      <Dialog
        title={edit?.id ? "Editar categoría" : "Nueva categoría"}
        open={!!edit}
        onClose={() => setEdit(null)}
      >
        {edit && (
          <form
            className="form-stack"
            onSubmit={async (e) => {
              e.preventDefault();
              const f = new FormData(e.currentTarget);
              setBusy(true);
              setErr("");
              try {
                await api(
                  "/admin/categories" + (edit.id ? "/" + edit.id : ""),
                  mutation(edit.id ? "PATCH" : "POST", {
                    name: f.get("name"),
                    parentId: f.get("parentId") || null,
                  }),
                );
                await load();
                setEdit(null);
                notify("Categoría guardada.");
              } catch (e: any) {
                setErr(e.message);
              } finally {
                setBusy(false);
              }
            }}
          >
            <Field label="Nombre">
              <Input name="name" defaultValue={edit.name} required />
            </Field>
            <Field label="Categoría superior">
              <select name="parentId" defaultValue={edit.parentId || ""}>
                <option value="">Ninguna · categoría principal</option>
                {categories
                  .filter((c) => c.id !== edit.id)
                  .map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
              </select>
            </Field>
            <ErrorBox message={err} />
            <Button disabled={busy}>Guardar categoría</Button>
          </form>
        )}
      </Dialog>
    </>
  );
}
export function OutfitsView() {
  const { items, categories, loading, error, load } = useInventory();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [newModel, setNewModel] = useState(false);
  const [mode, setMode] = useState("FLEXIBLE");
  const [components, setComponents] = useState<any[]>([
    {
      name: "",
      required: true,
      quantity: 1,
      variantId: "",
      fixedUnitId: "",
      allowSubstitution: false,
      alternativeVariantIds: [],
    },
  ]);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [modelFilter, setModelFilter] = useState("");
  const [sizeFilter, setSizeFilter] = useState("");
  const [colorFilter, setColorFilter] = useState("");
  const { notify } = useStore();
  const variants = items.flatMap((i) =>
    i.variants.map((v: any) => ({
      ...v,
      label: `${i.name} · ${v.size} · ${v.color}`,
    })),
  );
  const outfitModels = items.filter(i => i.active && i.variants.some((v: any) => v.active && v.outfit)).sort((a, b) => Number(a.demo) - Number(b.demo) || a.name.localeCompare(b.name, "es"));
  const selectedModelId = modelFilter || outfitModels[0]?.id;
  const selectedModel = outfitModels.find(i => i.id === selectedModelId);
  const outfits = variants.filter((v) => v.active && v.outfit && v.costumeId === selectedModelId && (!sizeFilter || v.size === sizeFilter) && (!colorFilter || v.color === colorFilter));
  return (
    <>
      <div className="admin-title">
        <div>
          <h1>Juntos, cuentan más.</h1>
          <p>
            Conjuntos fijos y flexibles con componentes físicos compartidos.
          </p>
        </div>
        <div className="admin-title-actions">
          <Button variant="outline" onClick={() => setNewModel(true)}>
            <Plus size={15} /> Crear diseño base
          </Button>
          <Button
            onClick={() => {
              setEditing(null);
              setErr("");
              setOpen(true);
            }}
          >
            <Plus size={15} /> Armar conjunto
          </Button>
        </div>
      </div>
      <p className="info-box">
        Para un conjunto nuevo, crea primero su diseño base con 0 unidades.
        Después selecciona la variante y las piezas que lo componen. Los
        componentes opcionales se acuerdan por separado y no se asignan
        automáticamente.
      </p>
      <ErrorBox message={error || err} />
      <div className="admin-filter-row">
        <Field label="Conjunto"><select value={selectedModelId || ""} onChange={e => { setModelFilter(e.target.value); setSizeFilter(""); setColorFilter(""); }}>{outfitModels.map(i => <option key={i.id} value={i.id}>{i.name}{i.demo ? " · Demo" : ""}</option>)}</select></Field>
        <Field label="Talla del conjunto"><select value={sizeFilter} onChange={e => setSizeFilter(e.target.value)}><option value="">Todas las tallas</option>{[...new Set<string>((selectedModel?.variants || []).map((v: any) => v.size))].map(size => <option key={size}>{size}</option>)}</select></Field>
        <Field label="Color del conjunto"><select value={colorFilter} onChange={e => setColorFilter(e.target.value)}><option value="">Todos los colores</option>{[...new Set<string>((selectedModel?.variants || []).map((v: any) => v.color))].map(color => <option key={color}>{color}</option>)}</select></Field>
      </div>
      {loading ? (
        <Loading />
      ) : (
        <section className="admin-section">
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Conjunto</th>
                  <th>Modalidad</th>
                  <th>Piezas</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                {outfits.map((v) => (
                  <tr key={v.id}>
                    <td>{v.label}</td>
                    <td>
                      <Badge>
                        {v.outfit.mode === "FIXED" ? "Fijo" : "Flexible"}
                      </Badge>
                    </td>
                    <td>
                      {v.outfit.components
                        .map(
                          (c: any) =>
                            `${c.quantity} × ${c.name}${c.required ? "" : " (opcional)"}`,
                        )
                        .join(", ")}
                    </td>
                    <td>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setEditing(v);
                          setMode(v.outfit.mode);
                          setComponents(
                            v.outfit.components.map((c: any) => ({
                              ...c,
                              variantId: c.variantId || "",
                              fixedUnitId: c.fixedUnitId || "",
                              alternativeVariantIds: c.options.map(
                                (o: any) => o.variantId,
                              ),
                            })),
                          );
                          setErr("");
                          setOpen(true);
                        }}
                      >
                        Editar
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={async () => {
                          if (
                            !window.confirm(
                              "¿Desarmar este conjunto? Si tiene historial, deberás archivar su diseño.",
                            )
                          )
                            return;
                          try {
                            await api("/admin/outfits/" + v.outfit.id, {
                              method: "DELETE",
                            });
                            await load();
                            notify("Conjunto desarmado.");
                          } catch (e: any) {
                            setErr(e.message);
                          }
                        }}
                      >
                        <Trash2 size={14} />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {!outfits.length && (
              <p className="admin-empty">Todavía no has creado conjuntos.</p>
            )}
          </div>
        </section>
      )}
      <Dialog
        title="Crear diseño base del conjunto"
        open={newModel}
        onClose={() => setNewModel(false)}
      >
        <CreateCostume
          categories={categories}
          initialQuantity={0}
          onSaved={async () => {
            setNewModel(false);
            await load();
            notify(
              "Diseño creado. Puedes armar el conjunto usando una variante sin unidades.",
            );
          }}
        />
      </Dialog>
      <Dialog
        title={editing ? "Editar conjunto" : "Armar un conjunto"}
        open={open}
        onClose={() => setOpen(false)}
        wide
      >
        <form
          key={editing?.id || "new"}
          className="form-stack"
          onSubmit={async (e) => {
            e.preventDefault();
            const f = new FormData(e.currentTarget);
            setBusy(true);
            setErr("");
            try {
              await api(
                "/admin/outfits" + (editing ? "/" + editing.outfit.id : ""),
                mutation(editing ? "PATCH" : "POST", {
                  variantId: editing?.id || f.get("variantId"),
                  mode,
                  components: components.map((c) => ({
                    name: c.name,
                    required: c.required,
                    quantity: Number(c.quantity),
                    ...(mode === "FIXED"
                      ? { fixedUnitId: c.fixedUnitId }
                      : { variantId: c.variantId }),
                    allowSubstitution:
                      mode === "FLEXIBLE" && c.allowSubstitution,
                    alternativeVariantIds:
                      mode === "FLEXIBLE" ? c.alternativeVariantIds : [],
                  })),
                }),
              );
              await load();
              setOpen(false);
              notify("Conjunto registrado.");
            } catch (e: any) {
              setErr(e.message);
            } finally {
              setBusy(false);
            }
          }}
        >
          <Field label="Variante que representa el conjunto">
            <select
              name="variantId"
              required
              disabled={!!editing}
              defaultValue={editing?.id || ""}
            >
              {editing && <option value={editing.id}>{editing.label}</option>}
              <option value="">Selecciona una variante sin unidades</option>
              {variants
                .filter((v) => !v.units.length && !v.outfit)
                .map((v) => (
                  <option key={v.id} value={v.id}>
                    {v.label}
                  </option>
                ))}
            </select>
          </Field>
          <Field label="Modalidad">
            <select
              value={mode}
              onChange={(e) => {
                setMode(e.target.value);
                setComponents(components.map((c) => ({ ...c, quantity: 1 })));
              }}
            >
              <option value="FLEXIBLE">
                Flexible · prendas de variantes compatibles
              </option>
              <option value="FIXED">Fijo · unidades específicas</option>
            </select>
          </Field>
          {components.map((c, index) => (
            <div key={index} className="unit-card">
              <div className="component-row">
                <Field label="Nombre de la pieza">
                  <Input
                    value={c.name}
                    required
                    onChange={(e) =>
                      setComponents(
                        components.map((x, i) =>
                          i === index ? { ...x, name: e.target.value } : x,
                        ),
                      )
                    }
                  />
                </Field>
                <Field label={mode === "FIXED" ? "Unidad física" : "Variante"}>
                  <select
                    required
                    value={mode === "FIXED" ? c.fixedUnitId : c.variantId}
                    onChange={(e) =>
                      setComponents(
                        components.map((x, i) =>
                          i === index
                            ? {
                                ...x,
                                [mode === "FIXED"
                                  ? "fixedUnitId"
                                  : "variantId"]: e.target.value,
                              }
                            : x,
                        ),
                      )
                    }
                  >
                    <option value="">Selecciona una pieza</option>
                    {mode === "FIXED"
                      ? variants
                          .filter((v) => !v.outfit)
                          .flatMap((v) =>
                            v.units.map((u: any) => (
                              <option key={u.id} value={u.id}>
                                {v.label} · {u.code}
                              </option>
                            )),
                          )
                      : variants
                          .filter((v) => v.units.length && !v.outfit)
                          .map((v) => (
                            <option key={v.id} value={v.id}>
                              {v.label}
                            </option>
                          ))}
                  </select>
                </Field>
                <Field label="Cantidad">
                  <Input
                    type="number"
                    min="1"
                    max={mode === "FIXED" ? 1 : 20}
                    required
                    value={c.quantity}
                    onChange={(e) =>
                      setComponents(
                        components.map((x, i) =>
                          i === index
                            ? { ...x, quantity: Number(e.target.value) }
                            : x,
                        ),
                      )
                    }
                  />
                </Field>
                <Button
                  variant="ghost"
                  size="icon"
                  type="button"
                  disabled={components.length === 1}
                  onClick={() =>
                    setComponents(components.filter((_, i) => i !== index))
                  }
                >
                  <X size={16} />
                </Button>
              </div>
              <label className="checkbox">
                <input
                  type="checkbox"
                  checked={c.required}
                  onChange={(e) =>
                    setComponents(
                      components.map((x, i) =>
                        i === index ? { ...x, required: e.target.checked } : x,
                      ),
                    )
                  }
                />{" "}
                Obligatorio
              </label>
              {mode === "FLEXIBLE" && (
                <>
                  <label className="checkbox" style={{ marginTop: 10 }}>
                    <input
                      type="checkbox"
                      checked={c.allowSubstitution}
                      onChange={(e) =>
                        setComponents(
                          components.map((x, i) =>
                            i === index
                              ? { ...x, allowSubstitution: e.target.checked }
                              : x,
                          ),
                        )
                      }
                    />{" "}
                    Permitir sustituciones registradas
                  </label>
                  {c.allowSubstitution && (
                    <Field label="Variantes alternativas (Ctrl / Cmd para varias)">
                      <select
                        multiple
                        value={c.alternativeVariantIds}
                        onChange={(e) =>
                          setComponents(
                            components.map((x, i) =>
                              i === index
                                ? {
                                    ...x,
                                    alternativeVariantIds: Array.from(
                                      e.target.selectedOptions,
                                      (o) => o.value,
                                    ),
                                  }
                                : x,
                            ),
                          )
                        }
                      >
                        {variants
                          .filter(
                            (v) =>
                              v.units.length &&
                              !v.outfit &&
                              v.id !== c.variantId,
                          )
                          .map((v) => (
                            <option key={v.id} value={v.id}>
                              {v.label}
                            </option>
                          ))}
                      </select>
                    </Field>
                  )}
                </>
              )}
            </div>
          ))}
          <Button
            variant="outline"
            type="button"
            onClick={() =>
              setComponents([
                ...components,
                {
                  name: "",
                  required: true,
                  quantity: 1,
                  variantId: "",
                  fixedUnitId: "",
                  allowSubstitution: false,
                  alternativeVariantIds: [],
                },
              ])
            }
          >
            <Plus size={15} /> Agregar componente
          </Button>
          <ErrorBox message={err} />
          <Button disabled={busy}>Guardar conjunto</Button>
        </form>
      </Dialog>
    </>
  );
}
