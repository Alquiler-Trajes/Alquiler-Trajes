"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  ArrowUpRight,
  CalendarDays,
  CircleDollarSign,
  ClipboardList,
  Flower2,
  LayoutDashboard,
  Layers3,
  Package,
  ShieldCheck,
  Users,
} from "lucide-react";
import { money, statusLabels } from "@vestuario/shared";
import { api, colombianDate, mutation } from "@/lib/api";
import { Badge, Button, ErrorBox, Loading } from "../ui";
import { InventoryView, CategoriesView, OutfitsView } from "./inventory";
import { RentalsView, CustomersView, CalendarView } from "./rentals";
import { ImportView } from "./import";
const nav = [
  ["dashboard", "Resumen", LayoutDashboard],
  ["inventario", "Inventario", Package],
  ["alquileres", "Alquileres", ClipboardList],
  ["calendario", "Calendario", CalendarDays],
  ["clientes", "Clientes", Users],
  ["categorias", "Categorías", Layers3],
  ["conjuntos", "Conjuntos", Layers3],
  ["importar", "Importar Excel", ArrowUpRight],
] as const;
export function AdminApp({ section }: { section: string }) {
  const [admin, setAdmin] = useState<any>(null);
  const router = useRouter();
  useEffect(() => {
    api("/auth/me")
      .then(setAdmin)
      .catch(() => router.replace("/admin/login"));
  }, [router]);
  if (!admin) return <Loading />;
  const label = nav.find((n) => n[0] === section)?.[1] || "Resumen";
  return (
    <div className="admin-shell">
      <aside className="admin-sidebar">
        <Link className="logo" href="/admin">
          <Flower2 size={29} />
          vestuario
        </Link>
        <nav aria-label="Administración">
          {nav.map(([key, name, Icon]) => (
            <Link
              className={section === key ? "active" : ""}
              key={key}
              href={key === "dashboard" ? "/admin" : "/admin/" + key}
            >
              <Icon size={17} />
              {name}
            </Link>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <Link href="/">
            Ver catálogo público <ArrowUpRight size={14} />
          </Link>
          <small>{admin.email}</small>
          <button
            onClick={async () => {
              await api("/auth/logout", mutation("POST", {}));
              router.replace("/admin/login");
            }}
          >
            Cerrar sesión
          </button>
        </div>
      </aside>
      <div className="admin-main">
        <header className="admin-topbar">
          <strong>
            Tu espacio de trabajo{" "}
            <span style={{ color: "#b1b9a8", fontWeight: 400 }}>
              {" "}
              / {label}
            </span>
          </strong>
          <span>
            <ShieldCheck size={14} /> Sesión de {admin.name}
            <button
              className="text-link"
              style={{ fontSize: 10 }}
              onClick={async () => {
                await api("/auth/logout", mutation("POST", {}));
                router.replace("/admin/login");
              }}
            >
              Salir
            </button>
          </span>
        </header>
        <main id="main" className="admin-content">
          {section === "inventario" ? (
            <InventoryView />
          ) : section === "alquileres" ? (
            <RentalsView />
          ) : section === "calendario" ? (
            <CalendarView />
          ) : section === "clientes" ? (
            <CustomersView />
          ) : section === "categorias" ? (
            <CategoriesView />
          ) : section === "conjuntos" ? (
            <OutfitsView />
          ) : section === "importar" ? (
            <ImportView />
          ) : (
            <Dashboard />
          )}
        </main>
      </div>
    </div>
  );
}
function Dashboard() {
  const [data, setData] = useState<any>(null);
  const [error, setError] = useState("");
  useEffect(() => {
    api("/admin/dashboard")
      .then(setData)
      .catch((e) => setError(e.message));
  }, []);
  if (error) return <ErrorBox message={error} />;
  if (!data) return <Loading />;
  const stats = [
    [
      "Unidades registradas",
      data.units,
      "Prendas físicas en inventario",
      Package,
    ],
    [
      "Alquileres activos",
      data.active,
      "Prendas entregadas a clientes",
      ClipboardList,
    ],
    [
      "Reservas próximas",
      data.upcoming,
      "Confirmadas y por preparar",
      CalendarDays,
    ],
    [
      "Ingresos registrados",
      money(data.revenue),
      "Alquileres, sin garantías",
      CircleDollarSign,
    ],
    [
      "Entregas pendientes",
      data.pendingDeliveries,
      "Para sus fechas programadas",
      Package,
    ],
    [
      "Devoluciones vencidas",
      data.overdue,
      "Necesitan seguimiento",
      CalendarDays,
    ],
    [
      "Limpieza / reparación",
      `${data.cleaning} / ${data.repair}`,
      "Pendientes de revisión",
      Layers3,
    ],
    [
      "Solicitudes nuevas",
      data.requested,
      "Todavía no bloquean prendas",
      Users,
    ],
  ];
  return (
    <>
      <div className="admin-title">
        <div>
          <p className="eyebrow">CADA PRENDA CUENTA UNA HISTORIA</p>
          <h1 style={{ marginTop: 10 }}>Todo bajo control.</h1>
          <p>El estado de tu vestuario, en un solo lugar.</p>
        </div>
        <Button asChild>
          <Link href="/admin/inventario">
            Agregar un traje <ArrowUpRight size={16} />
          </Link>
        </Button>
      </div>
      {data.demoRecords > 0 && (
        <p className="info-box">
          Hay datos de demostración cargados. Los indicadores incluyen prendas,
          alquileres e ingresos ficticios, identificados como Demo en sus
          registros.
        </p>
      )}
      <div className="stats-grid">
        {stats.map(([label, value, hint, Icon]: any) => (
          <div
            key={label}
            className={
              "stat-card " +
              (label === "Devoluciones vencidas" && data.overdue ? "alert" : "")
            }
          >
            <Icon />
            <p>{label}</p>
            <strong>{value}</strong>
            <small>{hint}</small>
          </div>
        ))}
      </div>
      <section className="admin-section">
        <div className="admin-section-head">
          <h2>Tu agenda de alquileres</h2>
          <Link className="text-link" href="/admin/alquileres">
            Gestionar alquileres <ArrowUpRight size={15} />
          </Link>
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Solicitud</th>
                <th>Cliente</th>
                <th>Entrega</th>
                <th>Devolución</th>
                <th>Estado</th>
              </tr>
            </thead>
            <tbody>
              {data.agenda.map((r: any) => (
                <tr key={r.id}>
                  <td>
                    {r.reference}
                    {r.demo && (
                      <>
                        {" "}
                        <Badge>Demo</Badge>
                      </>
                    )}
                  </td>
                  <td>{r.customer.name}</td>
                  <td>{colombianDate(r.startsAt)}</td>
                  <td>{colombianDate(r.endsAt)}</td>
                  <td>
                    <Badge>{statusLabels[r.status]}</Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {!data.agenda.length && (
            <p className="admin-empty">
              Tu agenda está despejada. Las solicitudes aparecerán aquí.
            </p>
          )}
        </div>
      </section>
      <p className="fine-print" style={{ marginTop: 20 }}>
        Las referencias con etiqueta Demo son ficticias. Las unidades conservan
        su historial al archivarse.
      </p>
    </>
  );
}
