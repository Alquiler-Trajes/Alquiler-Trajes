"use client";
import { useState } from "react";
import { Download, FileSpreadsheet, Upload } from "lucide-react";
import { api, mutation } from "@/lib/api";
import { Button, ErrorBox } from "../ui";
export function ImportView() {
  const [preview, setPreview] = useState<any>(null);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  return (
    <>
      <div className="admin-title">
        <div>
          <h1>Tu inventario, sin repetir trabajo.</h1>
          <p>Importa hasta 500 diseños desde una plantilla de Excel.</p>
        </div>
        <Button asChild variant="outline">
          <a href="/api/admin/import/template" download>
            <Download size={16} /> Descargar plantilla
          </a>
        </Button>
      </div>
      <section className="form-card" style={{ maxWidth: 950 }}>
        <h2>1. Prepara tu archivo</h2>
        <p style={{ fontSize: 12, marginBottom: 20 }}>
          Conserva las ocho columnas de la plantilla. Escribe cantidades y
          precios como números. Crea las categorías antes de importar y elimina
          la fila de ejemplo. Una referencia identifica una fila de importación,
          no una unidad física.
        </p>
        <label className="upload-control">
          <FileSpreadsheet size={30} style={{ margin: "0 auto 10px" }} />
          Selecciona un archivo XLSX · máximo 2 MB
          <input
            type="file"
            accept=".xlsx"
            disabled={busy}
            onChange={async (e) => {
              const file = e.target.files?.[0];
              if (!file) return;
              setError("");
              setPreview(null);
              setResult(null);
              setBusy(true);
              const form = new FormData();
              form.append("file", file);
              try {
                setPreview(
                  await api("/admin/import/preview", {
                    method: "POST",
                    body: form,
                  }),
                );
              } catch (e: any) {
                setError(e.message);
              } finally {
                setBusy(false);
              }
            }}
          />
        </label>
        <ErrorBox message={error} />
        {busy && <p className="info-box">Procesando archivo…</p>}
        {preview && (
          <>
            <h2 style={{ marginTop: 30 }}>2. Revisa antes de importar</h2>
            <p style={{ fontSize: 12 }}>
              {preview.total} filas válidas · {preview.errors.length} errores.{" "}
              {preview.notice}
            </p>
            {preview.errors.length > 0 && (
              <div className="import-errors" role="alert">
                {preview.errors.map((e: any, i: number) => (
                  <p key={i}>
                    Fila {e.row}: {e.message}
                  </p>
                ))}
              </div>
            )}
            <div className="import-preview">
              <table>
                <thead>
                  <tr>
                    <th>Referencia</th>
                    <th>Nombre</th>
                    <th>Talla</th>
                    <th>Cantidad</th>
                    <th>Precio</th>
                  </tr>
                </thead>
                <tbody>
                  {preview.rows.map((r: any) => (
                    <tr key={r.row}>
                      <td>{r.reference}</td>
                      <td>{r.name}</td>
                      <td>{r.size}</td>
                      <td>{r.quantity}</td>
                      <td>{r.price}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <Button
              style={{ marginTop: 20 }}
              disabled={!preview.valid || busy || !!result}
              onClick={async () => {
                setBusy(true);
                setError("");
                try {
                  setResult(
                    await api(
                      "/admin/import/commit",
                      mutation("POST", { rows: preview.rows, confirmed: true }),
                    ),
                  );
                } catch (e: any) {
                  setError(e.message);
                } finally {
                  setBusy(false);
                }
              }}
            >
              <Upload size={16} /> Confirmar importación de {preview.total}{" "}
              filas
            </Button>
          </>
        )}
        {result && (
          <div className="import-status" role="status">
            Importación completada: {result.imported} diseños y {result.units}{" "}
            unidades físicas independientes.
          </div>
        )}
      </section>
    </>
  );
}
