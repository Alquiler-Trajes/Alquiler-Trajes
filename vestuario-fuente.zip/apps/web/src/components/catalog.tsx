"use client";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { ArrowLeft, ArrowRight, Search, SlidersHorizontal, X } from "lucide-react";
import { collectionSections, costumeKind, type CostumeKind } from "@vestuario/shared";
import { api, bogotaISO, compareSizes, type CatalogItem } from "@/lib/api";
import { asset, staticCatalog } from "@/lib/public-mode";
import { Button, Empty, ErrorBox, Field, Input } from "./ui";
const initialFilters = { group: "", kind: "", q: "", style: "", size: "", color: "", category: "", start: "", end: "", onlyAvailable: false };
export function CatalogPage() {
  const [selection, setSelection] = useState(initialFilters);
  const [query, setQuery] = useState("");
  const [ready, setReady] = useState(false);
  const [data, setData] = useState<any>(null);
  const [items, setItems] = useState<CatalogItem[]>([]);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [retry, setRetry] = useState(0);
  const results = useRef<HTMLElement>(null);
  useEffect(() => {
    const params = new URLSearchParams(window.location.search || sessionStorage.getItem("vestuario-catalog-filters") || "");
    const values = { ...initialFilters };
    for (const key of ["group", "kind", "q", "style", "size", "color", "category"] as const) values[key] = params.get(key) || "";
    if (!["celebraciones", "personajes", "accesorios"].includes(values.group)) values.group = "";
    if (!collectionSections.some(s => s.kind === values.kind)) values.kind = "";
    setSelection(values); setQuery(values.q); setReady(true);
  }, []);
  useEffect(() => {
    if (!ready) return;
    const params = new URLSearchParams();
    for (const key of ["group", "kind", "q", "style", "size", "color", "category"] as const) if (selection[key]) params.set(key, selection[key]);
    sessionStorage.setItem("vestuario-catalog-filters", params.toString());
    window.history.replaceState(window.history.state, "", window.location.pathname + (params.size ? "?" + params : ""));
    let live = true;
    setLoading(true); setError("");
    params.set("collection", "current"); params.set("page", String(page));
    if (!staticCatalog && selection.start && selection.end) {
      params.set("startsAt", bogotaISO(selection.start)); params.set("endsAt", bogotaISO(selection.end));
      if (selection.onlyAvailable) params.set("onlyAvailable", "true");
    }
    api("/catalog?" + params).then(result => {
      if (!live) return;
      setData(result);
      setItems(previous => page === 1 ? result.items : [...new Map([...previous, ...result.items].map((i: CatalogItem) => [i.id, i])).values()]);
    }).catch(e => { if (live) setError(e.message); }).finally(() => { if (live) setLoading(false); });
    return () => { live = false; };
  }, [selection, page, ready, retry]);
  const update = <K extends keyof typeof initialFilters>(key: K, value: typeof initialFilters[K]) => {
    setPage(1); setItems([]); setSelection(previous => ({ ...previous, [key]: value }));
  };
  const reset = () => { setQuery(""); setPage(1); setItems([]); setSelection({ ...initialFilters, group: selection.group }); };
  const accessoryView = selection.group === "accesorios";
  const noun = accessoryView ? "accesorios" : selection.group ? "trajes" : "modelos";
  const groupTitle = selection.group === "celebraciones" ? "Danzas y cultura" : selection.group === "personajes" ? "Profesiones y disfraces" : accessoryView ? "Accesorios para alquilar" : "Trajes y accesorios";
  const visibleSections = collectionSections.filter(s => !selection.group || (accessoryView ? s.kind === "accessory" : selection.group === "celebraciones" ? ["cultural", "stage", "princess"].includes(s.kind) : ["profession", "costume"].includes(s.kind)));
  const activeCount = [selection.kind, selection.style, selection.size, selection.color, selection.category, selection.start].filter(Boolean).length;
  const grouped = collectionSections.map(section => ({ ...section, items: items.filter(item => costumeKind(item, data?.categories || []) === section.kind) })).filter(section => section.items.length);
  return <main id="main" className="container easy-catalog">
    <Link href="/" className="back-link text-link"><ArrowLeft size={20} /> Cambiar colección</Link>
    <div className="collection-heading"><p className="welcome-kicker">{accessoryView ? "Complementa tu personaje" : "Elige el traje que te gusta"}</p><h1>{groupTitle}</h1><p>{accessoryView ? "Alquila un accesorio o un kit. Toca la foto para ver qué incluye." : "Toca una foto para ver el traje y elegir tu talla."}</p>{!accessoryView && <a href={asset("/catalogo") + "?group=accesorios"} className="text-link">Ver accesorios para alquilar <ArrowRight size={19} /></a>}</div>
    <div className="easy-tools">
      <form className="easy-search" onSubmit={event => { event.preventDefault(); update("q", query); }}>
        <Search size={23} aria-hidden="true" /><input aria-label="Buscar en el catálogo" placeholder={accessoryView ? "Busca un accesorio o un kit…" : "Busca un traje por su nombre…"} value={query} onChange={event => setQuery(event.target.value)} /><button type="submit">Buscar <ArrowRight size={19} /></button>
      </form>
      <details className="easy-filters">
        <summary><SlidersHorizontal size={21} /> Filtrar {activeCount > 0 && <span>{activeCount}</span>}</summary>
        <div className="easy-filter-fields">
          <Field label="Tipo de traje"><select aria-label="Tipo de traje" value={selection.kind} onChange={e => { update("kind", e.target.value); if (e.target.value && e.target.value !== "cultural") setSelection(previous => ({ ...previous, style: "" })); }}><option value="">Todos los tipos</option>{visibleSections.map(section => <option key={section.kind} value={section.kind}>{section.title}</option>)}</select></Field>
          {selection.group !== "personajes" && !accessoryView && (!selection.kind || selection.kind === "cultural") && !!data?.styles?.length && <Field label="Danza o región"><select aria-label="Danza o región" value={selection.style} onChange={e => update("style", e.target.value)}><option value="">Todas las danzas y regiones</option>{data.styles.map((style: { name: string }) => <option key={style.name}>{style.name}</option>)}</select></Field>}
          <Field label="Talla"><select aria-label="Talla" value={selection.size} onChange={e => update("size", e.target.value)}><option value="">Todas las tallas</option>{(data?.filters?.sizes || []).slice().sort(compareSizes).map((size: string) => <option key={size}>{size}</option>)}</select></Field>
          <Field label="Color"><select aria-label="Color" value={selection.color} onChange={e => update("color", e.target.value)}><option value="">Todos los colores</option>{data?.filters?.colors.map((color: string) => <option key={color}>{color}</option>)}</select></Field>
          {!staticCatalog && <><Field label="Entrega · hora Bogotá"><Input type="datetime-local" value={selection.start} onChange={e => update("start", e.target.value)} /></Field><Field label="Devolución · hora Bogotá"><Input type="datetime-local" value={selection.end} min={selection.start} onChange={e => update("end", e.target.value)} /></Field><label className="checkbox"><input type="checkbox" checked={selection.onlyAvailable} disabled={!selection.start || !selection.end} onChange={e => update("onlyAvailable", e.target.checked)} /> Solo disponibles para estas fechas</label></>}
        </div>
      </details>
    </div>
    <div className="easy-results" role="status" aria-live="polite"><span>{loading ? "Buscando…" : `${data?.total || 0} ${noun} para elegir`}{selection.q && ` · «${selection.q}»`}</span>{(activeCount > 0 || selection.q) && <button onClick={reset}>Limpiar filtros <X size={17} /></button>}</div>
    {!!data?.intent?.explanation?.length && <details className="search-hint"><summary>Sobre esta búsqueda</summary>{data.intent.explanation.map((text: string) => <p key={text}>{text}</p>)}</details>}
    <ErrorBox message={error} />{error && <Button variant="outline" onClick={() => setRetry(n => n + 1)}>Intentar de nuevo</Button>}
    <section ref={results} aria-label="Catálogo de trajes" aria-busy={loading}>
      {loading && !items.length ? <div className="easy-product-grid" aria-label="Cargando catálogo">{[0, 1, 2, 3].map(i => <div key={i} className="skeleton-card"><div className="skeleton" /></div>)}</div> : grouped.map(section => <section className="costume-section" key={section.kind} aria-label={section.title} data-kind={section.kind}>{!accessoryView && <div className="costume-section-heading"><h2>{section.title}</h2><span>{section.items.length} {section.items.length === 1 ? "modelo" : "modelos"}</span></div>}<div className="easy-product-grid">{section.items.map(item => <ProductCard key={item.id} item={item} />)}</div></section>)}
      {!loading && !error && !items.length && <Empty title="No encontramos un traje con esos filtros."><p>Prueba otro nombre o vuelve a ver la colección completa.</p><Button onClick={reset}>Ver la colección completa</Button></Empty>}
      {data?.total > items.length && !!items.length && <div className="load-more"><Button variant="outline" disabled={loading} onClick={() => setPage(n => n + 1)}>{loading ? "Cargando…" : `Ver ${Math.min(24, data.total - items.length)} ${noun} más`}</Button></div>}
    </section>
  </main>;
}
export function ProductCard({ item }: { item: CatalogItem }) {
  const accessory = item.tags.includes("accesorio-alquilable");
  return <Link href={`/trajes/${item.slug}`} className="easy-product-card" aria-label={`Ver ${accessory ? "accesorio" : "traje"}: ${item.name}`}>
    <div className="catalog-photo-frame"><img src={item.images[0] || asset("/placeholder.svg")} alt={item.name} loading="lazy" /></div>
    <div className="easy-card-copy"><h3>{item.name}</h3><span>Ver {accessory ? "accesorio" : "traje"} <ArrowRight size={20} /></span></div>
  </Link>;
}
