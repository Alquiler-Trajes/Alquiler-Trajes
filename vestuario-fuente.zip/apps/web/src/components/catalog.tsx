"use client";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import {
  ArrowDown,
  ArrowRight,
  ArrowUpRight,
  CalendarDays,
  Check,
  Search,
  SlidersHorizontal,
  Sparkles,
  X,
} from "lucide-react";
import { money } from "@vestuario/shared";
import { api, bogotaISO, compareSizes, hasPendingPrice, type CatalogItem } from "@/lib/api";
import { Badge, Button, Empty, ErrorBox, Field, Input } from "./ui";
import { asset, staticCatalog } from "@/lib/public-mode";
export function CatalogPage({ home = false }: { home?: boolean }) {
  const [query, setQuery] = useState("");
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");
  const [style, setStyle] = useState("");
  const [initialized, setInitialized] = useState(false);
  const [size, setSize] = useState("");
  const [color, setColor] = useState("");
  const [sort, setSort] = useState("relevance");
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const [onlyAvailable, setOnlyAvailable] = useState(false);
  const [filters, setFilters] = useState(false);
  const [page, setPage] = useState(1);
  const [data, setData] = useState<any>(null);
  const [showcase, setShowcase] = useState<CatalogItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [retry, setRetry] = useState(0);
  const catalogue = useRef<HTMLElement>(null);
  useEffect(() => {
    const initial = new URLSearchParams(window.location.search || (!home ? sessionStorage.getItem("vestuario-catalog-filters") || "" : ""));
    if (initial.get("q")) {
      setSearch(initial.get("q")!);
      setQuery(initial.get("q")!);
    }
    if (initial.get("category")) setCategory(initial.get("category")!);
    setStyle(initial.get("style") || "");
    setSize(initial.get("size") || "");
    setColor(initial.get("color") || "");
    setInitialized(true);
  }, []);
  useEffect(() => {
    if (!initialized) return;
    const params = new URLSearchParams();
    if (search) params.set("q", search);
    if (category) params.set("category", category);
    if (style) params.set("style", style);
    if (size) params.set("size", size);
    if (color) params.set("color", color);
    const query = params.toString();
    if (!home) sessionStorage.setItem("vestuario-catalog-filters", query);
    window.history.replaceState(window.history.state, "", window.location.pathname + (query ? `?${query}` : ""));
  }, [initialized, search, category, style, size, color]);
  useEffect(() => {
    if (!initialized) return;
    let live = true;
    setLoading(true);
    setError("");
    const params = new URLSearchParams({ q: search, sort, page: String(page), collection: "current" });
    if (category) params.set("category", category);
    if (size) params.set("size", size);
    if (color) params.set("color", color);
    if (style) params.set("style", style);
    if (start && end) {
      params.set("startsAt", bogotaISO(start));
      params.set("endsAt", bogotaISO(end));
      if (onlyAvailable) params.set("onlyAvailable", "true");
    }
    api("/catalog?" + params)
      .then((d) => {
        if (live) {
          setData(d);
          setShowcase(previous => previous.length ? previous : d.items.filter((i: CatalogItem) => !i.demo && i.images.length));
        }
      })
      .catch((e) => {
        if (live) setError(e.message);
      })
      .finally(() => {
        if (live) setLoading(false);
      });
    return () => {
      live = false;
    };
  }, [
    search,
    category,
    size,
    color,
    sort,
    start,
    end,
    onlyAvailable,
    page,
    retry,
    style,
    initialized,
  ]);
  const reset = () => {
    setSearch("");
    setQuery("");
    setCategory("");
    setStyle("");
    setSize("");
    setColor("");
    setStart("");
    setEnd("");
    setOnlyAvailable(false);
    setPage(1);
  };
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setSearch(query);
    setPage(1);
    catalogue.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  };
  const categories = data?.navigationCategories || [];
  const selectedCategory = data?.categories?.find((c: any) => c.id === category);
  const belongsTo = (ancestor: string, child: string): boolean => {
    const visited = new Set<string>();
    let current = child;
    while (current && !visited.has(current)) {
      if (current === ancestor) return true;
      visited.add(current);
      current = data?.categories?.find((c: any) => c.id === current)?.parentId || "";
    }
    return false;
  };
  const activeFamily = categories.find((c: any) => belongsTo(c.id, category));
  const subcategories = data?.categories?.filter((c: any) => c.parentId === activeFamily?.id) || [];
  const heroItems = showcase;
  const heroBack = heroItems.find((i: CatalogItem) => i.slug === "real-elsa") || heroItems[0];
  const heroFront = heroItems.find((i: CatalogItem) => i.slug === "real-hada-verde") || heroItems[1] || heroItems[0];
  return (
    <main id="main">
      {home && (
        <section className="hero container">
          <div className="hero-copy">
            <p className="eyebrow">
              <span /> CULTURA QUE SE VISTE
            </p>
            <h1>
              Cada historia
              <br />
              tiene <em>su traje.</em>
            </h1>
            <p className="hero-description">
              Del primer baile a un mundo de fantasía.
              <br className="hide-mobile" /> Encuentra el vestuario que hará
              especial ese momento.
            </p>
            <form className="hero-search" onSubmit={submit}>
              <label htmlFor="hero-search">¿Qué traje estás buscando?</label>
              <div>
                <Search size={21} />
                <input
                  id="hero-search"
                  placeholder="Prueba: traje de cumbia o princesa azul"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                />
                <Button size="icon" aria-label="Buscar trajes">
                  <ArrowRight size={20} />
                </Button>
              </div>
            </form>
            <div className="hero-note">
              <Check size={15} /> Sin registro <span>·</span>
              <Check size={15} /> Tallas con orientación <span>·</span>
              <Check size={15} /> Alquiler fácil
            </div>
          </div>
          <div
            className="hero-art"
            aria-label={heroFront ? "Modelos de nuestra colección" : "Ilustraciones de trajes de demostración"}
          >
            <div className="hero-orbit" />
            <span className="art-spark">✳</span>
            <div className="art-caption">
              Tradición.
              <br />
              Imaginación.
              <br />
              <i>Celebración.</i>
            </div>
            <div className="art-card art-back">
              <img
                src={heroBack?.images[0] || asset("/demo/cenicienta.svg")}
                alt={heroBack?.name || "Ilustración de demostración de vestido azul"}
              />
              <span>
                Un poco de magia <Sparkles size={13} />
              </span>
            </div>
            <div className="art-card art-front">
              <img
                src={heroFront?.images[0] || asset("/demo/mapale.svg")}
                alt={heroFront?.name || "Ilustración de demostración de traje de Mapalé"}
              />
              <span>
                {heroFront ? "Hecho para imaginar" : "Raíces que se mueven"} <ArrowUpRight size={14} />
              </span>
            </div>
            <span className="art-label">{heroFront ? "Colección infantil y adulto" : "Colección ilustrativa · Demo"}</span>
          </div>
        </section>
      )}
      {home && (
        <div className="category-strip">
          <div className="container category-inner">
            <span>
              UN TRAJE PARA
              <br />
              <strong>cada ocasión</strong>
            </span>
            <button
              onClick={() => {
                reset();
                catalogue.current?.scrollIntoView({ behavior: "smooth" });
              }}
            >
              ✧ Todo el vestuario
            </button>
            {categories.slice(0, 5).map((c: any, i: number) => (
              <button
                key={c.id}
                className={category === c.id ? "selected" : ""}
                onClick={() => {
                  setCategory(c.id); setStyle("");
                  setPage(1);
                  catalogue.current?.scrollIntoView({ behavior: "smooth" });
                }}
              >
                <span>{["❋", "♧", "✺", "✧", "❋"][i]}</span>
                {c.name}
              </button>
            ))}
          </div>
        </div>
      )}
      <section
        className="container catalog-section"
        ref={catalogue}
        aria-label="Catálogo de trajes"
      >
        <div className="section-heading">
          <div>
            <p className="eyebrow">ENCUENTRA TU PRÓXIMO PERSONAJE</p>
            <h2>{home ? "Un mundo por vestir." : "Explora el vestuario."}</h2>
          </div>
          {home && (
            <Link className="text-link" href="/catalogo">
              Ver todo el catálogo <ArrowUpRight size={17} />
            </Link>
          )}
        </div>
        <div className="catalog-toolbar">
          <form className="catalog-search" onSubmit={submit}>
            <Search size={18} />
            <input
              aria-label="Buscar en el catálogo"
              placeholder="Buscar trajes, personajes, danzas…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
            <button type="submit" aria-label="Aplicar búsqueda">
              <ArrowRight size={18} />
            </button>
          </form>
          <Button
            variant={filters ? "default" : "outline"}
            onClick={() => setFilters(!filters)}
          >
            <SlidersHorizontal size={16} /> Filtros{" "}
            {(size || color || start) && <span className="filter-dot" />}
          </Button>
          <select
            aria-label="Ordenar resultados"
            value={sort}
            onChange={(e) => setSort(e.target.value)}
          >
            <option value="relevance">Más relevantes</option>
            <option value="price-asc">Menor precio</option>
            <option value="price-desc">Mayor precio</option>
            <option value="name">Nombre A–Z</option>
          </select>
        </div>
        <div className="category-pills">
          <button
            className={!category ? "active" : ""}
            onClick={() => {
              setCategory(""); setStyle("");
              setPage(1);
            }}
          >
            Todos los trajes
          </button>
          {categories.map((c: any) => (
              <button
                key={c.id}
                className={belongsTo(c.id, category) ? "active" : ""}
                onClick={() => {
                  setCategory(c.id); setStyle("");
                  setPage(1);
                }}
              >
                {c.name} <small>{c.count}</small>
              </button>
            ))}
        </div>
        {subcategories.length > 0 && <div className="category-pills subcategory-pills" aria-label={`Diseños de ${activeFamily.name}`}>
          <button className={category === activeFamily.id ? "active" : ""} onClick={() => { setCategory(activeFamily.id); setStyle(""); setPage(1); }}>Todos los diseños</button>
          {subcategories.map((c: any) => <button key={c.id} className={category === c.id ? "active" : ""} onClick={() => { setCategory(c.id); setStyle(""); setPage(1); }}>{c.name} <small>{c.count}</small></button>)}
        </div>}
        {!!data?.styles?.length && (!category || activeFamily?.slug === "bailes") && <div className="style-filter" role="group" aria-label="Filtrar por danza o región">
          <span>Danza o región</span><div>
          {data.styles.map((s: { name: string; count: number }) => <button key={s.name} className={style === s.name ? "active" : ""} aria-pressed={style === s.name} onClick={() => { setStyle(style === s.name ? "" : s.name); setPage(1); }}>{s.name}<small>{s.count}</small></button>)}
          </div>
        </div>}
        {(search || style || size || color || start) && <div className="active-filters" aria-label="Filtros activos">
          {[[search, () => { setSearch(""); setQuery(""); }], [style, () => setStyle("")], [size && `Talla ${size}`, () => setSize("")], [color, () => setColor("")]].filter(([label]) => label).map(([label, remove]) => <button key={String(label)} onClick={() => { (remove as () => void)(); setPage(1); }} aria-label={`Quitar filtro ${label}`}>{String(label)}<X size={13} /></button>)}
          <button className="clear-filters" onClick={reset}>Limpiar todo</button>
        </div>}
        {selectedCategory && <p className="catalog-breadcrumb">Colección / {activeFamily?.name}{selectedCategory.id !== activeFamily?.id ? ` / ${selectedCategory.name}` : ""}</p>}
        {filters && (
          <div className="filter-panel">
            <Field label="Talla comercial">
              <select
                value={size}
                onChange={(e) => {
                  setSize(e.target.value);
                  setPage(1);
                }}
              >
                <option value="">Todas las tallas</option>
                {data?.filters?.sizes.map((s: string) => (
                  <option key={s}>{s}</option>
                ))}
              </select>
            </Field>
            <Field label="Color">
              <select
                value={color}
                onChange={(e) => {
                  setColor(e.target.value);
                  setPage(1);
                }}
              >
                <option value="">Todos los colores</option>
                {data?.filters?.colors.map((s: string) => (
                  <option key={s}>{s}</option>
                ))}
              </select>
            </Field>
            {!staticCatalog && <><Field label="Entrega · hora Bogotá">
              <Input
                type="datetime-local"
                value={start}
                onChange={(e) => setStart(e.target.value)}
              />
            </Field>
            <Field label="Devolución · hora Bogotá">
              <Input
                type="datetime-local"
                value={end}
                min={start}
                onChange={(e) => setEnd(e.target.value)}
              />
            </Field>
            <label className="checkbox">
              <input
                type="checkbox"
                checked={onlyAvailable}
                disabled={!start || !end}
                onChange={(e) => setOnlyAvailable(e.target.checked)}
              />{" "}
              Solo disponibles para estas fechas
            </label></>}
            <button className="text-link" onClick={reset}>
              Limpiar filtros <X size={14} />
            </button>
          </div>
        )}
        <div className="results-meta">
          <span>
            {loading
              ? "Buscando en el vestuario…"
              : `${data?.total || 0} diseños para descubrir`}
          </span>
          <span className="demo-note">
            <span /> {data?.hasRealCollection ? (data.items.length && data.items.every((i: CatalogItem) => i.bundleSize === 6) ? "Tallas escolares S · M · Niño · Accesorios incluidos" : "Tallas infantiles y de adulto · Accesorios incluidos") : "Las ilustraciones y los artículos demo son ficticios."}
          </span>
        </div>
        {data?.intent?.explanation?.map((s: string) => (
          <p className="info-box" key={s}>
            <Sparkles size={17} />
            {s}
          </p>
        ))}
        {!staticCatalog && data?.intent?.quantity > 1 && (
          <p className="info-box">
            Buscamos {data.intent.quantity} trajes. Selecciona fechas para
            comprobar si hay suficientes unidades.
          </p>
        )}
        <ErrorBox message={error} />
        {error && (
          <Button variant="outline" onClick={() => setRetry(retry + 1)}>
            Intentar de nuevo
          </Button>
        )}
        {loading ? (
          <div className="product-grid" aria-label="Cargando catálogo">
            {Array.from({ length: 8 }, (_, i) => (
              <div className="skeleton-card" key={i}>
                <div className="skeleton" />
                <span className="skeleton" />
              </div>
            ))}
          </div>
        ) : data?.items.length ? (
          <>
            <div className="product-grid">
              {data.items.map((item: CatalogItem) => (
                <ProductCard key={item.id} item={item} />
              ))}
            </div>
            {data.total > 24 && (
              <div className="pagination">
                <Button
                  variant="outline"
                  disabled={page === 1}
                  onClick={() => setPage(page - 1)}
                >
                  Anterior
                </Button>
                <span>
                  Página {page} de {Math.ceil(data.total / 24)}
                </span>
                <Button
                  variant="outline"
                  disabled={page * 24 >= data.total}
                  onClick={() => setPage(page + 1)}
                >
                  Siguiente
                </Button>
              </div>
            )}
          </>
        ) : (
          !error && (
            <Empty title="Todavía no encontramos ese traje.">
              <p>Prueba con otro nombre, una danza o un personaje.</p>
              <div className="category-pills center">
                {data?.suggestions.map((s: string) => (
                  <button
                    key={s}
                    onClick={() => {
                      setSearch(s);
                      setQuery(s);
                      setPage(1);
                    }}
                  >
                    {s}
                  </button>
                ))}
              </div>
              <Button variant="outline" onClick={reset}>
                Explorar todo el inventario
              </Button>
            </Empty>
          )
        )}
      </section>
      {home && (
        <section id="como-funciona" className="how-section">
          <div className="container">
            <p className="eyebrow">MÁS MOMENTOS, MENOS COMPLICACIONES</p>
            <div className="section-heading">
              <h2>Listo para salir a escena.</h2>
              <span className="how-icon">✳</span>
            </div>
            <div className="steps">
              {[
                [
                  "01",
                  "Encuentra tu traje",
                  "Explora por ocasión, personaje o tradición. Busca como se lo contarías a alguien.",
                ],
                [
                  "02",
                  "Elige talla y fechas",
                  staticCatalog ? "Elige una unidad o el juego completo de seis. Confirma talla, fechas y colores con el negocio." : "Revisa medidas y disponibilidad. Si tienes dudas, te ayudamos a confirmar el ajuste.",
                ],
                [
                  "03",
                  "Solicita y celebra",
                  staticCatalog ? "Guarda y comparte el resumen de tu selección. Acordaremos contigo la tarifa y la reserva." : "Envía tu selección. El negocio revisará las prendas y confirmará tu reserva.",
                ],
              ].map(([n, title, desc]) => (
                <div key={n}>
                  <span>{n}</span>
                  <h3>{title}</h3>
                  <p>{desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}
    </main>
  );
}
export function ProductCard({ item }: { item: CatalogItem }) {
  const sizes = [...new Set(item.variants.map((v) => v.size))].sort(compareSizes);
  const isOutfit = item.variants.some(v => v.isOutfit);
  const stock = item.variants.some((v) => v.available !== undefined)
    ? isOutfit ? item.variants.filter(v => v.available > 0).length : item.variants.reduce((s, v) => s + (v.available || 0), 0)
    : null;
  return (
    <Link href={`/trajes/${item.slug}`} className="product-card">
      <div className={`product-image${item.tags.includes("foto-estudio-ia") ? " product-image-studio" : item.tags.includes("foto-retocada") ? " product-image-group" : ""}`}>
        <img
          src={item.images[0] || asset("/placeholder.svg")}
          alt={item.demo ? `Ilustración demo de ${item.name}` : item.name}
          loading="lazy"
        />
        {item.demo && <Badge tone="light">Demo ilustrativa</Badge>}
        {!item.demo && item.tags.includes("foto-referencia") && <Badge tone="light">Imagen de referencia</Badge>}
        {item.danceStyle ? <Badge tone="light">{item.danceStyle.replace(" / ", " · ")}</Badge> : item.tags.includes("foto-estudio-ia") && <Badge tone="light">Edición de estudio</Badge>}
        {!item.tags.includes("foto-estudio-ia") && item.tags.includes("foto-retocada") && <Badge tone="light">Foto del vestuario · retocada</Badge>}
        <span className="card-arrow">
          <ArrowUpRight size={21} />
        </span>
        {item.variants.some((v) => v.isOutfit) && (
          <span className="set-label">{item.bundleSize === 6 ? "x1 o juego x6" : "Conjunto"}</span>
        )}
      </div>
      <div className="product-meta">
        <span>{item.category.name}</span>
        <span>{sizes.length > 8 ? "Infantil 2–16 · Adulto XS–XXL" : `Tallas ${sizes.join(" · ")}`}</span>
      </div>
      <h3>{item.name}</h3>
      <div className="product-bottom">
        <span>
          {hasPendingPrice(item.minPrice, item.tags) ? <strong>Precio por definir</strong> : <>Desde <strong>{money(item.minPrice)}</strong>{" "}<small>/ alquiler</small></>}
        </span>
        <span className={stock === 0 ? "stock no-stock" : "stock"}>
          {stock !== null ? `${stock} ${isOutfit ? "tallas disponibles" : "disponibles"}` : "Ver tallas"}
          <span />
        </span>
      </div>
    </Link>
  );
}
