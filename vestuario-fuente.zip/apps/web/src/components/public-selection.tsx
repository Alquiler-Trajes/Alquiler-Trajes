"use client";
import Link from "next/link";
import { useState } from "react";
import { ArrowLeft, Copy, Download, Instagram, ShoppingBag, Trash2 } from "lucide-react";
import { hasPendingPrice } from "@/lib/api";
import { money } from "@vestuario/shared";
import { asset } from "@/lib/public-mode";
import { instagramHandle, instagramMessageUrl, instagramProfileUrl } from "@/lib/contact";
import { cartKey, useStore } from "./providers";
import { Badge, Button, Empty } from "./ui";
export function PublicSelection() {
  const { cart, setQuantity, notify } = useStore();
  const [copyStatus, setCopyStatus] = useState("");
  const keys = [...new Set(cart.map(i => i.bundleId || cartKey(i)))];
  const selections = keys.map(key => {
    const items = cart.filter(i => (i.bundleId || cartKey(i)) === key);
    return { key, first: items[0], items, quantity: items.reduce((n, i) => n + i.quantity, 0) };
  });
  const text = ["Hola, me interesan estos artículos de Vestuario:", ...selections.map(({ first, items, quantity }) =>
    `• ${first.name} · ${first.bundleId ? "1 juego de 6: " + items.map(i => `${i.quantity} talla ${i.size}`).join(" + ") : `${quantity} unidad(es), talla ${first.size}`} · color de preferencia: ${first.color}`), "", "Por favor confirmen tarifa, disponibilidad, fechas y ajuste de talla. Esta selección no es una reserva."].join("\n");
  const copySelection = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopyStatus("Selección copiada. Pégala en el chat de Instagram y añade la fecha del alquiler.");
      notify("Selección copiada. Pégala en el chat de Instagram.");
    } catch {
      setCopyStatus("No se pudo copiar automáticamente. Abre «Ver resumen y otras opciones» para copiar el texto o descargarlo.");
    }
  };
  return <main id="main" className="container checkout-page">
    <Link href="/catalogo" className="text-link"><ArrowLeft size={16} /> Seguir explorando</Link>
    <h1>Mi selección.</h1>
    <p className="page-description">Revisa tu selección y consúltanos por Instagram para acordar el alquiler.</p>
    {!cart.length ? <Empty title="Elige el vestuario para tu próxima historia."><Button asChild><Link href="/catalogo">Explorar el catálogo</Link></Button></Empty> : <div className="checkout-grid"><div className="cart-items">
      {selections.map(({ key, first, items, quantity }) => <div key={key} className={`cart-item ${first.bundleId ? "cart-bundle" : ""}`}>
        <img src={first.image || asset("/placeholder.svg")} alt={first.name} />
        <div><Link href={`/trajes/${first.slug}`}><h3>{first.name}</h3></Link><p>{first.bundleId ? items.map(i => `${i.quantity} talla ${i.size}`).join(" + ") : `${quantity} × talla ${first.size}`} · {first.color}</p>{first.bundleId && <Badge>Juego de 6 · accesorios incluidos</Badge>}<strong>{hasPendingPrice(first.price, ["coleccion-real-octubre-2026"]) ? "Tarifa por confirmar" : money(items.reduce((n, i) => n + i.price * i.quantity, 0))}</strong></div>
        <button className="icon-button" aria-label={`Quitar ${first.name}`} onClick={() => setQuantity(cartKey(first), 0)}><Trash2 size={18} /></button>
      </div>)}
    </div><aside className="order-summary"><ShoppingBag size={24} /><h2>Comparte tu selección</h2><p>{cart.reduce((n, i) => n + i.quantity, 0)} artículos seleccionados</p>
      <p className="info-box">El negocio confirmará precio, disponibilidad y tallas. Guardar esta selección no bloquea prendas ni confirma una reserva.</p>
      <p className="instagram-instructions">Abre Instagram y pega tu selección en el chat de <strong>@{instagramHandle}</strong>. Añade la fecha y tu municipio.</p>
      <Button asChild><a href={instagramMessageUrl} target="_blank" rel="noreferrer" onClick={copySelection}><Instagram size={22} aria-hidden="true" /> Copiar y abrir Instagram</a></Button>
      <p className="copy-status" role="status" aria-live="polite">{copyStatus}</p>
      <a className="text-link instagram-profile-link" href={instagramProfileUrl} target="_blank" rel="noreferrer">Ver perfil de @{instagramHandle}</a>
      <details className="selection-message"><summary>Ver resumen y otras opciones</summary><pre>{text}</pre><Button variant="outline" onClick={copySelection}><Copy size={18} /> Copiar selección</Button><Button variant="outline" onClick={() => { const url = URL.createObjectURL(new Blob([text], { type: "text/plain;charset=utf-8" })); const link = document.createElement("a"); link.href = url; link.download = "mi-seleccion-vestuario.txt"; link.click(); URL.revokeObjectURL(url); }}><Download size={18} /> Descargar resumen</Button></details>
      <small className="fine-print">Tu selección se conserva únicamente en este navegador.</small>
    </aside></div>}
  </main>;
}
