"use client";
import {
  createContext,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react";
import { z } from "zod";
import { usePathname } from "next/navigation";
import Link from "next/link";
import {
  ArrowUpRight,
  ShoppingBag,
  Flower2,
  MessageCircle,
  Check,
  X,
} from "lucide-react";
import { Button } from "./ui";
import { api } from "@/lib/api";
import { staticCatalog } from "@/lib/public-mode";
const itemSchema = z.object({
  variantId: z.string(),
  slug: z.string(),
  name: z.string(),
  size: z.string(),
  color: z.string(),
  price: z.number().nonnegative(),
  quantity: z.number().int().min(1).max(100),
  image: z.string(),
  demo: z.boolean().default(false),
  bundleId: z.string().optional(),
  bundleLabel: z.string().optional(),
});
export type CartItem = z.infer<typeof itemSchema>;
export const cartKey = (item: CartItem) => `${item.bundleId || "unit"}:${item.variantId}`;
const Context = createContext<{
  cart: CartItem[];
  add: (item: CartItem) => void;
  addMany: (items: CartItem[]) => void;
  setQuantity: (id: string, n: number) => void;
  clear: () => void;
  notify: (message: string) => void;
}>({
  cart: [],
  add: () => {},
  addMany: () => {},
  setQuantity: () => {},
  clear: () => {},
  notify: () => {},
});
export const useStore = () => useContext(Context);
export function Providers({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [ready, setReady] = useState(false);
  const [toast, setToast] = useState("");
  useEffect(() => {
    try {
      const data = z
        .array(itemSchema)
        .max(30)
              .parse(JSON.parse(localStorage.getItem(staticCatalog ? "vestuario-public-selection" : "vestuario-cart") || "[]"));
      setCart(data);
    } catch {
      localStorage.removeItem(staticCatalog ? "vestuario-public-selection" : "vestuario-cart");
    }
    setReady(true);
  }, []);
  useEffect(() => {
    if (ready) localStorage.setItem(staticCatalog ? "vestuario-public-selection" : "vestuario-cart", JSON.stringify(cart));
  }, [cart, ready]);
  useEffect(() => {
    if (!toast) return;
    const timeout = setTimeout(() => setToast(""), 5000);
    return () => clearTimeout(timeout);
  }, [toast]);
  const add = (item: CartItem) => {
    setCart((old) =>
      old.some((i) => cartKey(i) === cartKey(item))
        ? old.map((i) =>
            cartKey(i) === cartKey(item)
              ? { ...i, quantity: Math.min(100, i.quantity + item.quantity) }
              : i,
          )
        : [...old, item],
    );
    setToast("Traje agregado a tu selección.");
  };
  return (
    <Context.Provider
      value={{
        cart,
        add,
        addMany: (items) => {
          setCart(old => [...old, ...items]);
          setToast("Juego de seis agregado a tu selección.");
        },
        setQuantity: (id, n) =>
          setCart((old) =>
            n > 0
              ? old.map((i) =>
                  cartKey(i) === id && !i.bundleId ? { ...i, quantity: Math.min(100, n) } : i,
                )
              : old.filter((i) => {
                  const target = old.find(x => cartKey(x) === id);
                  return target?.bundleId ? i.bundleId !== target.bundleId : cartKey(i) !== id;
                }),
          ),
        clear: () => setCart([]),
        notify: setToast,
      }}
    >
      <SiteHeader />
      {children}
      <SiteFooter />
      {toast && (
        <div className="toast" role="status">
          <Check size={18} />
          {toast}
          <button aria-label="Cerrar mensaje" onClick={() => setToast("")}>
            <X size={16} />
          </button>
        </div>
      )}
    </Context.Provider>
  );
}
function SiteHeader() {
  const path = usePathname();
  const { cart } = useStore();
  if (path.startsWith("/admin")) return null;
  return (
    <>
      <div className="announcement">
        Una nueva forma de encontrar el traje para tu próxima historia{" "}
        <span>✧</span>
      </div>
      <header className="site-header container">
        <Link href="/" className="logo" aria-label="Vestuario, inicio">
          <Flower2 size={28} strokeWidth={1.5} />
          vestuario<span>®</span>
        </Link>
        <nav aria-label="Navegación principal">
          <Link
            href="/catalogo"
            className={path === "/catalogo" ? "nav-active" : ""}
          >
            Explorar catálogo
          </Link>
          <Link href="/#como-funciona" className="hide-mobile">
            Cómo alquilar
          </Link>
        </nav>
        <Link href="/solicitud" className="bag">
          <ShoppingBag size={20} />
          <span className="hide-small">Mi selección</span>
          <span className="bag-count">
            {cart.reduce((s, i) => s + i.quantity, 0)}
          </span>
        </Link>
      </header>
    </>
  );
}
function SiteFooter() {
  const path = usePathname();
  const [config, setConfig] = useState<any>(null);
  useEffect(() => {
    api("/config")
      .then(setConfig)
      .catch(() => {});
  }, []);
  if (path.startsWith("/admin")) return null;
  return (
    <footer className="site-footer">
      <div className="container footer-top">
        <div>
          <Link href="/" className="logo">
            <Flower2 size={26} />
            vestuario
          </Link>
          <p>Historias, cultura y un traje para cada ocasión.</p>
        </div>
        <div>
          <Link href="/catalogo">
            Explorar el catálogo <ArrowUpRight size={15} />
          </Link>
          {!staticCatalog && <Link href="/admin">
            Administración <ArrowUpRight size={15} />
          </Link>}
          {config?.whatsappUrl && (
            <a href={config.whatsappUrl} target="_blank" rel="noreferrer">
              <MessageCircle size={16} /> Escríbenos por WhatsApp
            </a>
          )}
        </div>
      </div>
      <div className="container footer-bottom">
        <span>Vestuario · Hecho para volver a compartir.</span>
        <span>Precios en COP · Fechas de Bogotá</span>
      </div>
    </footer>
  );
}
