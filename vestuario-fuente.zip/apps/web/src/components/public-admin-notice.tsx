import Link from "next/link";
export function PublicAdminNotice() {
  return <main id="main" className="container page-space"><h1>Catálogo público</h1><p>El inventario y las reservas se administran en la aplicación privada del negocio.</p><Link className="text-link" href="/catalogo">Volver al catálogo</Link></main>;
}
