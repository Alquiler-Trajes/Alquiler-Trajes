"use client";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  CalendarDays,
  Check,
  ChevronDown,
  Info,
  Ruler,
  ShoppingBag,
  Sparkles,
  Users,
  Maximize2,
  PackageCheck,
  Minus,
  Plus,
} from "lucide-react";
import { money } from "@vestuario/shared";
import {
  api,
  bogotaISO,
  colombianDate,
  hasPendingPrice,
  compareSizes,
  mutation,
  type CatalogItem,
} from "@/lib/api";
import { Badge, Button, Dialog, ErrorBox, Field, Input, Loading } from "./ui";
import { useStore } from "./providers";
import { asset, staticCatalog } from "@/lib/public-mode";
const metricLabels: Record<string, string> = {
  height: "Estatura",
  chest: "Pecho",
  waist: "Cintura",
  hip: "Cadera",
  length: "Largo",
};
const levelLabels: Record<string, string> = {
  ORIENTATIVE: "Orientativa",
  ESTIMATED: "Estimada",
  VERIFIED: "Verificada por criterios",
};
export function ProductDetail({ slug }: { slug: string }) {
  const [item, setItem] = useState<CatalogItem | null>(null);
  const [selected, setSelected] = useState("");
  const [image, setImage] = useState("");
  const [photoView, setPhotoView] = useState<"model" | "bundle">("model");
  const [zoom, setZoom] = useState(false);
  const [error, setError] = useState("");
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const [count, setCount] = useState(1);
  const [bundle, setBundle] = useState(false);
  const [available, setAvailable] = useState<any>(null);
  const [body, setBody] = useState<Record<string, string>>({});
  const [fit, setFit] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const [checking, setChecking] = useState(false);
  const availabilityRequest = useRef(0);
  const { add, addMany } = useStore();
  useEffect(() => {
    let live = true;
    api("/catalog/" + encodeURIComponent(slug))
      .then((d) => {
        if (!live) return;
        d.variants.sort((a: any, b: any) => compareSizes(a.size, b.size) || a.color.localeCompare(b.color, "es"));
        setItem(d);
        setBundle(false);
        setCount(1);
        setSelected(d.variants[0]?.id || "");
        setImage(d.images[0] || "");
        setPhotoView("model");
        setZoom(false);
      })
      .catch((e) => { if (live) setError(e.message); });
    return () => { live = false; };
  }, [slug]);
  const variant = item?.variants.find((v) => v.id === selected);
  const pricePending = !!item && hasPendingPrice(variant?.price || 0, item.tags);
  useEffect(() => {
    setAvailable(null);
    setFit(null);
  }, [selected, bundle]);
  useEffect(() => {
    availabilityRequest.current++;
    setAvailable(null);
    setChecking(false);
  }, [start, end, selected, bundle]);
  if (!item)
    return error ? (
      <main id="main" className="container page-space">
        <ErrorBox message={error} />
        <Link href="/catalogo">Volver al catálogo</Link>
      </main>
    ) : (
      <Loading />
    );
  const colors = [...new Set(item.variants.map(v => v.color))];
  const showPhoto = (view: "model" | "bundle") => {
    setPhotoView(view);
    setImage(view === "bundle" ? item.bundleImage || item.images[0] || "" : item.images[0] || "");
  };
  const selectFormat = (isBundle: boolean) => {
    setBundle(isBundle);
    showPhoto(isBundle && item.bundleImage ? "bundle" : "model");
  };
  const colorVariants = colors.length > 1 ? item.variants.filter(v => v.color === variant?.color) : item.variants;
  const bundleItems = colorVariants.some(v => v.size === "Niño")
    ? colorVariants.filter(v => v.size === "Niño").map(v => ({ variantId: v.id, quantity: 6 }))
    : ["S", "M"].flatMap(size => colorVariants.filter(v => v.size === size).map(v => ({ variantId: v.id, quantity: 3 })));
  const bundleReady = bundleItems.reduce((n, i) => n + i.quantity, 0) === 6;
  const bundlePrice = bundleItems.reduce((n, i) => n + (item.variants.find(v => v.id === i.variantId)?.price || 0) * i.quantity, 0);
  const pendingSelection = pricePending || (bundle && bundleItems.some(i => hasPendingPrice(item.variants.find(v => v.id === i.variantId)?.price || 0, item.tags)));
  const checkAvailability = async () => {
    const requestId = ++availabilityRequest.current;
    setError("");
    setChecking(true);
    try {
      const result = bundle ? await api("/catalog/selection/availability", mutation("POST", {
          startsAt: bogotaISO(start), endsAt: bogotaISO(end), items: bundleItems,
        })) : await api(
          `/catalog/variants/${selected}/availability?` +
            new URLSearchParams({
              startsAt: bogotaISO(start),
              endsAt: bogotaISO(end),
            }),
        );
      if (requestId === availabilityRequest.current) setAvailable(result);
    } catch (e: any) {
      if (requestId === availabilityRequest.current) setError(e.message);
    } finally {
      if (requestId === availabilityRequest.current) setChecking(false);
    }
  };
  const checkFit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      setFit(
        await api(
          `/catalog/variants/${selected}/fit`,
          mutation(
            "POST",
            Object.fromEntries(
              Object.entries(body)
                .filter(([, v]) => v)
                .map(([k, v]) => [k, Number(v)]),
            ),
          ),
        ),
      );
    } catch (e: any) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <main id="main" className="container product-page">
      <Link href="/catalogo" className="text-link back-link">
        <ArrowLeft size={16} /> Volver al catálogo
      </Link>
      <div className="detail-grid">
        <div className="detail-visual">
          {item.bundleImage && <div className="photo-switch" role="group" aria-label="Vista del vestuario">
            <button className={photoView === "model" ? "selected" : ""} aria-pressed={photoView === "model"} onClick={() => showPhoto("model")}>Ver modelo</button>
            <button className={photoView === "bundle" ? "selected" : ""} aria-pressed={photoView === "bundle"} onClick={() => showPhoto("bundle")}><Users size={16} /> Ver juego completo x6</button>
          </div>}
          <div className={`detail-main-image ${photoView === "bundle" ? "bundle-photo" : ""}`}>
            <button className="photo-open" onClick={() => setZoom(true)} aria-label={photoView === "bundle" ? "Ampliar fotografía del juego de 6" : "Ampliar fotografía del modelo"}>
            <img
              src={image || asset("/placeholder.svg")}
              alt={
                item.demo
                  ? "Ilustración de demostración de " + item.name
                  : photoView === "bundle" ? `Juego completo de 6 · ${item.name}` : item.name
              }
            />
            <span className="photo-zoom"><Maximize2 size={16} /> Ampliar foto</span>
            </button>
            {item.demo && (
              <Badge tone="light">Ilustración de demostración</Badge>
            )}
          </div>
          {photoView === "bundle" && <p className="photo-caption"><Users size={16} /> Vista de referencia del juego de 6. La combinación de colores se acuerda con el negocio.</p>}
          {item.images.length > 1 && (
            <div className="thumbnails">
              {item.images.map((src) => (
                <button
                  key={src}
                  onClick={() => { setPhotoView("model"); setImage(src); }}
                  aria-label="Ver fotografía"
                  className={image === src ? "selected" : ""}
                >
                  <img src={src} alt="Vista de la prenda" />
                </button>
              ))}
            </div>
          )}
          {item.demo && (
            <p className="fine-print">
              <Info size={15} /> Este artículo, sus medidas y su precio son
              ficticios. La ilustración no representa inventario real.
            </p>
          )}
          {!item.demo && item.tags.includes("foto-referencia") && (
            <p className="fine-print"><Info size={15} /> Imagen de referencia del modelo. El conjunto incluye las piezas enumeradas en esta ficha.</p>
          )}
          {item.tags.includes("foto-estudio-ia") && <p className="fine-print"><Info size={15} /> Presentación de estudio editada con IA a partir de las fotos aportadas. Confirma los detalles de la prenda al recogerla.</p>}
          {!item.tags.includes("foto-estudio-ia") && item.tags.includes("foto-retocada") && <p className="fine-print"><Info size={15} /> Fotografía del vestuario retocada, con rostros anonimizados.</p>}
        </div>
        <div className="detail-content">
          <p className="eyebrow">{item.category.name}</p>
          <h1>{item.name}</h1>
          {item.danceStyle && <div className="culture-labels">{item.danceStyle.split(" / ").map(label => <Badge key={label}>{label}</Badge>)}{item.tags.includes("etiqueta-provisional") && <small>Etiqueta provisional</small>}</div>}
          <p className="detail-description">{item.description}</p>
          <div className="detail-price">
            {pendingSelection ? "Precio por definir" : money(bundle ? bundlePrice : variant?.price || 0)}
            {!pendingSelection && <span> / {bundle ? "juego de 6" : "alquiler"}</span>}
          </div>
          <div className="detail-rule" />
          {item.bundleSize === 6 && <>
            <div className="field choice-section" role="group" aria-label="Formato de alquiler">
              <span className="choice-title"><span>1</span> ¿Cuántos trajes necesitas?</span>
              <div className="format-options">
                <button aria-pressed={!bundle} className={!bundle ? "selected" : ""} onClick={() => selectFormat(false)} aria-label="Una unidad · x1"><ShoppingBag size={20} /><strong>Una unidad · x1</strong><small>Elige talla y cantidad</small><Check size={16} className="choice-check" /></button>
                <button aria-pressed={bundle} className={bundle ? "selected" : ""} onClick={() => selectFormat(true)} aria-label="Juego completo · x6"><Users size={20} /><strong>Juego completo · x6</strong><small>{colorVariants.some(v => v.size === "Niño") ? "6 trajes talla Niño" : "3 talla S + 3 talla M"}</small><Check size={16} className="choice-check" /></button>
              </div>
            </div>
            {bundle && <div className="bundle-breakdown" aria-label="Contenido del juego"><PackageCheck size={20} /><div><strong>Juego completo: 6 trajes</strong><p>{colorVariants.some(v => v.size === "Niño") ? "6 unidades talla Niño, con sus accesorios." : "3 talla S + 3 talla M, con sus accesorios."}</p></div></div>}
            {!bundle && <p className="fine-print">{colorVariants.some(v => v.size === "Niño") ? "Talla Niño · 6 unidades por modelo." : "Tallas escolares para niñas de 6.º y 7.º grado · 3 S + 3 M por modelo."}</p>}
          </>}
          {colors.length > 1 && <div className="field" role="group" aria-label="Elige color">
            <span>Color {item.bundleSize === 6 ? "de preferencia" : ""} · {variant?.color}</span>
            <div className="variant-options">
              {colors.map(color => <button key={color} aria-pressed={variant?.color === color} className={variant?.color === color ? "selected" : ""} onClick={() => {
                const next = item.variants.find(v => v.color === color && v.size === variant?.size) || item.variants.find(v => v.color === color);
                if (next) setSelected(next.id);
              }}>{color}</button>)}
            </div>
            {item.bundleSize === 6 && <small>Las opciones de color comparten las seis existencias. Confirmaremos la combinación contigo.</small>}
          </div>}
          {!bundle && <div className="field" role="group" aria-label="Elige talla y color">
            <span>Elige tu talla</span>
            {(item.bundleSize === 6 ? [{ label: "Escolar", variants: colorVariants }] : item.tags.includes("coleccion-real-octubre-2026") ? [
              { label: "Infantil", variants: colorVariants.filter(v => /^\d+$/.test(v.size)) },
              { label: "Adulto", variants: colorVariants.filter(v => ["XS", "S", "M", "L", "XL", "XXL"].includes(v.size)) },
              { label: "Talla única", variants: colorVariants.filter(v => !/^\d+$/.test(v.size) && !["XS", "S", "M", "L", "XL", "XXL"].includes(v.size)) },
            ] : [{ label: "", variants: colorVariants }]).filter(g => g.variants.length).map(group => (
            <div className="size-group" key={group.label}>
              {group.label && <p className="size-group-label">{group.label}</p>}
              <div className="variant-options">
              {group.variants.map((v) => (
                <button
                  key={v.id}
                  className={selected === v.id ? "selected" : ""}
                  onClick={() => setSelected(v.id)}
                  aria-pressed={selected === v.id}
                >
                  <strong>{v.size}</strong>
                  <span>{v.color}</span>
                </button>
              ))}
              </div>
            </div>
            ))}
          </div>}
          {!bundle && <div className="quantity-row"><div><label htmlFor="rental-quantity">Cantidad</label>
            <div className="quantity-stepper">
              <button onClick={() => setCount(n => Math.max(1, n - 1))} disabled={count <= 1} aria-label="Disminuir cantidad"><Minus size={16} /></button>
              <Input id="rental-quantity" type="number" min="1" max="100" value={count} onChange={e => setCount(Math.max(1, Math.min(100, Number(e.target.value) || 1)))} />
              <button onClick={() => setCount(n => Math.min(100, n + 1))} disabled={count >= 100} aria-label="Aumentar cantidad"><Plus size={16} /></button>
            </div>
          </div><span>{count === 1 ? "traje individual" : "trajes individuales"}</span></div>}
          {!bundle && <p className="fine-print">
            <Ruler size={15} /> La talla es una etiqueta comercial. Confirma el
            ajuste con medidas.
          </p>}
          {variant?.outfit && (
            <div className="included included-compact">
              <h3><PackageCheck size={18} /> Incluido en tu alquiler</h3>
              {variant.outfit.components.map((c: any, i: number) => (
                <div className="included-piece" key={i}>
                  <div><p>
                  <Check size={15} />
                  {c.quantity * (bundle ? 6 : count)} × {c.name}{" "}
                  </p>
                  <small>
                    {c.required
                      ? "Incluido en el alquiler"
                      : "Opcional, se acuerda con el negocio"}
                    {c.allowSubstitution
                      ? " · admite sustitución compatible"
                      : ""}
                  </small>
                  </div>
                </div>
              ))}
            </div>
          )}
          {!!item.includedAccessories?.length && <div className="included accessories-compact">
            <h3>Accesorios incluidos</h3>
            <div className="accessory-tags">{item.includedAccessories.map(name => <span key={name}><Check size={14} /> {name}</span>)}</div>
            <small>Se entregan con el traje, sin alquiler adicional.</small>
          </div>}
          {!staticCatalog && <div className="date-card">
            <h3>
              <CalendarDays size={18} /> ¿Cuándo lo necesitas?
            </h3>
            <div className="form-grid">
              <Field label="Entrega · Bogotá">
                <Input
                  type="datetime-local"
                  value={start}
                  onChange={(e) => setStart(e.target.value)}
                />
              </Field>
              <Field label="Devolución · Bogotá">
                <Input
                  type="datetime-local"
                  min={start}
                  value={end}
                  onChange={(e) => setEnd(e.target.value)}
                />
              </Field>
            </div>
            <Button
              variant="outline"
              disabled={!start || !end || checking}
              onClick={checkAvailability}
            >
              {checking ? "Consultando…" : "Consultar disponibilidad"}
            </Button>
            {available && (
              <p
                className={
                  (bundle ? available.sufficient : available.available) ? "success-text" : "warning-text"
                }
                role="status"
              >
                {bundle ? (available.sufficient ? "Juego de seis disponible para estas fechas." : "El juego de seis no está completo para estas fechas. Puedes consultar unidades individuales.") : available.available
                  ? `${available.available} ${variant?.outfit ? "conjuntos completos" : "unidades"} disponibles en estas fechas.`
                  : "Sin disponibilidad en estas fechas. Prueba otro intervalo."}
              </p>
            )}
            <p className="fine-print">
              La disponibilidad se valida nuevamente al confirmar la reserva.
            </p>
          </div>}
          {staticCatalog && <p className="info-box"><Info size={18} /> Elige los trajes que te interesan. Confirmaremos tarifa, colores y disponibilidad contigo antes del alquiler.</p>}
          <ErrorBox message={error} />
          <div className="selection-summary">
            <div className="selection-total"><div><span>Tu selección</span><strong>{bundle ? "1 juego · 6 trajes" : `${count} ${count === 1 ? "traje" : "trajes"} · talla ${variant?.size || ""}`}</strong></div><strong>{pendingSelection ? "Tarifa por confirmar" : money(bundle ? bundlePrice : (variant?.price || 0) * count)}</strong></div>
            <div className="add-selection">
            <Button
              disabled={
                !variant ||
                (!staticCatalog && pendingSelection) ||
                (bundle ? !bundleReady || available?.sufficient === false : available?.available === 0 || (available && count > available.available))
              }
              onClick={() => {
                if (bundle) {
                  const bundleId = crypto.randomUUID();
                  addMany(bundleItems.map(i => {
                    const v = item.variants.find(v => v.id === i.variantId)!;
                    return { ...i, slug: item.slug, name: item.name, size: v.size, color: v.color, price: v.price, image: item.bundleImage || item.images[0] || "", demo: item.demo, bundleId, bundleLabel: "Juego de 6" };
                  }));
                  return;
                }
                add({
                  variantId: selected,
                  slug: item.slug,
                  name: item.name,
                  size: variant.size,
                  color: variant.color,
                  price: variant.price,
                  quantity: count,
                  image: item.images[0] || "",
                  demo: item.demo,
                });
              }}
            >
              <ShoppingBag size={18} /> {bundle ? "Agregar juego de 6" : "Agregar a mi selección"}
            </Button>
          </div>
          {pendingSelection && <p className="fine-print">{staticCatalog ? "La tarifa se confirma con el negocio. Puedes guardar este modelo en tu selección." : "Este modelo está listo. El negocio está definiendo su tarifa; podrás agregarlo cuando esté publicada."}</p>}
          <Link className="text-link" href="/solicitud">
            {staticCatalog ? "Ver mi selección" : "Continuar con la solicitud"} <ArrowRight size={16} />
          </Link>
          <small className="selection-note">{staticCatalog ? "Tu selección se guarda en este dispositivo. No confirma una reserva." : "Sin registro. La solicitud se confirma con el negocio."}</small>
          </div>
          {!staticCatalog && <details className="fit-panel">
            <summary>
              <span>
                <Ruler size={19} /> Te ayudamos con la talla
              </span>
              <ChevronDown size={18} />
            </summary>
            <div>
              <p>
                Usamos las medidas reales registradas, sin deducir el ajuste
                solo por la edad. Introduce medidas corporales en centímetros.
              </p>
              <form onSubmit={checkFit}>
                <div className="form-grid">
                  {["height", "chest", "waist", "hip"].map((m) => (
                    <Field key={m} label={metricLabels[m] + " (cm)"}>
                      <Input
                        type="number"
                        step="0.1"
                        min="1"
                        max="300"
                        value={body[m] || ""}
                        onChange={(e) =>
                          setBody({ ...body, [m]: e.target.value })
                        }
                      />
                    </Field>
                  ))}
                </div>
                <Button variant="outline" disabled={busy}>
                  <Sparkles size={16} />
                  {busy ? "Comparando…" : "Consultar compatibilidad"}
                </Button>
              </form>
              {fit && (
                <div className="fit-results" role="status">
                  {fit.note && <p>{fit.note}</p>}
                  {!fit.results.length && (
                    <p>
                      No hay medidas de unidades propias para este conjunto.
                      Confirma el ajuste de sus componentes con el negocio.
                    </p>
                  )}
                  {fit.results.map((r: any) => (
                    <div key={r.unitId} className="fit-result">
                      <Badge
                        tone={r.compatible === false ? "warning" : "default"}
                      >
                        {levelLabels[r.level]}
                      </Badge>
                      <strong>{r.code}</strong>
                      <p>
                        {r.compatible === true
                          ? "Cumple los criterios registrados."
                          : r.compatible === false
                            ? "No cumple uno o varios criterios."
                            : "Todavía no podemos confirmar la talla."}
                      </p>
                      {r.reasons.map((reason: string) => (
                        <small key={reason}>
                          {reason
                            .replace(/chest/g, "Pecho")
                            .replace(/waist/g, "Cintura")
                            .replace(/height/g, "Estatura")
                            .replace(/hip/g, "Cadera")}
                        </small>
                      ))}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </details>}
          {variant?.calendar?.length > 0 && (
            <details className="calendar-list">
              <summary>Ver intervalos reservados de esta variante</summary>
              <p className="fine-print">
                Los bloqueos corresponden a unidades individuales. Otras
                unidades de la misma talla pueden estar disponibles.
              </p>
              {variant.calendar.map((b: any, i: number) => (
                <p key={i}>
                  {colombianDate(b.startsAt)} →{" "}
                  {b.endsAt
                    ? colombianDate(b.endsAt)
                    : "Hasta finalizar revisión"}
                </p>
              ))}
            </details>
          )}
        </div>
      </div>
      <Dialog title="Fotografía ampliada" open={zoom} onClose={() => setZoom(false)} wide>
        <img className="enlarged-photo" src={image || asset("/placeholder.svg")} alt={photoView === "bundle" ? `Juego completo de 6 · ${item.name}` : item.name} />
        <p className="photo-caption">{photoView === "bundle" ? "Vista de referencia del juego de seis. Colores sujetos a confirmación." : item.name}</p>
        {image && <a className="text-link" href={image} target="_blank" rel="noreferrer">Abrir imagen a tamaño completo <Maximize2 size={15} /></a>}
      </Dialog>
    </main>
  );
}
