"use client";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { ArrowLeft, ArrowRight, CalendarDays, Check, ChevronDown, Maximize2, Minus, PackageCheck, Plus, Ruler, ShoppingBag, Users } from "lucide-react";
import { money } from "@vestuario/shared";
import { api, bogotaISO, colombianDate, hasPendingPrice, compareSizes, mutation, type CatalogItem } from "@/lib/api";
import { asset, staticCatalog } from "@/lib/public-mode";
import { Badge, Button, Dialog, ErrorBox, Field, Input, Loading } from "./ui";
import { useStore } from "./providers";
const metricLabels: Record<string, string> = { height: "Estatura", chest: "Pecho", waist: "Cintura", hip: "Cadera", length: "Largo" };
const levelLabels: Record<string, string> = { ORIENTATIVE: "Orientativa", ESTIMATED: "Estimada", VERIFIED: "Verificada por criterios" };
export function ProductDetail({ slug }: { slug: string }) {
  const [item, setItem] = useState<CatalogItem | null>(null);
  const [selected, setSelected] = useState("");
  const [image, setImage] = useState("");
  const [photoView, setPhotoView] = useState<"model" | "bundle">("model");
  const [zoom, setZoom] = useState(false);
  const [error, setError] = useState("");
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const [count, setCount] = useState(1);
  const [bundle, setBundle] = useState(false);
  const [added, setAdded] = useState(false);
  const [available, setAvailable] = useState<any>(null);
  const [body, setBody] = useState<Record<string, string>>({});
  const [fit, setFit] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const [checking, setChecking] = useState(false);
  const availabilityRequest = useRef(0);
  const { add, addMany } = useStore();
  useEffect(() => {
    let live = true; setError("");
    api("/catalog/" + encodeURIComponent(slug)).then(d => {
      if (!live) return;
      d.variants.sort((a: any, b: any) => compareSizes(a.size, b.size) || a.color.localeCompare(b.color, "es"));
      setItem(d); setBundle(false); setCount(1); setSelected(d.variants[0]?.id || ""); setImage(d.images[0] || ""); setPhotoView("model"); setZoom(false);
    }).catch(e => { if (live) setError(e.message); });
    return () => { live = false; };
  }, [slug]);
  const variant = item?.variants.find(v => v.id === selected);
  useEffect(() => { setAdded(false); }, [selected, bundle, count]);
  useEffect(() => { setFit(null); }, [selected, bundle]);
  useEffect(() => { availabilityRequest.current++; setAvailable(null); setChecking(false); }, [start, end, selected, bundle]);
  if (!item) return error ? <main id="main" className="container page-space"><ErrorBox message={error} /><Link href="/catalogo">Volver al catálogo</Link></main> : <Loading />;
  const colors = [...new Set(item.variants.map(v => v.color))];
  const colorVariants = item.variants.filter(v => v.color === variant?.color);
  const childBundle = colorVariants.some(v => v.size === "Niño");
  const bundleItems = childBundle ? colorVariants.filter(v => v.size === "Niño").map(v => ({ variantId: v.id, quantity: 6 })) : ["S", "M"].flatMap(size => colorVariants.filter(v => v.size === size).map(v => ({ variantId: v.id, quantity: 3 })));
  const bundleReady = bundleItems.reduce((n, i) => n + i.quantity, 0) === 6;
  const bundlePrice = bundleItems.reduce((n, i) => n + (item.variants.find(v => v.id === i.variantId)?.price || 0) * i.quantity, 0);
  const pendingSelection = hasPendingPrice(variant?.price || 0, item.tags) || (bundle && bundleItems.some(i => hasPendingPrice(item.variants.find(v => v.id === i.variantId)?.price || 0, item.tags)));
  const selectFormat = (isBundle: boolean) => {
    setBundle(isBundle); setPhotoView(isBundle && item.bundleImage ? "bundle" : "model"); setImage(isBundle && item.bundleImage ? item.bundleImage : item.images[0] || "");
  };
  const checkAvailability = async () => {
    const requestId = ++availabilityRequest.current; setError(""); setChecking(true);
    try {
      const result = bundle ? await api("/catalog/selection/availability", mutation("POST", { startsAt: bogotaISO(start), endsAt: bogotaISO(end), items: bundleItems })) : await api(`/catalog/variants/${selected}/availability?` + new URLSearchParams({ startsAt: bogotaISO(start), endsAt: bogotaISO(end) }));
      if (requestId === availabilityRequest.current) setAvailable(result);
    } catch (e: any) { if (requestId === availabilityRequest.current) setError(e.message); }
    finally { if (requestId === availabilityRequest.current) setChecking(false); }
  };
  const checkFit = async (event: React.FormEvent) => {
    event.preventDefault(); setBusy(true); setError("");
    try { setFit(await api(`/catalog/variants/${selected}/fit`, mutation("POST", Object.fromEntries(Object.entries(body).filter(([, v]) => v).map(([k, v]) => [k, Number(v)]))))); }
    catch (e: any) { setError(e.message); } finally { setBusy(false); }
  };
  const choose = () => {
    if (!variant) return;
    if (bundle) {
      const bundleId = crypto.randomUUID();
      addMany(bundleItems.map(i => { const v = item.variants.find(v => v.id === i.variantId)!; return { ...i, slug: item.slug, name: item.name, size: v.size, color: v.color, price: v.price, image: item.bundleImage || item.images[0] || "", demo: item.demo, bundleId, bundleLabel: "Juego de 6" }; }));
    } else add({ variantId: selected, slug: item.slug, name: item.name, size: variant.size, color: variant.color, price: variant.price, quantity: count, image: item.images[0] || "", demo: item.demo });
    setAdded(true);
  };
  const sizeGroups = item.bundleSize === 6 ? [{ label: "Escolar", variants: colorVariants }] : [
    { label: "Infantil", variants: colorVariants.filter(v => /^\d+$/.test(v.size)) },
    { label: "Adulto", variants: colorVariants.filter(v => ["XS", "S", "M", "L", "XL", "XXL"].includes(v.size)) },
    { label: "Otras tallas", variants: colorVariants.filter(v => !/^\d+$/.test(v.size) && !["XS", "S", "M", "L", "XL", "XXL"].includes(v.size)) },
  ];
  return <main id="main" className="container product-page easy-detail">
    <Link href="/catalogo" className="text-link back-link"><ArrowLeft size={20} /> Volver al catálogo</Link>
    <div className="detail-grid">
      <div className="detail-visual">
        <div className={`detail-main-image ${photoView === "bundle" ? "bundle-photo" : ""}`}><button className="photo-open" onClick={() => setZoom(true)} aria-label={photoView === "bundle" ? "Ampliar fotografía del juego de 6" : "Ampliar fotografía del modelo"}><img src={image || asset("/placeholder.svg")} alt={photoView === "bundle" ? `Juego completo de 6 · ${item.name}` : item.name} /><span className="photo-zoom"><Maximize2 size={19} /> Toca para ampliar</span></button></div>
        {photoView === "bundle" && <p className="photo-caption">Juego completo de 6 · Colores sujetos a confirmación.</p>}
        <details className="photo-details"><summary>{item.tags.includes("foto-estudio-ia") ? "Foto editada con IA · Ver detalles" : item.demo ? "Ilustración de ejemplo · Ver detalles" : "Sobre esta fotografía"}</summary><p>{item.demo ? "Este artículo, sus medidas y su precio son ficticios. La ilustración no representa inventario real." : item.tags.includes("foto-estudio-ia") ? "Presentación de estudio editada con IA a partir de las fotos aportadas. Confirma los detalles de la prenda al recogerla." : "Imagen de referencia del modelo. Confirma los detalles de la prenda con el negocio."}</p>{item.images.length > 1 && <div className="thumbnails">{item.images.map(src => <button key={src} onClick={() => { setImage(src); setPhotoView("model"); }} aria-label="Ver fotografía"><img src={src} alt="Otra vista de la prenda" /></button>)}</div>}</details>
      </div>
      <div className="detail-content">
        <h1>{item.name}</h1>
        {(!!item.includedAccessories?.length || variant?.outfit) && <p className="included-note"><PackageCheck size={21} /> {item.includedAccessories?.length ? "Accesorios incluidos en el alquiler" : "Conjunto completo"}</p>}
        {item.bundleSize === 6 && <div className="field choice-section" role="group" aria-label="Formato de alquiler"><span className="choice-title">¿Cuántos trajes necesitas?</span><div className="format-options"><button className={!bundle ? "selected" : ""} aria-label="1 traje" aria-pressed={!bundle} onClick={() => selectFormat(false)}><ShoppingBag size={22} /><strong>1 traje</strong><small>Elige talla y cantidad</small><Check className="choice-check" size={18} /></button><button className={bundle ? "selected" : ""} aria-label="Juego de 6" aria-pressed={bundle} onClick={() => selectFormat(true)}><Users size={22} /><strong>Juego de 6</strong><small>{childBundle ? "6 talla Niño" : "3 talla S + 3 talla M"}</small><Check className="choice-check" size={18} /></button></div></div>}
        {colors.length > 1 && <Field label={item.bundleSize === 6 ? "Color de preferencia" : "Color"}><select aria-label={item.bundleSize === 6 ? "Color de preferencia" : "Color"} value={variant?.color || ""} onChange={e => { const next = item.variants.find(v => v.color === e.target.value && v.size === variant?.size) || item.variants.find(v => v.color === e.target.value); if (next) setSelected(next.id); }}>{colors.map(color => <option key={color}>{color}</option>)}</select></Field>}
        {!bundle && <div className="detail-size-quantity"><Field label="Elige tu talla"><select aria-label="Elige tu talla" value={selected} onChange={e => setSelected(e.target.value)}>{sizeGroups.filter(group => group.variants.length).map(group => <optgroup key={group.label} label={group.label}>{group.variants.map(v => <option value={v.id} key={v.id}>{v.size}</option>)}</optgroup>)}</select></Field><div className="field"><label htmlFor="rental-quantity">Cantidad</label><div className="quantity-stepper"><button onClick={() => setCount(n => Math.max(1, n - 1))} disabled={count <= 1} aria-label="Disminuir cantidad"><Minus size={19} /></button><Input id="rental-quantity" type="number" min="1" max="100" value={count} onChange={e => setCount(Math.max(1, Math.min(100, Number(e.target.value) || 1)))} /><button onClick={() => setCount(n => Math.min(100, n + 1))} disabled={count >= 100} aria-label="Aumentar cantidad"><Plus size={19} /></button></div></div></div>}
        {bundle && <div className="bundle-breakdown" aria-label="Contenido del juego"><PackageCheck size={23} /><div><strong>6 trajes con sus accesorios</strong><p>{childBundle ? "6 unidades talla Niño" : "3 talla S + 3 talla M"}</p></div></div>}
        <ErrorBox message={error} />
        <div className="selection-summary"><div className="selection-total"><div><span>{bundle ? "Juego completo" : `${count} ${count === 1 ? "traje" : "trajes"} · talla ${variant?.size || ""}`}</span><strong>{pendingSelection ? "Precio a consultar" : money(bundle ? bundlePrice : (variant?.price || 0) * count)}</strong></div></div>
          {added ? <><p className="selection-saved" role="status"><Check size={22} /> Ya está en tus trajes.</p><Button asChild><Link href="/solicitud">Ver mis trajes <ArrowRight size={21} /></Link></Button><Link className="text-link" href="/catalogo">Elegir otro traje</Link></> : <Button disabled={!variant || (!staticCatalog && pendingSelection) || (bundle ? !bundleReady || available?.sufficient === false : available?.available === 0 || (available && count > available.available))} onClick={choose}>{bundle ? "Elegir juego de 6" : "Elegir este traje"} <ArrowRight size={21} /></Button>}
          <p className="selection-note">{staticCatalog ? "El negocio confirma el precio y las fechas contigo." : pendingSelection ? "El negocio está definiendo la tarifa de este modelo." : "La solicitud se confirma con el negocio."}</p>
        </div>
        <details className="garment-details"><summary>Ver detalles del traje <ChevronDown size={20} /></summary><div><p>{item.description}</p>{item.danceStyle && <p><strong>Danza o región:</strong> {item.danceStyle}{item.tags.includes("etiqueta-provisional") ? " · Etiqueta provisional" : ""}</p>}{!!item.includedAccessories?.length && <><h2>Accesorios incluidos</h2><ul>{item.includedAccessories.map(name => <li key={name}>{name}</li>)}</ul></>}{variant?.outfit && <><h2>Qué incluye</h2><ul>{variant.outfit.components.map((component: any, i: number) => <li key={i}>{component.quantity * (bundle ? 6 : count)} × {component.name}{!component.required ? " · opcional" : ""}{component.allowSubstitution ? " · admite sustitución compatible" : ""}</li>)}</ul></>}{item.bundleSize === 6 && <p>{childBundle ? "Talla Niño. Seis unidades por modelo." : "Tallas escolares para niñas de 6.º y 7.º grado. Tres S y tres M por modelo."} Los colores comparten existencias.</p>}<p>La talla es una etiqueta comercial. Confirma el ajuste con medidas.</p></div></details>
        {!staticCatalog && <><details className="date-card easy-disclosure"><summary><CalendarDays size={22} /> Consultar fechas <ChevronDown size={20} /></summary><div><h2>¿Cuándo lo necesitas?</h2><div className="form-grid"><Field label="Entrega · Bogotá"><Input type="datetime-local" value={start} onChange={e => setStart(e.target.value)} /></Field><Field label="Devolución · Bogotá"><Input type="datetime-local" value={end} min={start} onChange={e => setEnd(e.target.value)} /></Field></div><Button variant="outline" disabled={!start || !end || checking} onClick={checkAvailability}>{checking ? "Consultando…" : "Consultar disponibilidad"}</Button>{available && <p role="status" className={(bundle ? available.sufficient : available.available) ? "success-text" : "warning-text"}>{bundle ? available.sufficient ? "Juego de seis disponible para estas fechas." : "El juego de seis no está completo para estas fechas. Puedes consultar unidades individuales." : available.available ? `${available.available} ${variant?.outfit ? "conjuntos completos" : "unidades"} disponibles en estas fechas.` : "Sin disponibilidad en estas fechas. Prueba otro intervalo."}</p>}<p>La disponibilidad se valida al confirmar la reserva.</p></div></details>
          <details className="fit-panel"><summary><span><Ruler size={22} /> Te ayudamos con la talla</span><ChevronDown size={20} /></summary><div><p>Introduce medidas corporales en centímetros para compararlas con las prendas registradas.</p><form onSubmit={checkFit}><div className="form-grid">{["height", "chest", "waist", "hip"].map(metric => <Field key={metric} label={metricLabels[metric] + " (cm)"}><Input type="number" step="0.1" min="1" max="300" value={body[metric] || ""} onChange={e => setBody({ ...body, [metric]: e.target.value })} /></Field>)}</div><Button variant="outline" disabled={busy}>{busy ? "Comparando…" : "Consultar compatibilidad"}</Button></form>{fit && <div className="fit-results" role="status">{fit.note && <p>{fit.note}</p>}{!fit.results.length && <p>No hay medidas de unidades propias para este conjunto. Confirma el ajuste de sus componentes con el negocio.</p>}{fit.results.map((result: any) => <div key={result.unitId} className="fit-result"><Badge tone={result.compatible === false ? "warning" : "default"}>{levelLabels[result.level]}</Badge><strong>{result.code}</strong><p>{result.compatible === true ? "Cumple los criterios registrados." : result.compatible === false ? "No cumple uno o varios criterios." : "Todavía no podemos confirmar la talla."}</p>{result.reasons.map((reason: string) => <small key={reason}>{reason.replace(/chest/g, "Pecho").replace(/waist/g, "Cintura").replace(/height/g, "Estatura").replace(/hip/g, "Cadera")}</small>)}</div>)}</div>}</div></details></>}
        {variant?.calendar?.length > 0 && <details className="calendar-list"><summary>Ver intervalos reservados de esta variante</summary><p>Los bloqueos corresponden a unidades individuales. Otras unidades pueden estar disponibles.</p>{variant.calendar.map((block: any, i: number) => <p key={i}>{colombianDate(block.startsAt)} → {block.endsAt ? colombianDate(block.endsAt) : "Hasta finalizar revisión"}</p>)}</details>}
      </div>
    </div>
    <Dialog title="Fotografía ampliada" open={zoom} onClose={() => setZoom(false)} wide><img className="enlarged-photo" src={image || asset("/placeholder.svg")} alt={photoView === "bundle" ? `Juego completo de 6 · ${item.name}` : item.name} /><p className="photo-caption">{photoView === "bundle" ? "Vista de referencia del juego de seis. Colores sujetos a confirmación." : item.name}</p>{image && <a className="text-link" href={image} target="_blank" rel="noreferrer">Abrir imagen a tamaño completo <Maximize2 size={18} /></a>}</Dialog>
  </main>;
}
